(()=>{
'use strict';
const KEY='__KYRON_SIDEBAR_BRAND_HOOK_V3__';if(globalThis[KEY])return;
const SIDEBAR='nav[aria-label="Chat history"],aside[aria-label="Sidebar"],[data-octane-sidebar-pane],[data-sidebar-shell-version]',FROM='ChatGPT',TO='Kyrongpt';
const exact=v=>String(v??'').trim()===FROM,inSidebar=el=>!!el?.closest?.(SIDEBAR);
function patchText(t){if(!t||t.nodeType!==3||!inSidebar(t.parentElement)||!exact(t.nodeValue))return false;const raw=String(t.nodeValue||''),lead=(raw.match(/^\s*/)||[''])[0],tail=(raw.match(/\s*$/)||[''])[0];t.nodeValue=lead+TO+tail;return true}
function patchAttrs(el){if(!el||el.nodeType!==1||!inSidebar(el))return 0;let n=0;for(const a of['aria-label','title'])if(exact(el.getAttribute?.(a))){el.setAttribute(a,TO);n++}return n}
function patch(root){if(!root)return 0;if(root.nodeType===3)return patchText(root)?1:0;if(![1,9,11].includes(root.nodeType))return 0;let n=root.nodeType===1?patchAttrs(root):0;if(root.querySelectorAll)for(const el of root.querySelectorAll('[aria-label],[title]'))n+=patchAttrs(el);const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let t;while((t=w.nextNode()))if(patchText(t))n++;return n}
let mo=null,host=null;
function bind(){const next=document.querySelector(SIDEBAR);if(!next)return false;if(next===host)return true;mo?.disconnect();host=next;patch(host);mo=new MutationObserver(ms=>{for(const m of ms)for(const n of m.addedNodes)if(n.nodeType===1||n.nodeType===3)patch(n)});mo.observe(host,{subtree:true,childList:true});return true}
function start(){if(bind())return;const boot=new MutationObserver(()=>{if(bind())boot.disconnect()});boot.observe(document.documentElement,{subtree:true,childList:true});setTimeout(()=>boot.disconnect(),12000)}
globalThis[KEY]={patch,bind};if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();addEventListener('pageshow',()=>{bind();patch(host)},{passive:true});
})();