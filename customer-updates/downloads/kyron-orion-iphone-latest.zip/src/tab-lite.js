(()=>{
'use strict';
const KEY='__KYRON_TAB_LITE_V3__';if(globalThis[KEY])return;
const api=globalThis.browser||globalThis.chrome,STYLE='kyron-tab-lite-v3-style';let reason='resident';
function ensure(){if(document.getElementById(STYLE))return;const s=document.createElement('style');s.id=STYLE;s.textContent='[data-testid^="conversation-turn-"],article[data-testid^="conversation-turn-"]{content-visibility:auto;contain-intrinsic-size:auto 520px}';(document.head||document.documentElement)?.appendChild(s)}
function apply(){ensure();document.documentElement?.setAttribute('data-kyron-tab-lite','resident');document.documentElement?.setAttribute('data-kyron-tab-lite-reason',reason)}
api?.runtime?.onMessage?.addListener?.((m,_s,send)=>{if(m?.scope!=='kyron-page'||m?.type!=='tab-lite:update')return false;reason=String(m?.payload?.reason||'resident').slice(0,48);apply();send?.({ok:true,sleep:false,state:'resident'});return false});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply,{once:true,passive:true});else apply();globalThis[KEY]={apply,get forced(){return false},get state(){return'resident'}};
})();