(()=>{
'use strict';
globalThis.KyronUpdateChannel=Object.freeze({
  schema:4,
  provider:'pantry-core',
  host:'https://raw.githubusercontent.com/pvtkyron/pantry-core/main',
  mirrors:['https://pvtkyron.github.io/pantry-core','https://cdn.jsdelivr.net/gh/pvtkyron/pantry-core@main'],
  manifestPath:'/customer-updates/customer.json',
  channel:'orion',
  timeoutMs:5600,
  graceMs:450,
  pollMinutes:360
});
})();
