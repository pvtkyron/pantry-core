(()=>{
'use strict';
globalThis.KyronUpdateChannel=Object.freeze({
  schema:2,
  provider:'pantry-core',
  host:'https://pvtkyron.github.io/pantry-core',
  manifestPath:'/customer-updates/customer.json',
  channel:'orion',
  pollMinutes:360
});
})();
