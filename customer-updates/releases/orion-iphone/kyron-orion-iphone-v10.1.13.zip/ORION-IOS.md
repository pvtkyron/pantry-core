# Kyron v10.1.12 — Orion iPhone build

This package is prepared for Orion on iOS/iPadOS.

## Install

1. In Orion, open `...` -> **Settings** and enable **Chrome Extensions**.
2. Open `...` -> **Extensions** -> `+` -> **Install from File**.
3. Select `Kyron-v10.1.12-iPhone-Orion-FIX6.zip` from the Files app. If the iCloud picker is unreliable, save the ZIP under **On My iPhone** first and select it there.
4. Open `https://chatgpt.com/`, then open **Extensions** and choose **Kyron v10.1.12**.
5. Enter the Kyron license and allow the requested ChatGPT/OpenAI site permissions if Orion asks.

## iOS compatibility changes

- `manifest.json` is at the ZIP root.
- Removed Chrome-version pinning, Chrome extension key, split-incognito setting, and the optional `webNavigation` permission.
- Added cross-browser MV3 background fallback: background scripts + service worker.
- Added `browser`/`chrome` API compatibility and script-injection fallback paths.
- Background health checks tolerate APIs that Orion iOS may not expose.
- Kyron identifies Orion to the gateway when Orion exposes its `KAGI` browser context.
- If Orion iOS omits or rewrites the WebExtension HTTP `Origin` header and the v3 gateway returns `origin_denied`, login automatically retries through the existing v1 compatibility transport on Orion only.

## If Orion installs it but a feature fails

Orion's iOS WebExtension implementation is still partial. Capture the exact Kyron popup error or Orion extension-console error. That distinguishes an install/package problem from an unsupported runtime API.


## FIX3 — iOS account picker
- The account selector no longer starts the async restore from the native iOS `<select>` change event.
- A visible green **Select account** button now performs the restore after the picker is closed.
- The button is disabled until an account is chosen.
- This avoids Orion/iOS popup lifecycle issues while the native picker is open.


## FIX4 — Android-parity account flow
- Android behavior is the source of truth for the Accounts screen.
- The green **Select account** button appears only after an account is chosen.
- Choosing from the native picker does not itself alter the ChatGPT session.
- Tapping **Select account** runs the same account-selection backend: fetch snapshot -> restore cookies/storage -> verify ChatGPT session -> persist selection -> reload target ChatGPT tab(s).
- iOS-specific code is limited to browser API / transport compatibility; account state semantics are unchanged.


## FIX6 — stable HWID + auth/backups parity with Android v10.1.12

- The KeyAuth HWID is no longer a throwaway install UUID: the current ID is mirrored to a secure, long-lived cookie on the Kyron Worker origin and recovered after extension replacement.
- Existing local IDs win during migration, so updating in place preserves the currently bound KeyAuth HWID.
- Remembered-license self-healing remains enabled if a previous 401 left the local session marked for reauthentication.
- A `request_signature_invalid` response no longer poisons the saved customer session; only genuine session-invalid codes trigger reauthentication.
- v3/v2 backup/profile reads automatically fall back to the current Worker v1 bearer routes only for signature-compatibility/not-found errors; real expired/revoked sessions still fail closed.
- FIX4 iOS picker semantics are preserved: choosing an account does not switch it until **Select account** is tapped.
- Runtime version markers were bumped to `10.1.12` so an already-open ChatGPT page does not reuse injected `10.1.10` bridge/guard state.
- The manifest description and the popup brand subtitle were removed.
