(()=>{
'use strict';
const KEY='__KYRON_SIDEBAR_BRAND_HOOK_V2__';
if(globalThis[KEY])return;
const SIDEBAR='nav[aria-label="Chat history"],aside[aria-label="Sidebar"],[data-octane-sidebar-pane],[data-sidebar-shell-version]';
const FROM='ChatGPT',TO='Kyrongpt';
const exact=v=>String(v??'').trim()===FROM;
const inSidebar=el=>!!el?.closest?.(SIDEBAR);
function patchText(t){
  if(!t||t.nodeType!==Node.TEXT_NODE||!inSidebar(t.parentElement)||!exact(t.nodeValue))return false;
  const raw=String(t.nodeValue||''),lead=(raw.match(/^\s*/)||[''])[0],tail=(raw.match(/\s*$/)||[''])[0];
  t.nodeValue=lead+TO+tail;return true;
}
function patchAttrs(el){
  if(!el||el.nodeType!==Node.ELEMENT_NODE||!inSidebar(el))return 0;
  let n=0;
  for(const a of ['aria-label','title']){const v=el.getAttribute?.(a);if(exact(v)){el.setAttribute(a,TO);n++}}
  return n;
}
function patch(root){
  if(!root)return 0;
  if(root.nodeType===Node.TEXT_NODE)return patchText(root)?1:0;
  if(root.nodeType!==Node.ELEMENT_NODE&&root.nodeType!==Node.DOCUMENT_NODE&&root.nodeType!==Node.DOCUMENT_FRAGMENT_NODE)return 0;
  let n=0;if(root.nodeType===Node.ELEMENT_NODE)n+=patchAttrs(root);
  if(root.querySelectorAll)for(const el of root.querySelectorAll('[aria-label],[title]'))n+=patchAttrs(el);
  const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let t;while((t=w.nextNode()))if(patchText(t))n++;
  return n;
}
function start(){
  if(!document.documentElement){document.addEventListener('DOMContentLoaded',start,{once:true});return}
  patch(document);
  const mo=new MutationObserver(ms=>{for(const m of ms){if(m.type==='characterData')patchText(m.target);else if(m.type==='attributes')patchAttrs(m.target);for(const x of m.addedNodes||[])patch(x)}});
  mo.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['aria-label','title']});
}
globalThis[KEY]={patch,patchText,patchAttrs};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
globalThis.addEventListener?.('pageshow',()=>patch(document));
if(globalThis.__KYRON_TEST_MODE__)globalThis.__KYRON_BRAND_HOOK_TEST__={patch,patchText,patchAttrs};
})();
