'use strict';
importScripts('hardcoded-v920.js','local-features.js','config-store.js','account-hook.js','background.js','page-health.js','update-channel.js','update-check.js');
async function kyronReinjectConversationBidi(){try{const tabs=await chrome.tabs.query({url:['*://*.chatgpt.com/*']});for(const t of tabs){if(!t?.id||t.discarded||t.frozen)continue;await chrome.scripting.executeScript({target:{tabId:t.id,frameIds:[0]},files:['src/conversation-bidi.js','src/brand-hook.js']}).catch(()=>{})}}catch{}}
kyronReinjectConversationBidi().catch(()=>{});
chrome.runtime.onStartup.addListener(()=>kyronReinjectConversationBidi().catch(()=>{}));
chrome.runtime.onInstalled.addListener(()=>kyronReinjectConversationBidi().catch(()=>{}));
