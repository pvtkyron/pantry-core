(()=>{
  'use strict';
  const FORMAT='kyron-global-config',SCHEMA=1,MAX_FILE=16*1024*1024,BACKUP_KEY='kyronGlobalConfigBackup.v1',KEYS=[
    'sitevaultPrefs','kyronAppearance','kyronDeepFocus','kyronPersonality','kyronPageHealth','kyronTabGovernor','kyronUiDensity.v1','kyronModelProfiles.v1','kyronCustomerModel'
  ],EXCLUDED=['SiteVault account/snapshot blobs','cookies and page auth/session state','runtime telemetry and restore journals'];
  const has=(o,k)=>Object.prototype.hasOwnProperty.call(o||{},k),clone=v=>v===undefined?undefined:JSON.parse(JSON.stringify(v));
  function clean(key,value){
    const v=clone(value);if(key==='sitevaultPrefs'&&v&&typeof v==='object'){v.selectedBackupId=null;v.vaultPinnedIds=[]}return v;
  }
  function build(raw={},version='unknown',now=new Date().toISOString()){
    const config={};for(const k of KEYS)if(has(raw,k))config[k]=clean(k,raw[k]);
    return{format:FORMAT,schema:SCHEMA,createdAt:now,kyronVersion:String(version||'unknown'),portable:true,config,excluded:[...EXCLUDED],note:'Portable Kyron configuration. Known auth/session/vault secrets and runtime-only state are intentionally excluded.'};
  }
  function parse(raw){
    if(!raw||typeof raw!=='object'||Array.isArray(raw))throw new Error('Invalid config file.');
    if(raw.format!==FORMAT)throw new Error('This is not a Kyron global config file.');
    const schema=Number(raw.schema)||0;if(schema<1||schema>SCHEMA)throw new Error(`Unsupported config schema ${raw.schema}.`);
    if(!raw.config||typeof raw.config!=='object'||Array.isArray(raw.config))throw new Error('Config payload is missing.');
    const config={};for(const k of KEYS)if(has(raw.config,k))config[k]=clean(k,raw.config[k]);
    if(!Object.keys(config).length)throw new Error('No portable Kyron settings were found in this file.');
    return{schema,kyronVersion:String(raw.kyronVersion||'unknown'),createdAt:String(raw.createdAt||''),config};
  }
  async function exportFile(){
    const raw=await chrome.storage.local.get(KEYS),out=build(raw,chrome.runtime.getManifest().version),blob=new Blob([JSON.stringify(out,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=`Kyron-Global-Config-v${out.kyronVersion}-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);return Object.keys(out.config).length;
  }
  async function importFile(file){
    if(!file)throw new Error('Choose a config file.');if(file.size>MAX_FILE)throw new Error('Config file is too large.');
    let raw;try{raw=JSON.parse(await file.text())}catch{throw new Error('Config file is not valid JSON.')}
    const incoming=parse(raw),n=Object.keys(incoming.config).length;
    if(!confirm(`Import ${n} Kyron setting group${n===1?'':'s'} from v${incoming.kyronVersion}?\n\nThis replaces matching local settings. Account snapshots and login/session data are not touched.`))return{cancelled:true};
    await backupLocal();await chrome.storage.local.set(incoming.config);return{cancelled:false,count:n,sourceVersion:incoming.kyronVersion};
  }
  async function backupLocal(){const raw=await chrome.storage.local.get(KEYS),out=build(raw,chrome.runtime.getManifest().version);await chrome.storage.local.set({[BACKUP_KEY]:out});return{count:Object.keys(out.config).length,createdAt:out.createdAt}}
  async function restoreLocal(){const x=await chrome.storage.local.get(BACKUP_KEY),raw=x[BACKUP_KEY];if(!raw)throw new Error('No local config backup.');const incoming=parse(raw);await chrome.storage.local.set(incoming.config);return{count:Object.keys(incoming.config).length,sourceVersion:incoming.kyronVersion}}
  function flash(btn,text,ms=1400){if(!btn)return;const old=btn.dataset.baseLabel||btn.textContent;btn.dataset.baseLabel=old;btn.textContent=text;setTimeout(()=>{btn.textContent=btn.dataset.baseLabel||old},ms)}
  function init(){
    if(typeof document==='undefined'||typeof chrome==='undefined'||!chrome.storage?.local)return;const ex=document.querySelector('#configExportBtn'),im=document.querySelector('#configImportBtn'),bk=document.querySelector('#configBackupBtn'),rs=document.querySelector('#configRestoreBtn'),fi=document.querySelector('#configImportFile');if(!ex||!im||!fi)return;
    ex.addEventListener('click',async()=>{try{ex.disabled=true;const n=await exportFile();flash(ex,`Exported ${n}`)}catch(e){flash(ex,'Export failed',2200);console.error('[Kyron config export]',e)}finally{ex.disabled=false}});
    bk?.addEventListener('click',async()=>{try{bk.disabled=true;const r=await backupLocal();flash(bk,`Backed up ${r.count}`)}catch(e){flash(bk,'Backup failed',2200);console.error('[Kyron config backup]',e)}finally{bk.disabled=false}});
    rs?.addEventListener('click',async()=>{try{rs.disabled=true;if(!confirm('Restore the last local config backup?'))return;const r=await restoreLocal();flash(rs,`Restored ${r.count}`,700);setTimeout(()=>location.reload(),500)}catch(e){flash(rs,e?.message||'Restore failed',2600);console.error('[Kyron config restore]',e)}finally{rs.disabled=false}});
    im.addEventListener('click',()=>fi.click());fi.addEventListener('change',async()=>{const f=fi.files?.[0];if(!f)return;try{im.disabled=true;const r=await importFile(f);if(r.cancelled)return;flash(im,`Imported ${r.count}`,700);setTimeout(()=>location.reload(),500)}catch(e){flash(im,e?.message||'Import failed',2600);console.error('[Kyron config import]',e)}finally{im.disabled=false;fi.value=''}});
  }
  globalThis.KyronGlobalConfig={FORMAT,SCHEMA,BACKUP_KEY,KEYS:[...KEYS],EXCLUDED:[...EXCLUDED],build,parse,clean,backupLocal,restoreLocal};init();
})();
