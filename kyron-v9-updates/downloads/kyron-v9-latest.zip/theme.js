(()=>{
  const $=s=>document.querySelector(s),KEY='kyronAppearance',MODES=['midnight','black','graphite'];
  const LABELS={midnight:'Midnight',black:'Deep Black',graphite:'Graphite'};
  const E={theme:$('#themeBtn'),label:$('#themeLabel'),boost:$('#quickBoostState'),boostDot:$('#quickBoostDot'),persona:$('#quickPersonaState'),personaDot:$('#quickPersonaDot')};
  let mode='midnight';
  function apply(v){mode=MODES.includes(v)?v:'midnight';document.documentElement.dataset.theme=mode;document.documentElement.dataset.themeMode=mode;if(E.label)E.label.textContent=LABELS[mode];if(E.theme){E.theme.title=`Appearance: ${LABELS[mode]} · click to change`;E.theme.setAttribute('aria-label',`Appearance ${LABELS[mode]}`)}}
  async function save(v){apply(v);await chrome.storage.local.set({[KEY]:{schema:2,mode}})}
  async function load(){const x=await chrome.storage.local.get(KEY),v=x[KEY]?.mode;apply(MODES.includes(v)?v:'midnight');if(!MODES.includes(v)&&v)await chrome.storage.local.set({[KEY]:{schema:2,mode:'midnight'}})}
  function setChip(kind,on,text){const value=E[kind],dot=E[kind+'Dot'];if(value)value.textContent=text||(on?'On':'Off');if(dot){dot.classList.toggle('on',!!on);dot.classList.toggle('off',!on)}}
  async function refreshQuick(){try{const x=await chrome.storage.local.get(['kyronDeepFocus','kyronPersonality']),b=x.kyronDeepFocus||{};setChip('boost',b.enabled!==false,b.enabled===false?'Off':b.mode==='strong'?'Strong':b.mode==='native'?'Native':'Auto');setChip('persona',x.kyronPersonality?.enabled===true,x.kyronPersonality?.enabled===true?'On':'Off')}catch{}
  }
  E.theme?.addEventListener('click',()=>{const i=MODES.indexOf(mode);save(MODES[(i+1)%MODES.length]).catch(()=>{})});
  document.querySelectorAll('[data-jump]').forEach(b=>b.addEventListener('click',()=>document.querySelector(`[data-view="${b.dataset.jump}"]`)?.click()));
  $('#boostEnabled')?.addEventListener('change',e=>setChip('boost',e.target.checked,e.target.checked?'On':'Off'));
  $('#personaEnabled')?.addEventListener('change',e=>setChip('persona',e.target.checked,e.target.checked?'On':'Off'));
  chrome.storage.onChanged.addListener((c,a)=>{if(a==='local'&&(c.kyronDeepFocus||c.kyronPersonality||c[KEY])){if(c[KEY])apply(c[KEY].newValue?.mode);refreshQuick()}});
  load().then(refreshQuick).catch(()=>{apply('midnight');refreshQuick()});
})();
