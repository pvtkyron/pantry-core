const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const enc=new TextEncoder(),dec=new TextDecoder(),PRIVATE=!!chrome.extension?.inIncognitoContext;
const MAGIC3='SITEVAULT3\n',MAGIC2='SITEVAULT2\n';
const KINDS=['cookies','local','session','idb','cache'];
const ui={
  captureView:$('#captureView'),vaultView:$('#vaultView'),boostView:$('#boostView'),personaView:$('#personaView'),source:$('#sourceTab'),target:$('#targetTab'),sourceOrigin:$('#sourceOrigin'),sourceFrames:$('#sourceFrames'),snapshotName:$('#snapshotName'),
  cookiesStat:$('#cookiesStat'),localStat:$('#localStat'),sessionStat:$('#sessionStat'),idbStat:$('#idbStat'),cacheStat:$('#cacheStat'),cookiesPicked:$('#cookiesPicked'),localPicked:$('#localPicked'),sessionPicked:$('#sessionPicked'),idbPicked:$('#idbPicked'),cachePicked:$('#cachePicked'),
  scopeAll:$('#scopeAllBtn'),frames:$('#framesToggle'),encrypt:$('#encryptToggle'),passRow:$('#passRow'),pass:$('#passphrase'),showPass:$('#showPass'),advancedBtn:$('#advancedBtn'),advanced:$('#advancedPanel'),advancedSummary:$('#advancedSummary'),capture:$('#captureBtn'),captureSub:$('#captureSub'),
  vaultCount:$('#vaultCount'),vaultSearch:$('#vaultSearch'),backupList:$('#backupList'),restorePanel:$('#restorePanel'),selectedName:$('#selectedName'),selectedMeta:$('#selectedMeta'),restoreSummary:$('#restoreSummary'),mappingHint:$('#mappingHint'),restoreSub:$('#restoreSub'),
  status:$('#statusBox'),statusText:$('#statusText'),statusPct:$('#statusPct'),progress:$('#progressBar'),statusDetail:$('#statusDetail'),
  picker:$('#pickerModal'),pickerTitle:$('#pickerTitle'),pickerSearch:$('#pickerSearch'),pickerList:$('#pickerList'),pickerCount:$('#pickerCount'),pickerAll:$('#pickerAll'),pickerNone:$('#pickerNone'),
  prompt:$('#promptModal'),promptTitle:$('#promptTitle'),promptText:$('#promptText'),promptInput:$('#promptInput'),promptOk:$('#promptOk'),preview:$('#previewModal'),previewBody:$('#previewBody'),
  importFile:$('#importFile'),liveAccountCard:$('#liveAccountCard'),sourceGptSearch:$('#sourceGptSearch'),sourceGptFind:$('#sourceGptFind'),sourceGptMeta:$('#sourceGptMeta'),targetGptSearch:$('#targetGptSearch'),targetGptFind:$('#targetGptFind'),targetGptMeta:$('#targetGptMeta'),
  surfaceKind:$('#surfaceKind'),surfaceRoute:$('#surfaceRoute'),surfaceNativeAccounts:$('#surfaceNativeAccounts'),surfaceDrafts:$('#surfaceDrafts'),surfaceModels:$('#surfaceModels'),surfaceVolatile:$('#surfaceVolatile'),surfaceEndpoints:$('#surfaceEndpoints'),githubSyncState:$('#githubSyncState'),profileTags:$('#profileTags'),profileNotes:$('#profileNotes'),saveProfileMeta:$('#saveProfileMeta'),compareProfileBtn:$('#compareProfileBtn'),captureRecipeHint:$('#captureRecipeHint'),vaultSort:$('#vaultSort'),vaultFilter:$('#vaultFilter'),vaultOverview:$('#vaultOverview'),accountStackIntel:$('#accountStackIntel'),restoreRecipe:$('#restoreRecipe'),restoreRecipeHint:$('#restoreRecipeHint'),restoreCustomBox:$('#restoreCustomBox')
};
let tabs=[],scan=null,currentPicker=null,selectedBackupId=null,restoreMode='merge',restoreRecipe='full',restoreCustom={kinds:{cookies:false,local:true,session:true,idb:true,cache:false},classes:{stable:true,preferences:true,model:true,workspace:true,draft:true,volatile:false,integrity:false,auth:false,diagnostics:false},cookieClasses:{auth:true,stable:true,ephemeral:false},policies:{cookies:'inherit',local:'inherit',session:'inherit',idb:'inherit',cache:'inherit'}},cookieMode='strict',records=[],gptSource=null,gptTarget=null,profilesReconciled=false,captureRecipe='full',vaultSort='recent',vaultFilter='all',vaultPinnedIds=new Set(),applyingRecipe=false;
const selected=Object.fromEntries(KINDS.map(k=>[k,new Set()]));

const humanBytes=n=>n<1024?`${n} B`:n<1048576?`${(n/1024).toFixed(n<10240?1:0)} KB`:`${(n/1048576).toFixed(1)} MB`;
const ago=iso=>{const s=Math.max(0,(Date.now()-new Date(iso))/1000);if(s<60)return'just now';if(s<3600)return`${Math.floor(s/60)}m ago`;if(s<86400)return`${Math.floor(s/3600)}h ago`;if(s<604800)return`${Math.floor(s/86400)}d ago`;return new Date(iso).toLocaleDateString()};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const status=(text,pct=0,detail='')=>{ui.status.hidden=false;ui.statusText.textContent=text;ui.statusPct.textContent=`${pct}%`;ui.progress.style.width=`${pct}%`;ui.statusDetail.textContent=detail};
const hideStatus=()=>ui.status.hidden=true;
const uid=()=>crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random().toString(16).slice(2)}`;
const validUrl=u=>/^https?:/i.test(u||'');
const contextLabel=()=>PRIVATE?'Incognito':'Normal';
function assertContextTab(t){if(!t)throw new Error('Select a tab first.');if(!!t.incognito!==PRIVATE)throw new Error(`Context mismatch: this ${contextLabel()} Kyron window cannot restore into a ${t.incognito?'Incognito':'Normal'} tab.`);return t}
const hostOf=u=>{try{return new URL(u).hostname}catch{return''}};
const originOf=u=>{try{return new URL(u).origin}catch{return''}};
const kindOn=k=>$(`[data-kind="${k}"]`)?.checked;
const setBusy=v=>{$$('button,select,input').forEach(x=>{if(!x.closest('dialog'))x.disabled=v});};
const itemId=(...x)=>JSON.stringify(x);
const cookieId=c=>itemId(c.storeId||'',c.domain||'',c.path||'/',c.name||'',c.partitionKey||null);
const GPT_STORAGE_DOMAINS=['chatgpt.com','chat.openai.com'],FASTPASS_DOMAINS=['fastpass-panel.ir'];
const GPT_COOKIE_URLS=['https://chatgpt.com/','https://openai.com/','https://auth.openai.com/'],FASTPASS_COOKIE_URLS=['https://chats.fastpass-panel.ir/'];
const hostMatches=(host,domain)=>host===domain||host.endsWith('.'+domain);
const isGptStorageHost=host=>GPT_STORAGE_DOMAINS.some(d=>hostMatches((host||'').toLowerCase(),d));
const isFastpassHost=host=>FASTPASS_DOMAINS.some(d=>hostMatches((host||'').replace(/^\./,'').toLowerCase(),d));
const GPT_COOKIE_DOMAINS=['chatgpt.com','openai.com'];
const isGptCookieHost=host=>{host=(host||'').replace(/^\./,'').toLowerCase();return GPT_COOKIE_DOMAINS.some(d=>hostMatches(host,d))};
const isSupportedCookieHost=host=>isGptCookieHost(host)||isFastpassHost(host);
const isRestorableCookie=c=>!!c&&isSupportedCookieHost(c.domain);
const cleanHeaders=h=>(h||[]).filter(([k])=>!['authorization','proxy-authorization','cookie','set-cookie','x-api-key'].includes(String(k).toLowerCase()));
const isGptOrigin=o=>{try{return isGptStorageHost(new URL(o).hostname)}catch{return false}};
const isFastpassOrigin=o=>{try{return isFastpassHost(new URL(o).hostname)}catch{return false}};
const isSupportedOrigin=o=>isGptOrigin(o)||isFastpassOrigin(o);
const sessionClass=o=>isFastpassOrigin(o)?'FASTPASS':isGptOrigin(o)?'GPT':'OTHER';
const sourceSessionClass=v=>sessionClass(v?.source?.wrapperOrigin||v?.source?.origin||v?.source?.url||'');
const targetSessionClass=(t,g)=>sessionClass(originOf(t?.url)||g?.wrapperOrigin||g?.primaryOrigin||'');
const sameSessionBoundary=(v,t,g)=>{const a=sourceSessionClass(v),b=targetSessionClass(t,g);return a!=='OTHER'&&a===b};
const bridgeDirection=(v,t,g)=>sourceSessionClass(v)==='FASTPASS'&&targetSessionClass(t,g)==='GPT';
const restoreRouteAllowed=(v,t,g)=>v?.scope?.restoreCookies===false||!(v?.cookies?.length)||sameSessionBoundary(v,t,g)||(cookieMode==='map'&&bridgeDirection(v,t,g));

async function cookieStoreForTab(tabId){
  try{for(const s of await chrome.cookies.getAllCookieStores())if((s.tabIds||[]).includes(Number(tabId)))return s.id}catch{}return undefined;
}
async function partitionKeyForContext(ctx){
  if(ctx?.tabId==null||ctx?.frameId==null||!chrome.cookies.getPartitionKey)return null;
  try{return (await chrome.cookies.getPartitionKey({tabId:Number(ctx.tabId),frameId:Number(ctx.frameId)}))?.partitionKey||null}catch{return null}
}
const cookieBucket=c=>isFastpassHost(c?.domain)?'FASTPASS_FIRST_PARTY':c?.partitionKey?'GPT_EMBEDDED_PARTITION':'GPT_UNPARTITIONED';
const withBucket=(c,b)=>({...c,sitevaultBucket:b});
const rootSite=o=>{try{const u=new URL(o),h=u.hostname.toLowerCase();if(isFastpassHost(h))return `${u.protocol}//fastpass-panel.ir`;if(isGptCookieHost(h))return `${u.protocol}//chatgpt.com`;return u.origin}catch{return''}};
const keySig=k=>JSON.stringify(k||null);
async function partitionCandidates(ctx,wrapperOrigin=''){
  const out=new Map(),add=k=>{if(k?.topLevelSite)out.set(keySig(k),k)};
  add(await partitionKeyForContext(ctx));
  if(ctx?.tabId!=null)try{for(const f of await chrome.webNavigation.getAllFrames({tabId:Number(ctx.tabId)})||[])if(f.frameId!==ctx?.frameId)add(await partitionKeyForContext({tabId:ctx.tabId,frameId:f.frameId}))}catch{}
  const top=rootSite(wrapperOrigin);if(top){add({topLevelSite:top});add({topLevelSite:top,hasCrossSiteAncestor:true});add({topLevelSite:top,hasCrossSiteAncestor:false})}
  return[...out.values()];
}
async function gptCookieBuckets(ctx,wrapperOrigin=''){
  const storeId=await cookieStoreForTab(ctx?.tabId),unpartitioned=new Map(),embedded=new Map(),keys=isFastpassOrigin(wrapperOrigin)?await partitionCandidates(ctx,wrapperOrigin):[];
  for(const url of GPT_COOKIE_URLS){
    const base={url};if(storeId!==undefined)base.storeId=storeId;
    try{for(const c of await chrome.cookies.getAll(base))if(isGptCookieHost(c.domain)&&!c.partitionKey&&isRestorableCookie(c))unpartitioned.set(cookieId(c),withBucket(c,'GPT_UNPARTITIONED'))}catch{}
    for(const partitionKey of keys)try{for(const c of await chrome.cookies.getAll({...base,partitionKey}))if(isGptCookieHost(c.domain)&&c.partitionKey&&isRestorableCookie(c))embedded.set(cookieId(c),withBucket(c,'GPT_EMBEDDED_PARTITION'))}catch{}
  }
  return{unpartitioned:[...unpartitioned.values()],embedded:[...embedded.values()],partitionKeys:keys,storeId};
}
async function fastpassCookies(ctx){
  const storeId=await cookieStoreForTab(ctx?.tabId),out=new Map();
  for(const url of FASTPASS_COOKIE_URLS){const base={url};if(storeId!==undefined)base.storeId=storeId;try{for(const c of await chrome.cookies.getAll(base))if(isFastpassHost(c.domain)&&!c.partitionKey)out.set(cookieId(c),withBucket(c,'FASTPASS_FIRST_PARTY'))}catch{}}
  return{cookies:[...out.values()],storeId};
}
async function siteCookies(ctx,wrapperOrigin=''){
  const g=await gptCookieBuckets(ctx,wrapperOrigin),f=isFastpassOrigin(wrapperOrigin)?await fastpassCookies(ctx):{cookies:[],storeId:g.storeId},proxy=isFastpassOrigin(wrapperOrigin),cookies=proxy?[...f.cookies,...g.embedded]:g.unpartitioned;
  return{cookies,buckets:{FASTPASS_FIRST_PARTY:f.cookies,GPT_UNPARTITIONED:g.unpartitioned,GPT_EMBEDDED_PARTITION:g.embedded},partitionKeys:g.partitionKeys,partitionKey:g.partitionKeys[0]||null,storeId:g.storeId};
}
function sessionHealthFromCookies(cookies=[]){const auth=(cookies||[]).filter(c=>/^__Secure-next-auth\.session-token(?:\.\d+)?$/i.test(c?.name||''));if(!auth.length)return{status:'unknown',authCookieCount:0,expiresAt:null,checkedAt:new Date().toISOString()};const finite=auth.map(c=>Number(c.expirationDate)).filter(Number.isFinite),now=Date.now()/1000;if(!finite.length)return{status:'session',authCookieCount:auth.length,expiresAt:null,checkedAt:new Date().toISOString()};const exp=Math.min(...finite),hours=(exp-now)/3600,status=hours<=0?'expired':hours<=72?'expiring':'healthy';return{status,authCookieCount:auth.length,expiresAt:new Date(exp*1000).toISOString(),checkedAt:new Date().toISOString()}}

async function inspectGptTab(t){
  const wrapperOrigin=originOf(t?.url),rows=await chrome.webNavigation.getAllFrames({tabId:t.id})||[],contexts=[];
  for(const f of rows){
    const origin=originOf(f.url);if(!isGptOrigin(origin))continue;
    contexts.push({origin,host:hostOf(f.url),kind:f.frameId===0?'direct':'embedded',frameId:f.frameId,documentId:f.documentId||null,parentFrameId:f.parentFrameId??-1,href:f.url});
  }
  return{tabId:t.id,wrapperOrigin,contexts};
}
function routeScore(x){
  let n=x.kind==='direct'?20:10;const u=x.href||'';if(/\/g\//.test(u))n+=6;if(/\/c\//.test(u))n+=8;if(x.host==='chatgpt.com')n+=4;return n;
}
function pickGptContext(info,q=''){
  if(!info)return null;q=q.trim().toLowerCase();let list=info.contexts||[];
  if(q&&q!=='gpt'&&q!=='chatgpt')list=list.filter(x=>`${x.host} ${x.origin} ${x.href||''} ${x.kind}`.toLowerCase().includes(q));
  return list.sort((a,b)=>routeScore(b)-routeScore(a))[0]||null;
}
function gptRoute(href=''){
  try{const u=new URL(href),seg=u.pathname.split('/').filter(Boolean),gi=seg.indexOf('g'),ci=seg.indexOf('c'),space=gi>=0?String(seg[gi+1]||''):'',raw=ci>=0?decodeURIComponent(String(seg[ci+1]||'')):'',colon=raw.indexOf(':'),namespace=colon>0?raw.slice(0,colon):'',conversationId=colon>0?raw.slice(colon+1):raw,surface=space?'project':/(?:^|\/)(?:f|work|workspace)(?:\/|$)/i.test(u.pathname)?'work':'chat';return{path:u.pathname,space,conversation:raw,conversationId,namespace,surface}}catch{return{path:'',space:'',conversation:'',conversationId:'',namespace:'',surface:'chat'}}
}

async function probeSurfaceIntel(t,gctx=gptSource){
  if(!t?.id)return null;const frameId=gctx?.frameId??0;
  try{const rr=await chrome.scripting.executeScript({target:{tabId:t.id,frameIds:[frameId]},func:()=>{
    const parseCount=key=>{try{const raw=localStorage.getItem(key);if(!raw)return 0;const v=JSON.parse(raw);return Array.isArray(v)?v.length:v&&typeof v==='object'?Object.keys(v).length:1}catch{return 0}},keys=[];try{for(let i=0;i<localStorage.length;i++)keys.push(localStorage.key(i)||'')}catch{}
    const paths=[];try{for(const e of performance.getEntriesByType('resource').slice(-700)){try{const u=new URL(e.name,location.href);if(u.origin!==location.origin)continue;const p=u.pathname;if(/^\/(?:backend-api|backend-anon|ces|realtime)\//.test(p))paths.push(p+u.search)}catch{}}}catch{}
    const uniq=[...new Set(paths)].slice(-40),p=location.pathname,project=(p.match(/\/(g-p-[A-Za-z0-9_-]+)/)||[])[1]||'',surface=project?'Project':/\/(?:f|work|workspace)(?:\/|$)/i.test(p)?'Work / F':'Chat',volatile=keys.filter(k=>/(?:resume|token|secret|session|auth|credential|correlated|accountSwitch)/i.test(k)).length;
    return{surface,route:p,project:project?project.slice(0,12)+'…':'',nativeAccounts:parseCount('oai/apps/accountSwitchSessions'),drafts:parseCount('oai/apps/conversationDrafts'),modelStores:keys.filter(k=>/(?:^|\/)models$|tpp-models|oai-last-model-config/i.test(k)).length,volatile,endpoints:uniq};
  }});return rr?.[0]?.result||null}catch{return null}
}
function paintSurfaceIntel(x){if(!x){for(const e of[ui.surfaceKind,ui.surfaceRoute,ui.surfaceNativeAccounts,ui.surfaceDrafts,ui.surfaceModels,ui.surfaceVolatile])if(e)e.textContent='—';ui.surfaceEndpoints.textContent='No live metadata yet.';return}ui.surfaceKind.textContent=x.project?`${x.surface} · ${x.project}`:x.surface;ui.surfaceRoute.textContent=x.route||'/';ui.surfaceNativeAccounts.textContent=String(x.nativeAccounts??0);ui.surfaceDrafts.textContent=String(x.drafts??0);ui.surfaceModels.textContent=String(x.modelStores??0);ui.surfaceVolatile.textContent=String(x.volatile??0);const families=Object.entries(x.endpointFamilies||{}).sort((a,b)=>b[1]-a[1]).map(([k,n])=>`${k}×${n}`);ui.surfaceEndpoints.textContent=families.length?`Recent families: ${families.join(' · ')}`:(x.endpoints?.length?`Seen ${x.endpoints.length} backend path(s)`:'No backend endpoints observed in the recent resource window.')}
async function refreshSurfaceIntel(){const t=tabById(ui.source.value);if(!t)return;const x=await probeSurfaceIntel(t,gptSource);paintSurfaceIntel(x);return x}
function setGptMeta(which,ctx,wrapperOrigin=''){
  const el=which==='source'?ui.sourceGptMeta:ui.targetGptMeta;if(!el)return;
  if(!ctx){el.dataset.kind='cookie';el.querySelector('b').textContent='GPT session cookies';el.querySelector('small').textContent='cookie-only fallback';return}
  el.dataset.kind=ctx.kind;const r=gptRoute(ctx.href);el.querySelector('b').textContent=ctx.host||ctx.origin;el.querySelector('small').textContent=`${ctx.kind} · frame ${ctx.frameId}${r.conversation?` · ${r.conversation.slice(0,8)}…`:''}`;el.title=wrapperOrigin&&wrapperOrigin!==ctx.origin?`${wrapperOrigin} → ${ctx.href}`:ctx.href;
}
async function findGpt(which,{silent=false,rescan=true}={}){
  const select=which==='source'?ui.source:ui.target,input=which==='source'?ui.sourceGptSearch:ui.targetGptSearch,query=(input?.value||'').trim().toLowerCase();
  const t=tabById(select.value);if(!t)return null;assertContextTab(t);
  if(!silent)status(`Finding exact GPT ${which}`,18,t.url);
  try{
    const info=await inspectGptTab(t),found=pickGptContext(info,query);
    if(!found)throw new Error('No live ChatGPT document exists inside this tab.');
    const state={tabId:t.id,wrapperOrigin:info.wrapperOrigin,primaryOrigin:found.origin,kind:found.kind,frameId:found.frameId,documentId:found.documentId,frameUrl:found.href,host:found.host,route:gptRoute(found.href)};
    if(which==='source')gptSource=state;else gptTarget=state;setGptMeta(which,found,info.wrapperOrigin);
    if(!silent){status('Exact GPT document found',100,`${found.kind} · frame ${found.frameId}`);setTimeout(hideStatus,650)}
    if(which==='source'){scan=null;if(rescan)await scanSource()}else updateMappingHint();return state;
  }catch(e){const wrapperOrigin=originOf(t.url),proxy=isFastpassOrigin(wrapperOrigin),fallback={tabId:t.id,wrapperOrigin,primaryOrigin:proxy?wrapperOrigin:'https://chatgpt.com',kind:proxy?'proxy':'cookie',frameId:proxy?0:null,documentId:null,frameUrl:proxy?t.url:'',host:proxy?hostOf(t.url):'chatgpt.com',route:gptRoute(proxy?t.url:'https://chatgpt.com/')};if(which==='source')gptSource=fallback;else gptTarget=fallback;if(proxy)setGptMeta(which,{...fallback,origin:fallback.primaryOrigin,href:t.url},wrapperOrigin);else setGptMeta(which,null,wrapperOrigin);if(!silent){status(proxy?'Fast Chat proxy found':'GPT frame not live',100,proxy?'Same ChatGPT surface on proxy origin · frame 0':'Full GPT/OpenAI cookie session scope is still available');setTimeout(hideStatus,850)}if(which==='source'){scan=null;if(rescan)await scanSource()}else updateMappingHint();return fallback}
}

async function promptBox(title,text,ok='Continue',{input=false,type='text',value='',placeholder=''}={}){
  ui.promptTitle.textContent=title;ui.promptText.textContent=text;ui.promptOk.textContent=ok;ui.promptInput.hidden=!input;ui.promptInput.type=type;ui.promptInput.value=value;ui.promptInput.placeholder=placeholder;
  return new Promise(resolve=>{const done=()=>{ui.prompt.removeEventListener('close',done);resolve(ui.prompt.returnValue==='ok'?(input?ui.promptInput.value:true):(input?'':false))};ui.prompt.addEventListener('close',done);ui.prompt.showModal();if(input)setTimeout(()=>ui.promptInput.focus(),20)});
}
const askPassword=()=>promptBox('Encrypted snapshot','Enter the password for this snapshot.','Unlock',{input:true,type:'password',placeholder:'Password'});

function switchView(name){$$('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));ui.captureView.hidden=name!=='capture';ui.vaultView.hidden=name!=='vault';ui.boostView.hidden=name!=='boost';ui.personaView.hidden=name!=='persona';if(name==='vault'){renderVault();renderLiveAccountCard().catch(()=>{})}}

async function loadTabs(){
  const oldS=Number(ui.source.value)||null,oldT=Number(ui.target.value)||null,all=await chrome.tabs.query({});tabs=all.filter(t=>validUrl(t.url)&&!!t.incognito===PRIVATE).sort((a,b)=>(b.active-a.active)||(a.index-b.index));
  const fill=(el,prefer)=>{el.innerHTML='';for(const t of tabs){const o=document.createElement('option');o.value=t.id;o.textContent=`${hostOf(t.url)}${t.title?` — ${t.title}`:''}`;el.appendChild(o)}const id=tabs.some(t=>t.id===prefer)?prefer:(tabs.find(t=>t.active)?.id||tabs[0]?.id);if(id)el.value=String(id)};
  fill(ui.source,oldS);fill(ui.target,oldT||oldS);updateMappingHint();
}
const tabById=id=>tabs.find(t=>t.id===Number(id));
async function waitTabReady(tabId,timeout=18000){return new Promise((resolve,reject)=>{let done=false,timer=setTimeout(()=>finish(null,new Error('Timed out waiting for chatgpt.com to load.')),timeout);const finish=(tab,err)=>{if(done)return;done=true;clearTimeout(timer);chrome.tabs.onUpdated.removeListener(onUpdate);err?reject(err):resolve(tab)};const onUpdate=(id,change,tab)=>{if(id===Number(tabId)&&(change.status==='complete'||(tab?.url&&isGptStorageHost(hostOf(tab.url))&&change.url)))finish(tab)};chrome.tabs.onUpdated.addListener(onUpdate);chrome.tabs.get(Number(tabId)).then(tab=>{if(tab?.status==='complete'&&isGptStorageHost(hostOf(tab.url)))finish(tab)}).catch(()=>{})})}
async function ensureChatGptTarget(t){assertContextTab(t);if(isGptStorageHost(hostOf(t.url)))return t;status(`Opening ChatGPT in ${contextLabel()}`,14,'Same selected tab · other Chrome context stays untouched');await chrome.tabs.update(t.id,{url:'https://chatgpt.com/'});const ready=await waitTabReady(t.id);if(!!ready.incognito!==PRIVATE)throw new Error('Chrome returned the target in the wrong privacy context.');await loadTabs();ui.target.value=String(t.id);gptTarget=null;await findGpt('target',{silent:true});return tabById(t.id)||ready}


async function probeFrameMeta(){
  const byteLen=s=>new TextEncoder().encode(String(s??'')).length,req=r=>new Promise((res,rej)=>{r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
  const out={origin:location.origin,href:location.href,title:document.title,visibility:document.visibilityState,top:window.top===window,local:[],session:[],idb:[],cache:[],serviceWorkers:[],storage:null};
  try{for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i),v=localStorage.getItem(key);out.local.push({key,bytes:byteLen(key)+byteLen(v)})}}catch{}
  try{for(let i=0;i<sessionStorage.length;i++){const key=sessionStorage.key(i),v=sessionStorage.getItem(key);out.session.push({key,bytes:byteLen(key)+byteLen(v)})}}catch{}
  try{for(const meta of await indexedDB.databases()){if(!meta.name)continue;let db;try{db=await new Promise((res,rej)=>{const r=indexedDB.open(meta.name);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});for(const store of db.objectStoreNames){let count=0;try{const tx=db.transaction(store,'readonly');count=await req(tx.objectStore(store).count())}catch{}out.idb.push({db:db.name,version:db.version,store,count})}db.close()}catch{try{db?.close()}catch{}}}}catch{}
  try{for(const name of await caches.keys()){let count=0;try{count=(await (await caches.open(name)).keys()).length}catch{}out.cache.push({name,count})}}catch{}
  try{if(navigator.serviceWorker)for(const r of await navigator.serviceWorker.getRegistrations())out.serviceWorkers.push({scope:r.scope,active:r.active?.scriptURL||'',waiting:r.waiting?.scriptURL||'',installing:r.installing?.scriptURL||''})}catch{}
  try{const e=await navigator.storage?.estimate?.(),persisted=await navigator.storage?.persisted?.();out.storage={usage:e?.usage||0,quota:e?.quota||0,persisted:!!persisted}}catch{}
  return out;
}


function itemsFor(kind){
  if(!scan)return[];
  if(kind==='cookies')return scan.cookies.map(c=>({id:cookieId(c),title:c.name||'(empty name)',sub:`${c.domain}${c.path||'/'}${c.partitionKey?.topLevelSite?` · ${c.partitionKey.topLevelSite}`:''}`,tag:[c.httpOnly?'HttpOnly':'',c.secure?'Secure':'',c.session?'Session':'Persistent'].filter(Boolean).join(' · ')}));
  const rows=[];
  for(const f of scan.frames){
    if(kind==='local'||kind==='session')for(const x of f[kind])rows.push({id:itemId(kind,f.origin,x.key),title:x.key,sub:f.origin,tag:humanBytes(x.bytes)});
    if(kind==='idb')for(const x of f.idb)rows.push({id:itemId(kind,f.origin,x.db,x.store),title:`${x.db} / ${x.store}`,sub:f.origin,tag:`${x.count} rows`});
    if(kind==='cache')for(const x of f.cache)rows.push({id:itemId(kind,f.origin,x.name),title:x.name,sub:f.origin,tag:`${x.count} requests`});
  }
  return rows;
}

function resetSelections(){for(const k of KINDS){selected[k].clear();for(const x of itemsFor(k))selected[k].add(x.id)}updateScopeUI()}
function setCaptureRecipe(recipe){captureRecipe=['session','prefs','workspace','continuity','full','custom'].includes(recipe)?recipe:'full';$$('[data-capture-recipe]').forEach(b=>b.classList.toggle('active',b.dataset.captureRecipe===captureRecipe));ui.captureRecipeHint.textContent={session:'Auth/session · explicit',prefs:'Stable UI + model prefs',workspace:'Project/workspace state',continuity:'Drafts + continuity · no auth',full:'Everything selected',custom:'Granular custom'}[captureRecipe]||'Custom'}
function applyCaptureRecipe(recipe=captureRecipe,silent=false){if(!scan)return;setCaptureRecipe(recipe);applyingRecipe=true;try{const D=globalThis.KyronDataClassifier,on=k=>{const el=$(`[data-kind="${k}"]`);if(el)el.checked=true},off=k=>{const el=$(`[data-kind="${k}"]`);if(el)el.checked=false},all=k=>{selected[k].clear();for(const x of itemsFor(k))selected[k].add(x.id)},none=k=>selected[k].clear(),pickClass=(k,classes)=>{selected[k].clear();for(const x of itemsFor(k))if(classes.includes(D?.classifyStorageKey?.(x.title)||'stable'))selected[k].add(x.id)};if(recipe==='full'){for(const k of KINDS){on(k);all(k)}}else if(recipe==='custom'){}else if(recipe==='prefs'){for(const k of KINDS){off(k);none(k)}for(const k of['local','session'])on(k);pickClass('local',['preferences','stable']);pickClass('session',['preferences','stable'])}else if(recipe==='workspace'){for(const k of KINDS){off(k);none(k)}for(const k of['local','session','idb'])on(k);pickClass('local',['preferences','stable','workspace']);pickClass('session',['preferences','stable','workspace']);all('idb')}else if(recipe==='continuity'){for(const k of KINDS){off(k);none(k)}for(const k of['local','session','idb'])on(k);pickClass('local',['preferences','stable','workspace','volatile']);pickClass('session',['preferences','stable','workspace','volatile']);all('idb')}else{for(const k of KINDS){off(k);none(k)}for(const k of['cookies','local','session'])on(k);all('cookies');pickClass('local',['auth','preferences','stable']);pickClass('session',['auth','preferences','stable'])}updateScopeUI()}finally{applyingRecipe=false}if(!silent)persistPrefs()}
function markCaptureCustom(){if(applyingRecipe)return;setCaptureRecipe('custom')}
function updateScopeUI(){
  for(const k of KINDS){const all=itemsFor(k).length,pick=selected[k].size;ui[`${k}Picked`].textContent=all?`${pick}/${all}`:'0';const row=$(`[data-row-kind="${k}"]`);row?.classList.toggle('off',!kindOn(k))}
  const on=KINDS.filter(kindOn).length;ui.scopeAll.textContent=on===KINDS.length?'Clear all':'Select all';ui.captureSub.textContent='Ready to save this profile';ui.advancedSummary.textContent=`Recommended defaults${ui.encrypt.checked?' · encrypted':''}`;
}

async function scanSource(){
  hideStatus();const t=tabById(ui.source.value);if(!t)return;
  if(!gptSource||gptSource.tabId!==t.id)gptSource=await findGpt('source',{silent:true,rescan:false});
  setBusy(true);status('Scanning paired source',12,t.url);
  try{
    const wrapperOrigin=originOf(t.url),ids=[];if(isFastpassOrigin(wrapperOrigin))ids.push(0);if(gptSource?.frameId!=null&&!ids.includes(gptSource.frameId))ids.push(gptSource.frameId);
    let frames=[];for(const frameId of ids)try{const rr=await chrome.scripting.executeScript({target:{tabId:t.id,frameIds:[frameId]},func:probeFrameMeta});for(const r of rr)if(r.result?.origin&&r.result.origin!=='null'&&isSupportedOrigin(r.result.origin))frames.push({...r.result,frameId:r.frameId})}catch{}
    const cookieScope=await siteCookies(gptSource,wrapperOrigin),cookies=cookieScope.cookies,primaryOrigin=frames.find(f=>isGptOrigin(f.origin))?.origin||gptSource?.primaryOrigin||'https://chatgpt.com',hasWrapper=frames.some(f=>isFastpassOrigin(f.origin));
    scan={tabId:t.id,topOrigin:primaryOrigin,topUrl:gptSource?.primaryOrigin||'https://chatgpt.com',wrapperOrigin,frames,cookies,cookieBuckets:cookieScope.buckets,partitionKeys:cookieScope.partitionKeys,partitionKey:cookieScope.partitionKey,storeId:cookieScope.storeId,gpt:true,gptKind:gptSource?.kind||'cookie',frameId:gptSource?.frameId??null,wrapperFrameId:hasWrapper?0:null,captureFrameIds:ids};
    const distinctWrapper=hasWrapper&&wrapperOrigin!==primaryOrigin,b=cookieScope.buckets||{},fastN=b.FASTPASS_FIRST_PARTY?.length||0,gptUnN=b.GPT_UNPARTITIONED?.length||0,gptEmbN=b.GPT_EMBEDDED_PARTITION?.length||0;ui.sourceOrigin.textContent=distinctWrapper?`${primaryOrigin} + ${wrapperOrigin}`:primaryOrigin;ui.sourceFrames.textContent=gptSource?.kind==='proxy'?'Fast Chat proxy · origin-isolated':gptSource.frameId==null?(hasWrapper?'cookie-only GPT · Fast Chat wrapper':'cookie-only · direct GPT'):`${gptSource.kind} · GPT frame ${gptSource.frameId}${distinctWrapper?' · + wrapper':''}`;
    const local=frames.reduce((n,f)=>n+f.local.length,0),session=frames.reduce((n,f)=>n+f.session.length,0),idb=frames.reduce((n,f)=>n+f.idb.length,0),cache=frames.reduce((n,f)=>n+f.cache.length,0);
    ui.cookiesStat.textContent=isFastpassOrigin(wrapperOrigin)?`${cookies.length} active · ${fastN} FastPass + ${gptEmbN} embedded GPT · profile GPT ${gptUnN} isolated`:`${cookies.length} GPT cookies · unpartitioned`;
    ui.localStat.textContent=`${local} key${local===1?'':'s'}`;ui.sessionStat.textContent=`${session} key${session===1?'':'s'}`;ui.idbStat.textContent=`${idb} store${idb===1?'':'s'}`;ui.cacheStat.textContent=`${cache} bucket${cache===1?'':'s'}`;
    applyCaptureRecipe(captureRecipe,true);if(!ui.snapshotName.value.trim())autoName();await refreshSurfaceIntel();status('Origin-isolated source ready',100,`${cookies.length} active cookies · ${local+session} storage keys`);setTimeout(hideStatus,700);
  }catch(e){scan=null;status('Source scan failed',0,e.message||String(e))}finally{setBusy(false)}
}

function autoName(){const d=new Date(),stamp=d.toLocaleDateString(undefined,{month:'short',day:'2-digit'})+' '+d.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'});ui.snapshotName.value=`GPT · ${stamp}`}

function openPicker(kind){
  if(!scan)return;currentPicker=kind;const labels={cookies:'Cookies',local:'Local Storage keys',session:'Session Storage keys',idb:'IndexedDB stores',cache:'Cache buckets'};ui.pickerTitle.textContent=labels[kind];ui.pickerSearch.value='';renderPicker();ui.picker.showModal();
}
function renderPicker(){
  const q=ui.pickerSearch.value.trim().toLowerCase(),items=itemsFor(currentPicker).filter(x=>!q||`${x.title} ${x.sub} ${x.tag}`.toLowerCase().includes(q));ui.pickerList.innerHTML=items.length?items.map(x=>`<label class="picker-item"><input type="checkbox" data-pick-id="${esc(x.id)}" ${selected[currentPicker].has(x.id)?'checked':''}><span class="picker-copy"><b>${esc(x.title)}</b><small>${esc(x.sub)}</small></span><span class="picker-tag">${esc(x.tag)}</span></label>`).join(''):'<div class="empty">Nothing matches this filter.</div>';updatePickerCount();
}
function updatePickerCount(){ui.pickerCount.textContent=`${selected[currentPicker]?.size||0} of ${itemsFor(currentPicker).length} selected`}

const mapFromSelection=(kind)=>{
  const out={};for(const id of selected[kind]){const p=JSON.parse(id);if(kind==='local'||kind==='session'){const [,origin,key]=p;(out[origin]??=[]).push(key)}else if(kind==='idb'){const [,origin,db,store]=p;(out[origin]??=[]).push([db,store])}else if(kind==='cache'){const [,origin,name]=p;(out[origin]??=[]).push(name)}}return out;
};

function collectFrameV3(filter,sourceTop){
  const cleanHeaders=h=>(h||[]).filter(([k])=>!['authorization','proxy-authorization','cookie','set-cookie','x-api-key'].includes(String(k).toLowerCase()));
  const b64=buf=>{const a=new Uint8Array(buf);let s='';for(let i=0;i<a.length;i+=0x8000)s+=String.fromCharCode(...a.subarray(i,i+0x8000));return btoa(s)};
  const req=r=>new Promise((res,rej)=>{r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
  async function pack(v,seen=new WeakSet()){
    if(v===undefined)return{$t:'u'};if(typeof v==='bigint')return{$t:'bi',v:String(v)};if(typeof v==='number'&&!Number.isFinite(v))return{$t:'num',v:String(v)};if(v===null||typeof v==='string'||typeof v==='number'||typeof v==='boolean')return v;
    if(v instanceof Date)return{$t:'date',v:v.toISOString()};if(v instanceof RegExp)return{$t:'re',s:v.source,f:v.flags};if(v instanceof ArrayBuffer)return{$t:'ab',v:b64(v)};if(ArrayBuffer.isView(v))return{$t:'ta',c:v.constructor.name,v:b64(v.buffer.slice(v.byteOffset,v.byteOffset+v.byteLength))};if(v instanceof Blob)return{$t:'blob',m:v.type,v:b64(await v.arrayBuffer())};
    if(typeof v==='object'){if(seen.has(v))return{$t:'cycle'};seen.add(v);if(Array.isArray(v)){const a=[];for(const x of v)a.push(await pack(x,seen));return a}if(v instanceof Map){const a=[];for(const [k,x] of v)a.push([await pack(k,seen),await pack(x,seen)]);return{$t:'map',v:a}}if(v instanceof Set){const a=[];for(const x of v)a.push(await pack(x,seen));return{$t:'set',v:a}}const o={};for(const k of Object.keys(v))try{o[k]=await pack(v[k],seen)}catch{}return o}return{$t:'unsupported',v:String(v)};
  }
  const data={origin:location.origin,href:location.href,local:{},session:{},idb:[],cache:[]};
  return (async()=>{
    if(!filter.frames&&location.origin!==sourceTop)return{...data,skipped:true};
    if(filter.include.local)try{for(const key of filter.local[location.origin]||[])if(localStorage.getItem(key)!==null)data.local[key]=localStorage.getItem(key)}catch{}
    if(filter.include.session)try{for(const key of filter.session[location.origin]||[])if(sessionStorage.getItem(key)!==null)data.session[key]=sessionStorage.getItem(key)}catch{}
    if(filter.include.idb)try{const wanted=filter.idb[location.origin]||[],byDb=new Map();for(const [db,store] of wanted)(byDb.get(db)||byDb.set(db,[]).get(db)).push(store);for(const [dbName,stores] of byDb){let db;try{db=await new Promise((res,rej)=>{const r=indexedDB.open(dbName);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});const d={name:db.name,version:db.version,stores:[]};for(const name of stores){if(!db.objectStoreNames.contains(name))continue;const tx=db.transaction(name,'readonly'),s=tx.objectStore(name),schema={name,keyPath:s.keyPath,autoIncrement:s.autoIncrement,indexes:[]};for(const ix of s.indexNames){const x=s.index(ix);schema.indexes.push({name:x.name,keyPath:x.keyPath,unique:x.unique,multiEntry:x.multiEntry})}const [keys,vals]=await Promise.all([req(s.getAllKeys()),req(s.getAll())]);d.stores.push({...schema,keys:await pack(keys),values:await pack(vals)})}if(d.stores.length)data.idb.push(d);db.close()}catch{try{db?.close()}catch{}}}}catch{}
    if(filter.include.cache)try{for(const name of filter.cache[location.origin]||[]){try{const c=await caches.open(name),bucket={name,entries:[]};for(const r of await c.keys())try{const x=await c.match(r),body=x&&x.type!=='opaque'?b64(await x.clone().arrayBuffer()):null;bucket.entries.push({request:{url:r.url,method:r.method,headers:cleanHeaders([...r.headers.entries()])},response:x?{status:x.status,statusText:x.statusText,headers:cleanHeaders([...x.headers.entries()]),type:x.type,body}:null})}catch{}data.cache.push(bucket)}catch{}}}catch{}
    return data;
  })();
}

const concat=(...parts)=>{const n=parts.reduce((s,x)=>s+x.length,0),out=new Uint8Array(n);let o=0;for(const p of parts){out.set(p,o);o+=p.length}return out};
const gzip=async bytes=>{if(!('CompressionStream'in globalThis))return{bytes,codec:'raw'};const ab=await new Response(new Blob([bytes]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer();return{bytes:new Uint8Array(ab),codec:'gzip'}};
const gunzip=async(bytes,codec)=>codec!=='gzip'?bytes:new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
const derive=async(pass,salt,iterations=240000)=>{const base=await crypto.subtle.importKey('raw',enc.encode(pass),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])};

async function encodeV3(vault,pass=''){
  const raw=enc.encode(JSON.stringify(vault)),z=await gzip(raw);let payload=z.bytes;const header={version:3,name:vault.name,createdAt:vault.createdAt,source:vault.source,stats:vault.stats,sessionFingerprint:vault.sessionFingerprint||null,principalFingerprint:vault.principalFingerprint||null,fingerprintVersion:vault.fingerprintVersion||0,principalFingerprintVersion:vault.principalFingerprintVersion||0,codec:z.codec,encrypted:false};
  if(pass){const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12)),key=await derive(pass,salt);payload=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},key,payload));header.encrypted=true;header.kdf={name:'PBKDF2',hash:'SHA-256',iterations:240000,salt:[...salt]};header.cipher={name:'AES-GCM',iv:[...iv]}}
  const m=enc.encode(MAGIC3),h=enc.encode(JSON.stringify(header)),len=new Uint8Array(4);new DataView(len.buffer).setUint32(0,h.length,true);return{bytes:concat(m,len,h,payload),header,rawSize:raw.length};
}
function parseContainer(bytes){
  for(const [magic,version] of [[MAGIC3,3],[MAGIC2,2]]){const m=enc.encode(magic);if(bytes.length>m.length+4&&m.every((v,i)=>bytes[i]===v)){let o=m.length;const len=new DataView(bytes.buffer,bytes.byteOffset+o,4).getUint32(0,true);o+=4;const header=JSON.parse(dec.decode(bytes.slice(o,o+len)));o+=len;return{version,header,payload:bytes.slice(o),container:true}}}
  return{version:1,container:false};
}
async function decodePacked(bytes,passwordProvider=askPassword){
  const parsed=parseContainer(bytes);if(!parsed.container){const v=JSON.parse(dec.decode(bytes));if(v?.format!=='sitevault')throw new Error('Unsupported backup file.');return v}
  let payload=parsed.payload,h=parsed.header;if(h.encrypted){const pass=await passwordProvider();if(!pass)throw new Error('Password required.');const salt=new Uint8Array(h.kdf.salt),iv=new Uint8Array(h.cipher.iv),key=await derive(pass,salt,h.kdf.iterations||240000);try{payload=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv},key,payload))}catch{throw new Error('Wrong password or damaged snapshot.')}}payload=await gunzip(payload,h.codec);const v=JSON.parse(dec.decode(payload));if(v?.format!=='sitevault')throw new Error('Invalid SiteVault payload.');return v;
}

function statsOf(v){
  const fs=v.frames||[];return{cookies:v.cookies?.length||0,local:fs.reduce((n,f)=>n+Object.keys(f.local||{}).length,0),session:fs.reduce((n,f)=>n+Object.keys(f.session||{}).length,0),idb:fs.reduce((n,f)=>n+(f.idb||[]).reduce((x,d)=>x+(d.stores?.length||0),0),0),cache:fs.reduce((n,f)=>n+(f.cache||[]).length,0),frames:fs.length};
}
function continuityMeta(v){
  const frames=v?.frames||[],keys=frames.flatMap(f=>[...Object.keys(f.local||{}),...Object.keys(f.session||{})]),volatile=/(RESUME_TOKEN_STORE_KEY|conversationDrafts|integrityState|pendingSurvey|lastPageLoad|session_id|correlated-secret)/i,sensitive=/(token|secret|session|auth|credential|accountSwitchSessions|client-correlated-secret)/i,model=/(?:^|\/)(?:models|tpp-models)$|oai-last-model-config|tpp\/(?:model-view|service-tier|chat-surface-mode)/i,origins=[...new Set(frames.map(f=>f.origin).filter(Boolean))];return{schema:1,volatileKeys:keys.filter(k=>volatile.test(k)).length,sensitiveKeys:keys.filter(k=>sensitive.test(k)).length,modelKeys:keys.filter(k=>model.test(k)).length,frameCount:frames.length,originCount:origins.length,environmentMarker:(v?.cookies||[]).some(c=>c?.name==='_account_is_fedramp')?'present':'absent'};
}

async function captureSnapshot(){
  if(!scan||scan.tabId!==Number(ui.source.value))await scanSource();if(!scan)return;const include=Object.fromEntries(KINDS.map(k=>[k,kindOn(k)]));if(!Object.values(include).some(Boolean))return status('Nothing selected',0,'Enable at least one data type.');if(ui.encrypt.checked&&ui.pass.value.length<4)return status('Password too short',0,'Use at least 4 characters.');
  const t=tabById(ui.source.value),filter={include,frames:true,local:mapFromSelection('local'),session:mapFromSelection('session'),idb:mapFromSelection('idb'),cache:mapFromSelection('cache')};setBusy(true);status('Capturing paired state',15,`${scan.gptKind} · ${scan.topOrigin}`);
  try{
    let frames=[];for(const frameId of scan.captureFrameIds||[])try{const results=await chrome.scripting.executeScript({target:{tabId:t.id,frameIds:[frameId]},func:collectFrameV3,args:[filter,scan.topOrigin]});for(const r of results){const x={...r.result,frameId:r.frameId};if(x?.origin&&!x.skipped&&x.origin!=='null'&&isSupportedOrigin(x.origin))frames.push(x)}}catch{}
    status('Capturing session cookies',44,`${selected.cookies.size} selected`);let cookies=[];if(include.cookies)cookies=scan.cookies.filter(c=>selected.cookies.has(cookieId(c)));
    const sourceHost=hostOf(scan.topOrigin)||'chatgpt.com',hasWrapper=frames.some(f=>isFastpassOrigin(f.origin)),bucketCounts={FASTPASS_FIRST_PARTY:cookies.filter(c=>cookieBucket(c)==='FASTPASS_FIRST_PARTY').length,GPT_UNPARTITIONED:cookies.filter(c=>cookieBucket(c)==='GPT_UNPARTITIONED').length,GPT_EMBEDDED_PARTITION:cookies.filter(c=>cookieBucket(c)==='GPT_EMBEDDED_PARTITION').length},vault={format:'sitevault',version:7,id:uid(),name:ui.snapshotName.value.trim()||'GPT',createdAt:new Date().toISOString(),source:{title:t.title||'',url:scan.topOrigin,origin:scan.topOrigin,host:sourceHost,wrapperUrl:t.url,wrapperOrigin:scan.wrapperOrigin,gpt:true,gptKind:scan.gptKind,partitionKey:scan.partitionKey||null,partitionKeys:scan.partitionKeys||[],frameId:scan.frameId,wrapperFrameId:scan.wrapperFrameId,hasWrapper,documentId:gptSource?.documentId||null,frameUrl:gptSource?.frameUrl||'',route:gptSource?.route||null},scope:{include,frames:true,gptOnly:false,pairedContext:true,originIsolated:true,cookieBuckets:bucketCounts,selectedCounts:Object.fromEntries(KINDS.map(k=>[k,selected[k].size]))},frames,cookies};
    let liveIdentity=null;try{liveIdentity=await readLiveIdentity(t.id,scan.frameId??0)}catch{}if(liveIdentity?.loggedIn){vault.accountId=liveIdentity.accountId||null;vault.userId=liveIdentity.userId||null;vault.accountEmail=liveIdentity.email||null;Object.assign(vault.source,{accountId:vault.accountId,userId:vault.userId,accountEmail:vault.accountEmail})}vault.stats=statsOf(vault);vault.continuity=continuityMeta(vault);
    status('Compressing snapshot',68,ui.encrypt.checked?'gzip + AES-256-GCM':'gzip');
    const fp=await KyronSessionDedupe.fingerprintInfo(vault,{name:vault.name});vault.sessionFingerprint=fp.sessionFingerprint||null;vault.principalFingerprint=fp.principalFingerprint||null;vault.fingerprintVersion=3;vault.principalFingerprintVersion=4;
    const packed=await encodeV3(vault,ui.encrypt.checked?ui.pass.value:''),contentHash=await KyronSessionDedupe.contentHash(packed.bytes),index=await buildDuplicateIndex(),sameEmail=KyronSessionDedupe.emailMatch(index,vault.accountEmail),samePrincipal=KyronSessionDedupe.principalMatch(index,fp.principalFingerprint),exact=KyronSessionDedupe.duplicateOf(index,{sessionFingerprint:fp.sessionFingerprint,contentHash}),existing=sameEmail||samePrincipal||exact;
    const incoming={id:vault.id,name:vault.name,labelSource:'capture',createdAt:vault.createdAt,snapshotAt:vault.createdAt,sourceHost:vault.source.host,sourceOrigin:vault.source.origin,sourceUrl:vault.source.url,sourceWrapperOrigin:vault.source.wrapperOrigin,gptKind:vault.source.gptKind,size:packed.bytes.length,encrypted:packed.header.encrypted,stats:vault.stats,version:7,captureRecipe,surface:gptSource?.route?.space?'project':(/\/(?:f|work|workspace)(?:\/|$)/i.test(gptSource?.route?.path||'')?'work':'chat'),space:gptSource?.route?.space||'',projectId:gptSource?.route?.space||'',conversationId:gptSource?.route?.conversationId||gptSource?.route?.conversation||'',conversationRaw:gptSource?.route?.conversation||'',conversationNamespace:gptSource?.route?.namespace||'',accountName:liveIdentity?.name||null,accountEmail:liveIdentity?.email||null,accountId:liveIdentity?.accountId||null,userId:liveIdentity?.userId||null,avatarUrl:liveIdentity?.image||null,sessionFingerprint:fp.sessionFingerprint||null,sessionFingerprintVersion:3,sessionIdentityKind:fp.kind,principalFingerprint:fp.principalFingerprint||null,principalFingerprintVersion:4,samePrincipalAs:null,sessionHealth:sessionHealthFromCookies(cookies),continuity:vault.continuity,contentHash,bytes:packed.bytes.buffer.slice(packed.bytes.byteOffset,packed.bytes.byteOffset+packed.bytes.byteLength)};
    const record=existing?KyronAccountStack.mergeMeta(existing,incoming):incoming;await KyronVaultStore.put(record);selectedBackupId=record.id;
    status(existing?'Profile refreshed · no duplicate':'Origin-isolated profile saved',100,`${record.name} · ${humanBytes(record.size)} · ${vault.stats.cookies} cookies · ${vault.stats.frames} context${vault.stats.frames===1?'':'s'}${existing?' · existing name preserved':''}`);await loadRecords();switchView('vault');
  }catch(e){status('Capture failed',0,e.message||String(e))}finally{setBusy(false)}
}

function restoreFrameV3(frameData,mode,sourceTop,targetTop,recipe='full',custom=null){
  const from64=s=>{const b=atob(s),a=new Uint8Array(b.length);for(let i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return a.buffer},policy=k=>{if(recipe!=='custom')return mode;const p=custom?.policies?.[k]||'inherit';return p==='inherit'?mode:p},doKind=k=>policy(k)!=='skip'&&(recipe!=='custom'||custom?.kinds?.[k]===true);
  function unpack(v){if(!v||typeof v!=='object')return v;if(Array.isArray(v))return v.map(unpack);if(v.$t==='u')return undefined;if(v.$t==='bi')return BigInt(v.v);if(v.$t==='num')return Number(v.v);if(v.$t==='date')return new Date(v.v);if(v.$t==='re')return new RegExp(v.s,v.f);if(v.$t==='ab')return from64(v.v);if(v.$t==='ta'){const C=globalThis[v.c];return C?new C(from64(v.v)):new Uint8Array(from64(v.v))}if(v.$t==='blob')return new Blob([from64(v.v)],{type:v.m||''});if(v.$t==='map')return new Map(v.v.map(([k,x])=>[unpack(k),unpack(x)]));if(v.$t==='set')return new Set(v.v.map(unpack));const o={};for(const[k,x]of Object.entries(v))if(k!=='$t')o[k]=unpack(x);return o}
  const classify=k=>{k=String(k||'');if(/(?:RESUME_TOKEN_STORE_KEY|token|secret|credential|accountSwitchSessions|client-correlated-secret|next-auth|csrf|auth-info|sessionToken)/i.test(k))return'auth';if(/conversationDrafts/i.test(k))return'draft';if(/integrityState/i.test(k))return'integrity';if(/(?:models$|tpp-models|oai-last-model-config|model-view|service-tier|chat-surface-mode)/i.test(k))return'model';if(/(?:pendingSurvey|lastPageLoad|statsig\.session_id|turnTrace|temporary|transient)/i.test(k))return'volatile';if(/(?:chatTheme|sidebar|debugSettings|voiceLastUsed|attributions-settings|appearance|theme|recentsOrganization)/i.test(k))return'preferences';if(/(?:projects?|gizmo|workspace|pinned-items|conversation-history|snorlax-history|saves)/i.test(k))return'workspace';if(/(?:statsig|ownerDomainBackfill|loggedInUserMessageCount|lastUtm|lastSignup)/i.test(k))return'diagnostics';return'stable'},allow=k=>recipe==='full'||(recipe==='custom'?custom?.classes?.[classify(k)]===true:(recipe==='prefs'&&['stable','preferences','model'].includes(classify(k)))||(recipe==='workspace'&&['stable','preferences','model','workspace'].includes(classify(k)))||(recipe==='continuity'&&['stable','preferences','model','workspace','draft','volatile'].includes(classify(k)))||(recipe==='session'&&['auth','stable','preferences','model'].includes(classify(k))));
  const selectiveClear=(store,kind)=>{if(policy(kind)!=='replace'||!doKind(kind))return;if(recipe==='full'){store.clear();return}for(let i=store.length-1;i>=0;i--){const k=store.key(i);if(k&&allow(k))store.removeItem(k)}};
  const src=location.origin===targetTop?frameData.find(x=>x.origin===sourceTop):frameData.find(x=>x.origin===location.origin);if(!src)return{origin:location.origin,skipped:true};
  const req=r=>new Promise((res,rej)=>{r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)}),ensureDb=async b=>{let db=await new Promise((res,rej)=>{const r=indexedDB.open(b.name);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});const missing=(b.stores||[]).some(s=>!db.objectStoreNames.contains(s.name));if(!missing)return db;const next=db.version+1;db.close();return new Promise((res,rej)=>{const r=indexedDB.open(b.name,next);r.onupgradeneeded=()=>{const d=r.result;for(const s of b.stores||[])if(!d.objectStoreNames.contains(s.name)){const st=d.createObjectStore(s.name,{keyPath:s.keyPath??null,autoIncrement:!!s.autoIncrement});for(const ix of s.indexes||[])try{st.createIndex(ix.name,ix.keyPath,{unique:ix.unique,multiEntry:ix.multiEntry})}catch{}}};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})};
  return(async()=>{try{if(doKind('local')){selectiveClear(localStorage,'local');for(const[k,v]of Object.entries(src.local||{}))if(allow(k))localStorage.setItem(k,v)}}catch{}try{if(doKind('session')){selectiveClear(sessionStorage,'session');for(const[k,v]of Object.entries(src.session||{}))if(allow(k))sessionStorage.setItem(k,v)}}catch{}try{if(doKind('idb'))for(const b of src.idb||[]){let db;try{db=await ensureDb(b);const names=(b.stores||[]).map(s=>s.name).filter(n=>db.objectStoreNames.contains(n));if(names.length){const tx=db.transaction(names,'readwrite');for(const s of b.stores||[]){if(!db.objectStoreNames.contains(s.name))continue;const st=tx.objectStore(s.name);if(policy('idb')==='replace')await req(st.clear());const keys=unpack(s.keys||[]),vals=unpack(s.values||[]);for(let i=0;i<vals.length;i++)try{if(st.keyPath===null)await req(st.put(vals[i],keys[i]));else await req(st.put(vals[i]))}catch{}}await new Promise((res,rej)=>{tx.oncomplete=res;tx.onerror=()=>rej(tx.error);tx.onabort=()=>rej(tx.error)})}}finally{db?.close()}}}catch{}try{if(doKind('cache')){if(policy('cache')==='replace'&&recipe==='full')for(const name of await caches.keys())await caches.delete(name);for(const b of src.cache||[]){const c=await caches.open(b.name);if(policy('cache')==='replace')for(const q of await c.keys())await c.delete(q);for(const e of b.entries||[])try{if(!e.response||e.response.type==='opaque'||!e.response.body)continue;const body=from64(e.response.body),r=new Response(body,{status:e.response.status||200,statusText:e.response.statusText||'',headers:e.response.headers||[]}),q=new Request(e.request.url,{method:'GET',headers:e.request.headers||[]});await c.put(q,r)}catch{}}}}catch{}return{origin:location.origin,restored:true,policies:{local:policy('local'),session:policy('session'),idb:policy('idb'),cache:policy('cache')}}})();
}

const domainMatches=(host,domain)=>{domain=(domain||'').replace(/^\./,'');return host===domain||host.endsWith('.'+domain)};
async function cookieUrl(c){const path=c.path||'/',host=(c.domain||'chatgpt.com').replace(/^\./,'');return `${c.secure?'https:':'http:'}//${host}${path}`}
async function removeCookieExact(c,storeId){try{const x={url:await cookieUrl(c),name:c.name};if(storeId!==undefined)x.storeId=storeId;if(c.partitionKey)x.partitionKey=c.partitionKey;await chrome.cookies.remove(x)}catch{}}
async function clearSiteCookiesForTarget(ctx,wrapperOrigin=''){
  const scope=await siteCookies(ctx,wrapperOrigin);for(const c of scope.cookies)await removeCookieExact(c,scope.storeId);return scope;
}
function mappedEmbeddedKey(c,targetWrapperOrigin=''){
  const top=rootSite(targetWrapperOrigin);if(!top)return null;const src=c?.partitionKey||{},x={topLevelSite:top};if('hasCrossSiteAncestor' in src)x.hasCrossSiteAncestor=!!src.hasCrossSiteAncestor;else x.hasCrossSiteAncestor=true;return x;
}
const AUTH_COOKIE_RE=/^(?:fp_chatgpt_session|separatedLoggedIn|separatedUser|separatedProjectId|separatedPromptLimits|separatedPromptLimitsSig|__Secure-next-auth\.session-token(?:\.\d+)?|__Host-next-auth\.csrf-token|__Secure-next-auth\.callback-url)$/;
const SESSION_AUTH_COOKIE_RE=/^(?:fp_chatgpt_session|__Secure-next-auth\.session-token(?:\.\d+)?)$/;
const cookiePriority=c=>AUTH_COOKIE_RE.test(c?.name||'')?0:1;
async function cookieGetExact(c,storeId,partitionKey){
  const x={url:await cookieUrl(c),name:c.name};if(storeId!==undefined)x.storeId=storeId;if(partitionKey)x.partitionKey=partitionKey;
  try{return await chrome.cookies.get(x)}catch{return null}
}
async function pruneTargetCookies(ctx,wrapperOrigin,keep,classes=null){
  const scope=await siteCookies(ctx,wrapperOrigin),D=globalThis.KyronDataClassifier,allow=c=>!Array.isArray(classes)||!classes.length||classes.includes(D?.classifyCookie?.(c?.name)||'stable');let removed=0,failed=0;
  for(const c of scope.cookies||[])if(allow(c)&&!keep.has(cookieId(c)))try{await removeCookieExact(c,scope.storeId);removed++}catch{failed++}
  return{removed,failed};
}
async function verifyFastpassSession(tabId){
  try{
    const rr=await chrome.scripting.executeScript({target:{tabId:Number(tabId),frameIds:[0]},func:async()=>{
      try{const r=await fetch('/session-manager/validate',{method:'GET',credentials:'include',cache:'no-store',headers:{Accept:'*/*'}});return{ok:r.ok,status:r.status,url:r.url||location.href}}catch(e){return{ok:false,status:0,error:e?.message||String(e)}}
    }});
    return rr?.[0]?.result||{ok:false,status:0,error:'No validation result'};
  }catch(e){return{ok:false,status:0,error:e?.message||String(e)}
  }
}
async function verifyChatGptSession(tabId){
  try{
    const rr=await chrome.scripting.executeScript({target:{tabId:Number(tabId),frameIds:[0]},func:async()=>{
      try{const r=await fetch('/api/auth/session',{method:'GET',credentials:'include',cache:'no-store',headers:{Accept:'application/json'}}),j=await r.json().catch(()=>null);return{ok:r.ok,status:r.status,loggedIn:!!(j&&typeof j.accessToken==='string'&&j.accessToken.length>20&&j.user),userId:j?.user?.id||null,accountId:j?.account?.id||null}}catch(e){return{ok:false,status:0,loggedIn:false,error:e?.message||String(e)}}
    }});
    return rr?.[0]?.result||{ok:false,status:0,loggedIn:false,error:'No validation result'};
  }catch(e){return{ok:false,status:0,loggedIn:false,error:e?.message||String(e)}
  }
}

function collectAccountFrame(){
  const local={},session={};
  try{for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k!=null)local[k]=localStorage.getItem(k)}}catch{}
  try{for(let i=0;i<sessionStorage.length;i++){const k=sessionStorage.key(i);if(k!=null)session[k]=sessionStorage.getItem(k)}}catch{}
  return{origin:location.origin,href:location.href,local,session,idb:[],cache:[]};
}
async function readLiveIdentity(tabId,frameId=0){
  try{
    const rr=await chrome.scripting.executeScript({target:{tabId:Number(tabId),frameIds:[Number(frameId)||0]},func:async()=>{
      try{
        const r=await fetch('/api/auth/session',{method:'GET',credentials:'include',cache:'no-store',headers:{Accept:'application/json'}}),j=await r.json().catch(()=>null),u=j?.user||{},a=j?.account||{};
        return{ok:r.ok,status:r.status,loggedIn:!!(r.ok&&j&&u&&(j.accessToken||u.id||u.email)),name:u.name||u.display_name||null,email:u.email||null,userId:u.id||null,accountId:a.id||j?.account_id||u.account_id||null,image:u.image||u.picture||null};
      }catch(e){return{ok:false,status:0,loggedIn:false,error:e?.message||String(e)}}
    }});
    return rr?.[0]?.result||{ok:false,status:0,loggedIn:false,error:'No session result'};
  }catch(e){return{ok:false,status:0,loggedIn:false,error:e?.message||String(e)}}
}
const normAccount=KyronAccountStack.norm,sameAccount=KyronAccountStack.same,accountInitials=KyronAccountStack.initials,accountTitle=KyronAccountStack.title,accountLabel=KyronAccountStack.label,preservedAccountLabel=KyronAccountStack.preserveLabel;
async function preserveCurrentAccount(tab,gctx,selectedMeta){
  if(!tab||!gctx?.tabId||gctx.frameId==null||!isGptOrigin(gctx.primaryOrigin||'https://chatgpt.com'))return null;
  const identity=await readLiveIdentity(tab.id,gctx.frameId);if(!identity.loggedIn||sameAccount(identity,selectedMeta))return null;
  const rr=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[gctx.frameId]},func:collectAccountFrame}),frame=rr?.[0]?.result;if(!frame?.origin)return null;
  const scope=await siteCookies(gctx,originOf(tab.url)),cookies=(scope.cookies||[]).filter(c=>isRestorableCookie(c));if(!cookies.length&&!Object.keys(frame.local||{}).length&&!Object.keys(frame.session||{}).length)return null;
  const liveFp=await KyronSessionDedupe.fingerprintInfo({},{accountId:identity.accountId,userId:identity.userId,accountEmail:identity.email}),existing=KyronSessionDedupe.emailMatch(records,identity.email)||records.find(r=>sameAccount(identity,r))||KyronSessionDedupe.principalMatch(records,liveFp.principalFingerprint),id=existing?.id||uid(),createdAt=existing?.createdAt||new Date().toISOString(),name=preservedAccountLabel(existing,identity),vault={format:'sitevault',version:7,id,name,createdAt,source:{title:tab.title||name,url:gctx.primaryOrigin||'https://chatgpt.com',origin:gctx.primaryOrigin||frame.origin,host:hostOf(gctx.primaryOrigin||frame.origin)||'chatgpt.com',wrapperUrl:tab.url,wrapperOrigin:originOf(tab.url),gpt:true,gptKind:gctx.kind||'direct',frameId:gctx.frameId,hasWrapper:false,accountId:identity.accountId||null,userId:identity.userId||null,accountEmail:identity.email||null},scope:{include:{cookies:true,local:true,session:true,idb:false,cache:false},frames:true,gptOnly:true,pairedContext:true,originIsolated:true,accountCapsule:true},frames:[frame],cookies};
  vault.stats=statsOf(vault);vault.continuity=continuityMeta(vault);const fp=await KyronSessionDedupe.fingerprintInfo(vault,{accountId:identity.accountId,userId:identity.userId,accountEmail:identity.email});vault.sessionFingerprint=fp.sessionFingerprint||null;vault.principalFingerprint=fp.principalFingerprint||null;vault.fingerprintVersion=3;vault.principalFingerprintVersion=4;const packed=await encodeV3(vault,''),contentHash=await KyronSessionDedupe.contentHash(packed.bytes),incoming={id,name,labelSource:existing?.labelSource||'account',createdAt,snapshotAt:new Date().toISOString(),updatedAt:new Date().toISOString(),sourceHost:'chatgpt.com',sourceOrigin:vault.source.origin,sourceUrl:vault.source.url,sourceWrapperOrigin:vault.source.wrapperOrigin,gptKind:vault.source.gptKind,size:packed.bytes.length,encrypted:false,stats:vault.stats,version:7,capsule:true,accountName:identity.name||name,accountEmail:identity.email||null,accountId:identity.accountId||null,userId:identity.userId||null,avatarUrl:identity.image||null,sessionFingerprint:fp.sessionFingerprint||null,sessionFingerprintVersion:3,sessionIdentityKind:fp.kind,principalFingerprint:fp.principalFingerprint||liveFp.principalFingerprint||null,principalFingerprintVersion:4,sessionHealth:sessionHealthFromCookies(cookies),continuity:vault.continuity,contentHash,bytes:packed.bytes.buffer.slice(packed.bytes.byteOffset,packed.bytes.byteOffset+packed.bytes.byteLength)},record=existing?KyronAccountStack.mergeMeta(existing,incoming):incoming;
  await KyronVaultStore.put(record);records=await KyronVaultStore.list();return record;
}
async function tagSelectedFromLiveSession(tab,gctx){
  if(!selectedBackupId||!tab||gctx?.frameId==null)return null;const identity=await readLiveIdentity(tab.id,gctx.frameId);if(!identity.loggedIn)return null;
  await KyronVaultStore.updateMeta(selectedBackupId,{accountName:identity.name||null,accountEmail:identity.email||null,accountId:identity.accountId||null,userId:identity.userId||null,avatarUrl:identity.image||null,lastRestoredAt:new Date().toISOString()});records=await KyronVaultStore.list();return identity;
}
async function renderLiveAccountCard(){
  if(!ui.liveAccountCard)return;const t=tabById(ui.target.value);if(!t){ui.liveAccountCard.innerHTML='<span class="account-avatar muted">?</span><span class="live-account-copy"><b>No target tab</b><small>Select where you want to restore.</small></span>';return}
  if(!isGptStorageHost(hostOf(t.url))){ui.liveAccountCard.innerHTML=`<span class="account-avatar muted">↗</span><span class="live-account-copy"><b>Manual restore target</b><small>${esc(contextLabel())} · this tab will jump to chatgpt.com only after you click Restore.</small></span><span class="manual-pill">MANUAL</span>`;return}
  try{let g=gptTarget?.tabId===t.id?gptTarget:await findGpt('target',{silent:true});const x=await readLiveIdentity(t.id,g?.frameId??0),name=x.loggedIn?accountTitle(x):'ChatGPT not signed in',sub=x.loggedIn?(x.email||`${contextLabel()} session`):`${contextLabel()} · selected tab`;ui.liveAccountCard.innerHTML=`<span class="account-avatar">${esc(accountInitials(name,x.email))}</span><span class="live-account-copy"><b>${esc(name)}</b><small>${esc(sub)}</small></span><span class="current-pill">CURRENT</span>`;const intel=await probeSurfaceIntel(t,g);if(ui.accountStackIntel)ui.accountStackIntel.textContent=intel?`Native switch stack ${intel.nativeAccounts} · drafts ${intel.drafts} · ${intel.surface}${intel.modelStores?` · ${intel.modelStores} model-state stores`:''}`:'Native stack metadata unavailable'}catch{ui.liveAccountCard.innerHTML='<span class="account-avatar muted">?</span><span class="live-account-copy"><b>Current account unavailable</b><small>Restore is still manual.</small></span><span class="manual-pill">MANUAL</span>';if(ui.accountStackIntel)ui.accountStackIntel.textContent='Native stack metadata unavailable'}
}
const BRIDGE_AUTH_RE=/^__Secure-next-auth\.session-token(?:\.(\d+))?$/;
const bridgeAuthCookies=vault=>(vault.cookies||[]).filter(c=>(c.sitevaultBucket||cookieBucket(c))==='FASTPASS_FIRST_PARTY'&&isFastpassHost(c.domain)&&BRIDGE_AUTH_RE.test(c.name||''));
function orderedBridgeAuth(rows){
  const base=rows.find(c=>c.name==='__Secure-next-auth.session-token'),chunkRows=rows.filter(c=>/\.\d+$/.test(c.name||''));if(base&&chunkRows.length)throw new Error('FastPass auth snapshot is ambiguous: both base and chunked next-auth cookies are present.');if(base)return[base];
  const chunks=chunkRows.map(c=>{const m=(c.name||'').match(BRIDGE_AUTH_RE);return m&&m[1]!=null?[Number(m[1]),c]:null}).filter(Boolean).sort((a,b)=>a[0]-b[0]);
  if(!chunks.length)throw new Error('FastPass snapshot has no transferable next-auth session cookie.');
  for(let i=0;i<chunks.length;i++)if(chunks[i][0]!==i)throw new Error(`FastPass session cookie chunks are incomplete: expected .${i}, found .${chunks[i][0]}.`);
  return chunks.map(x=>x[1]);
}
async function directGptAuthCookies(storeId){
  const out=new Map();for(const url of ['https://chatgpt.com/','https://www.chatgpt.com/']){const q={url};if(storeId!==undefined)q.storeId=storeId;try{for(const c of await chrome.cookies.getAll(q))if(isGptCookieHost(c.domain)&&!c.partitionKey&&BRIDGE_AUTH_RE.test(c.name||''))out.set(cookieId(c),c)}catch{}}
  return[...out.values()];
}
async function removeDirectGptAuth(storeId){const rows=await directGptAuthCookies(storeId);for(const c of rows)await removeCookieExact(c,storeId);return rows}
async function setMappedGptAuth(c,storeId){
  const x={url:'https://chatgpt.com/',name:c.name,value:c.value,path:'/',secure:true,httpOnly:true,domain:'.chatgpt.com'};if(c.sameSite&&c.sameSite!=='unspecified')x.sameSite=c.sameSite;if(storeId!==undefined)x.storeId=storeId;if(!c.session&&c.expirationDate>Date.now()/1000)x.expirationDate=c.expirationDate;return chrome.cookies.set(x)
}
async function restoreOriginalGptAuth(rows,storeId){
  await removeDirectGptAuth(storeId);let ok=0;for(const c of rows)try{const x={url:await cookieUrl(c),name:c.name,value:c.value,path:c.path||'/',secure:!!c.secure,httpOnly:!!c.httpOnly};if(c.sameSite&&c.sameSite!=='unspecified')x.sameSite=c.sameSite;if(storeId!==undefined)x.storeId=storeId;if(c.domain&&!c.hostOnly)x.domain=c.domain;if(!c.session&&c.expirationDate>Date.now()/1000)x.expirationDate=c.expirationDate;if(await chrome.cookies.set(x))ok++}catch{}return ok
}
async function bridgeFastpassSessionToGpt(vault,targetCtx){
  const storeId=await cookieStoreForTab(targetCtx?.tabId),source=orderedBridgeAuth(bridgeAuthCookies(vault)),previous=await removeDirectGptAuth(storeId),out={mapped:0,verified:0,rolledBack:false,previous:previous.length,names:source.map(c=>c.name)};
  try{
    for(const c of source){if(!c.session&&c.expirationDate&&c.expirationDate<=Date.now()/1000)throw new Error(`FastPass auth cookie expired: ${c.name}`);const set=await setMappedGptAuth(c,storeId);if(!set)throw new Error(`Chrome refused mapped auth cookie: ${c.name}`);out.mapped++;const q={url:'https://chatgpt.com/',name:c.name};if(storeId!==undefined)q.storeId=storeId;const got=await chrome.cookies.get(q);if(got?.value!==c.value)throw new Error(`Mapped auth cookie verification failed: ${c.name}`);out.verified++}
    const live=await verifyChatGptSession(targetCtx.tabId);out.live=live;if(!live.ok||!live.loggedIn)throw new Error(`ChatGPT rejected bridged session (${live.status||'no status'}).`);return out
  }catch(e){out.rolledBack=true;out.rollbackRestored=await restoreOriginalGptAuth(previous,storeId);throw Object.assign(new Error(`${e.message||e} Previous ChatGPT auth was restored (${out.rollbackRestored}/${previous.length}).`),{bridgeResult:out})}
}
async function restoreCookies(vault,targetCtx,targetWrapperOrigin=''){
  const targetStoreId=await cookieStoreForTab(targetCtx?.tabId),targetProxy=isFastpassOrigin(targetWrapperOrigin),out={ok:0,verified:0,mismatch:0,expired:0,skip:0,fail:0,pruned:0,pruneFail:0,buckets:{FASTPASS_FIRST_PARTY:0,GPT_UNPARTITIONED:0,GPT_EMBEDDED_PARTITION:0}},keep=new Set(),now=Date.now()/1000;
  const rows=(vault.cookies||[]).slice().sort((a,b)=>cookiePriority(a)-cookiePriority(b));
  for(const c of rows)try{
    if(!isRestorableCookie(c)){out.skip++;continue}
    const bucket=c.sitevaultBucket||cookieBucket(c),allowed=targetProxy?(bucket==='FASTPASS_FIRST_PARTY'||bucket==='GPT_EMBEDDED_PARTITION'):bucket==='GPT_UNPARTITIONED';if(!allowed){out.skip++;continue}
    if(!c.session&&c.expirationDate&&c.expirationDate<=now){out.expired++;continue}
    const x={url:await cookieUrl(c),name:c.name,value:c.value,path:c.path||'/',secure:!!c.secure,httpOnly:!!c.httpOnly};
    if(c.sameSite&&c.sameSite!=='unspecified')x.sameSite=c.sameSite;if(targetStoreId!==undefined)x.storeId=targetStoreId;if(c.domain&&!c.hostOnly)x.domain=c.domain;if(!c.session&&c.expirationDate)x.expirationDate=c.expirationDate;
    let pk=null;if(bucket==='GPT_EMBEDDED_PARTITION'){pk=mappedEmbeddedKey(c,targetWrapperOrigin);if(!pk){out.skip++;continue}x.partitionKey=pk}
    const set=await chrome.cookies.set(x);if(!set){out.fail++;continue}
    out.ok++;out.buckets[bucket]=(out.buckets[bucket]||0)+1;keep.add(cookieId(set));
    const got=await cookieGetExact(set,targetStoreId,pk);if(got&&got.value===c.value){out.verified++;keep.add(cookieId(got))}else out.mismatch++;
  }catch{out.fail++}
  if(restoreKindMode('cookies')==='replace'){const q=await pruneTargetCookies(targetCtx,targetWrapperOrigin,keep,vault.scope?.restoreCookieClasses||null);out.pruned=q.removed;out.pruneFail=q.failed}
  return{...out,targetProxy};
}

function normalizeRestoreCustom(x={}){const d=globalThis.KyronPopupPrefs?.RESTORE_DEF||{kinds:{cookies:false,local:true,session:true,idb:true,cache:false},classes:{stable:true,preferences:true,model:true,workspace:true,draft:true,volatile:false,integrity:false,auth:false,diagnostics:false},cookieClasses:{auth:true,stable:true,ephemeral:false},policies:{cookies:'inherit',local:'inherit',session:'inherit',idb:'inherit',cache:'inherit'}},map=(src,def)=>Object.fromEntries(Object.keys(def).map(k=>[k,src?.[k]===undefined?def[k]:!!src[k]])),pol=(src,def)=>Object.fromEntries(Object.keys(def).map(k=>[k,['inherit','merge','replace','skip'].includes(src?.[k])?src[k]:def[k]]));return{kinds:map(x.kinds,d.kinds),classes:map(x.classes,d.classes),cookieClasses:map(x.cookieClasses,d.cookieClasses),policies:pol(x.policies,d.policies)}}
function paintRestoreCustom(){restoreCustom=normalizeRestoreCustom(restoreCustom);for(const el of $$('[data-restore-kind]'))el.checked=!!restoreCustom.kinds[el.dataset.restoreKind];for(const el of $$('[data-restore-class]'))el.checked=!!restoreCustom.classes[el.dataset.restoreClass];for(const el of $$('[data-restore-cookie-class]'))el.checked=!!restoreCustom.cookieClasses[el.dataset.restoreCookieClass];for(const el of $$('[data-restore-policy]'))el.value=restoreCustom.policies[el.dataset.restorePolicy]||'inherit';if(ui.restoreCustomBox)ui.restoreCustomBox.hidden=restoreRecipe!=='custom'}
function readRestoreCustom(){const x=normalizeRestoreCustom(restoreCustom);for(const el of $$('[data-restore-kind]'))x.kinds[el.dataset.restoreKind]=!!el.checked;for(const el of $$('[data-restore-class]'))x.classes[el.dataset.restoreClass]=!!el.checked;for(const el of $$('[data-restore-cookie-class]'))x.cookieClasses[el.dataset.restoreCookieClass]=!!el.checked;for(const el of $$('[data-restore-policy]'))x.policies[el.dataset.restorePolicy]=el.value;return x}
function restoreKindMode(kind,custom=restoreCustom,base=restoreMode){if(restoreRecipe!=='custom')return base;const p=custom?.policies?.[kind]||'inherit';return p==='inherit'?base:p}
function restoreRecipeInfo(recipe=restoreRecipe){return{prefs:['Surface + model prefs','Stable UI preferences + model/surface state only; no cookies, drafts, auth, integrity, IDB or Cache.'],workspace:['Workspace','Preferences + model + workspace Local/Session and IndexedDB; no cookies, drafts, integrity or Cache.'],continuity:['Continuity','Workspace plus drafts + non-auth volatile state and IndexedDB; integrity/auth remain excluded.'],session:['Session / Auth core','Auth-class cookies plus auth/supporting stable preference/model Local/Session; no drafts, integrity, IDB or Cache.'],full:['Full snapshot','All selected snapshot data; highest continuity and overwrite risk.'],custom:['Custom restore matrix','Choose kinds, storage classes, cookie classes and per-kind Merge/Replace/Skip policy.']}[recipe]||['Full snapshot','Restores all selected snapshot data.']}
function filterVaultForRestore(vault,recipe=restoreRecipe,custom=restoreCustom){const D=globalThis.KyronDataClassifier,customMode=recipe==='custom',classAllowed=k=>customMode?custom?.classes?.[D?.classifyStorageKey?.(k)||'stable']===true:(D?.allowClass?D.allowClass(recipe,D.classifyStorageKey(k)):true),policy=k=>customMode?(custom?.policies?.[k]||'inherit'):'inherit',kind=k=>(!customMode||custom?.kinds?.[k]===true)&&policy(k)!=='skip',cookieClasses=recipe==='session'?['auth']:customMode?Object.keys(custom?.cookieClasses||{}).filter(k=>custom.cookieClasses[k]):null,cookieAllowed=c=>!cookieClasses||cookieClasses.includes(D?.classifyCookie?.(c?.name)||'stable'),keepIdb=customMode?kind('idb'):recipe==='workspace'||recipe==='continuity'||recipe==='full',keepCache=customMode?kind('cache'):recipe==='full',keepCookies=customMode?kind('cookies'):recipe==='session'||recipe==='full';vault.frames=(vault.frames||[]).filter(f=>isSupportedOrigin(f.origin)).map(f=>({...f,local:kind('local')?Object.fromEntries(Object.entries(f.local||{}).filter(([k])=>classAllowed(k))):{},session:kind('session')?Object.fromEntries(Object.entries(f.session||{}).filter(([k])=>classAllowed(k))):{},idb:keepIdb?(f.idb||[]):[],cache:keepCache?(f.cache||[]):[]}));vault.cookies=keepCookies?(vault.cookies||[]).filter(c=>isRestorableCookie(c)&&cookieAllowed(c)):[];vault.scope={...(vault.scope||{}),pairedContext:true,restoreRecipe:recipe,restoreCustom:customMode?custom:null,restorePolicies:customMode?custom?.policies:null,restoreCookies:keepCookies,restoreIdb:keepIdb,restoreCache:keepCache,restoreCookieClasses:cookieClasses};return vault}
async function getSelectedVault(){const meta=records.find(x=>x.id===selectedBackupId);if(!meta)throw new Error('Select a snapshot first.');const r=await KyronVaultStore.get(meta.id),vault=filterVaultForRestore(await decodePacked(new Uint8Array(r.bytes),askPassword),restoreRecipe,restoreCustom);return{record:r,vault};}

async function captureRollbackFrame(tabId,frameId){
  const metaRows=await chrome.scripting.executeScript({target:{tabId:Number(tabId),frameIds:[Number(frameId)]},func:probeFrameMeta}),m=metaRows?.[0]?.result;if(!m?.origin||m.origin==='null')return null;
  const filter={include:{local:true,session:true,idb:true,cache:true},frames:true,local:{[m.origin]:(m.local||[]).map(x=>x.key)},session:{[m.origin]:(m.session||[]).map(x=>x.key)},idb:{[m.origin]:(m.idb||[]).map(x=>[x.db,x.store])},cache:{[m.origin]:(m.cache||[]).map(x=>x.name)}};
  const rows=await chrome.scripting.executeScript({target:{tabId:Number(tabId),frameIds:[Number(frameId)]},func:collectFrameV3,args:[filter,m.origin]}),frame=rows?.[0]?.result;return frame?.origin?{...frame,frameId:Number(frameId)}:null;
}
async function captureRestoreJournal(tab,gctx,targetWrapper){
  const frames=[];if(gctx?.frameId!=null){const f=await captureRollbackFrame(tab.id,gctx.frameId);if(f)frames.push(f)}
  if(isFastpassOrigin(targetWrapper)&&gctx?.frameId!==0){try{const f=await captureRollbackFrame(tab.id,0);if(f&&!frames.some(x=>x.frameId===0))frames.push(f)}catch{}}
  const scope=await siteCookies(gctx,targetWrapper),all=[...(scope.buckets?.FASTPASS_FIRST_PARTY||[]),...(scope.buckets?.GPT_UNPARTITIONED||[]),...(scope.buckets?.GPT_EMBEDDED_PARTITION||[])],seen=new Set(),cookies=[];for(const c of all){const k=cookieId(c);if(!seen.has(k)){seen.add(k);cookies.push(c)}}
  return{schema:1,tabId:tab.id,incognito:!!tab.incognito,wrapperOrigin:targetWrapper,gpt:{...gctx},storeId:scope.storeId,frames,cookies,capturedAt:Date.now()};
}
async function setCookieExact(c,storeId){
  const x={url:await cookieUrl(c),name:c.name,value:c.value,path:c.path||'/',secure:!!c.secure,httpOnly:!!c.httpOnly};if(c.sameSite&&c.sameSite!=='unspecified')x.sameSite=c.sameSite;if(storeId!==undefined)x.storeId=storeId;if(c.domain&&!c.hostOnly)x.domain=c.domain;if(!c.session&&c.expirationDate>Date.now()/1000)x.expirationDate=c.expirationDate;if(c.partitionKey)x.partitionKey=c.partitionKey;return chrome.cookies.set(x);
}
async function rollbackRestoreJournal(j){
  if(!j?.tabId)return{frames:0,cookies:0};let frameCount=0,cookieCount=0;
  for(const f of j.frames||[])try{const rows=await chrome.scripting.executeScript({target:{tabId:Number(j.tabId),frameIds:[Number(f.frameId)]},func:restoreFrameV3,args:[[f],'replace',f.origin,f.origin,'full']});if(rows?.some(x=>x.result?.restored))frameCount++}catch{}
  try{const now=await siteCookies(j.gpt,j.wrapperOrigin),all=[...(now.buckets?.FASTPASS_FIRST_PARTY||[]),...(now.buckets?.GPT_UNPARTITIONED||[]),...(now.buckets?.GPT_EMBEDDED_PARTITION||[])],seen=new Set();for(const c of all){const k=cookieId(c);if(seen.has(k))continue;seen.add(k);await removeCookieExact(c,now.storeId)}for(const c of j.cookies||[])try{if(await setCookieExact(c,j.storeId))cookieCount++}catch{}}catch{}
  return{frames:frameCount,cookies:cookieCount};
}
function vaultTouchesGptAuth(vault,targetWrapper=''){
  const targetProxy=isFastpassOrigin(targetWrapper);return (vault.cookies||[]).some(c=>{const b=c.sitevaultBucket||cookieBucket(c);return SESSION_AUTH_COOKIE_RE.test(c.name||'')&&(targetProxy?b==='FASTPASS_FIRST_PARTY'||b==='GPT_EMBEDDED_PARTITION':b==='GPT_UNPARTITIONED')});
}


async function restoreSelected(){
  let t=tabById(ui.target.value);if(!t)return;assertContextTab(t);setBusy(true);status('Opening snapshot',10,records.find(x=>x.id===selectedBackupId)?.name||'');
  try{
    const selectedMeta=records.find(x=>x.id===selectedBackupId)||null,{vault}=await getSelectedVault();t=await ensureChatGptTarget(t);if(!gptTarget||gptTarget.tabId!==t.id)gptTarget=await findGpt('target',{silent:true});status('Preserving current account',18,'Manual Account Stack · no automatic restore');const preserved=await preserveCurrentAccount(t,gptTarget,selectedMeta);if(preserved)status('Current account saved to stack',22,`${preserved.accountName||preserved.name}${preserved.accountEmail?` · ${preserved.accountEmail}`:''}`);const bridge=vault.scope?.restoreCookies!==false&&bridgeAuthCookies(vault).length>0&&cookieMode==='map'&&bridgeDirection(vault,t,gptTarget);if(!restoreRouteAllowed(vault,t,gptTarget))throw new Error(`Session route blocked after ChatGPT jump: ${sourceSessionClass(vault)} -> ${targetSessionClass(t,gptTarget)}. Use Bridge FP→GPT for a FastPass snapshot targeting direct ChatGPT.`);
    const targetGpt=gptTarget?.primaryOrigin||'https://chatgpt.com',sourceGpt=vault.source?.origin||'https://chatgpt.com',targetWrapper=originOf(t.url),sourceWrapper=vault.source?.wrapperOrigin||'',hasTargetWrapper=isFastpassOrigin(targetWrapper),hasSourceWrapper=isFastpassOrigin(sourceWrapper),journal=await captureRestoreJournal(t,gptTarget,targetWrapper),tx=globalThis.KyronRestoreTransaction;
    if(!tx?.run)throw new Error('Restore transaction module is unavailable. Reload the extension and try again.');
    const result=await tx.run({meta:{tabId:t.id,context:contextLabel(),profileId:selectedBackupId,wrapperOrigin:targetWrapper},capture:async()=>journal,rollback:rollbackRestoreJournal,onStage:stage=>{if(stage==='captured')status('Rollback journal ready',25,`${journal.frames.length} frame contexts · ${journal.cookies.length} cookies`);if(stage==='rollback')status('Rolling back target',8,'Restore validation failed · restoring previous state')},apply:async()=>{
      let gptTouched=0,wrapperTouched=0;
      if(bridge){status('Bridging FastPass producer session',48,'next-auth chunks only · wrapper cookies stay isolated');const b=await bridgeFastpassSessionToGpt(vault,gptTarget);return{bridge:true,b,gptTouched,wrapperTouched,c:null,live:b.live}}
      if(isGptOrigin(targetGpt)&&gptTarget?.frameId!=null&&(vault.frames||[]).some(f=>isGptOrigin(f.origin))){status('Restoring GPT first-party storage',36,`${sourceGpt} -> ${targetGpt}`);const rr=await chrome.scripting.executeScript({target:{tabId:t.id,frameIds:[gptTarget.frameId]},func:restoreFrameV3,args:[vault.frames||[],restoreMode,sourceGpt,targetGpt,restoreRecipe,restoreCustom]});gptTouched=rr.filter(r=>r.result?.restored).length}else status('GPT storage isolated',36,hasTargetWrapper?'FastPass target keeps GPT direct storage separate':'No GPT frame data in snapshot');
      if(hasSourceWrapper&&hasTargetWrapper&&(vault.frames||[]).some(f=>isFastpassOrigin(f.origin))){status('Restoring FastPass first-party storage',56,`${sourceWrapper} -> ${targetWrapper}`);const rr=await chrome.scripting.executeScript({target:{tabId:t.id,frameIds:[0]},func:restoreFrameV3,args:[vault.frames||[],restoreMode,sourceWrapper,targetWrapper,restoreRecipe,restoreCustom]}).catch(()=>[]);wrapperTouched=rr.filter(r=>r.result?.restored).length}
      let c={ok:0,verified:0,mismatch:0,expired:0,skip:0,fail:0,pruned:0,buckets:{}};if(vault.scope?.restoreCookies!==false){status('Restoring same-boundary cookies',74,hasTargetWrapper?'FastPass + same GPT partition':'Direct GPT only');c=await restoreCookies(vault,gptTarget,targetWrapper)}else status('Cookies excluded by restore recipe',74,restoreRecipeInfo()[0]);return{bridge:false,gptTouched,wrapperTouched,c,live:null};
    },validate:async out=>{
      if(out.bridge)return !!(out.b?.live?.ok&&out.b?.live?.loggedIn);
      if(hasTargetWrapper){status('Validating restored FastPass session',90,`${out.c?.verified||0}/${out.c?.ok||0} cookies verified`);out.live=await verifyFastpassSession(t.id);if(out.live.status===401||out.live.status===403)return false;return out.live.ok||out.live.status===0}
      if(vaultTouchesGptAuth(vault,targetWrapper)){status('Validating restored ChatGPT session',90,`${out.c?.verified||0}/${out.c?.ok||0} cookies verified`);out.live=await verifyChatGptSession(t.id);return !!(out.live.ok&&out.live.loggedIn)}
      return true;
    }}),out=result.result;
    if(out.bridge){await tagSelectedFromLiveSession(t,gptTarget);status('Bridge verified by ChatGPT',100,`${out.b.verified}/${out.b.mapped} auth chunks · /api/auth/session ${out.b.live.status} · transaction committed`);setTimeout(()=>chrome.tabs.reload(t.id),350);return}
    const c=out.c,bits=Object.entries(c.buckets||{}).filter(([,n])=>n).map(([k,n])=>`${n} ${k.replace(/_/g,' ')}`).join(' · '),verifyText=`${c.verified}/${c.ok} cookies verified${c.mismatch?` · ${c.mismatch} mismatch`:''}${c.expired?` · ${c.expired} expired`:''}${restoreKindMode('cookies')==='replace'?` · ${c.pruned} stale pruned`:''}`,sessionText=hasTargetWrapper?(out.live?.ok?` · FastPass validate ${out.live.status}`:(out.live?.status?` · validate ${out.live.status}`:' · validate unavailable')):(out.live?.loggedIn?` · ChatGPT validate ${out.live.status}`:'');
    await tagSelectedFromLiveSession(t,gptTarget);status('Restore complete',100,`${bits||`${c.ok} cookies`} · ${verifyText} · ${out.gptTouched} GPT storage · ${out.wrapperTouched} FastPass storage${sessionText}${c.skip?` · ${c.skip} isolated`:''}${c.fail?` · ${c.fail} failed`:''} · transaction committed`);setTimeout(()=>chrome.tabs.reload(t.id),500);
  }catch(e){status('Restore blocked',0,e.message||String(e))}finally{setBusy(false)}
}

async function previewSelected(){
  const selectedTab=tabById(ui.target.value);if(!selectedTab)return;assertContextTab(selectedTab);const willJump=!isGptStorageHost(hostOf(selectedTab.url)),t=willJump?{...selectedTab,url:'https://chatgpt.com/'}:selectedTab,previewGpt=willJump?{tabId:t.id,wrapperOrigin:'https://chatgpt.com',primaryOrigin:'https://chatgpt.com',kind:'direct',frameId:0,host:'chatgpt.com'}:gptTarget;if(!willJump&&(!gptTarget||gptTarget.tabId!==t.id))gptTarget=await findGpt('target',{silent:true});status('Building preview',18,willJump?'Restore will open chatgpt.com in this same tab/context':t.url);
  try{
    const g=willJump?previewGpt:gptTarget,{vault}=await getSelectedVault(),bridge=vault.scope?.restoreCookies!==false&&bridgeAuthCookies(vault).length>0&&cookieMode==='map'&&bridgeDirection(vault,t,g),ok=restoreRouteAllowed(vault,t,g),targetGpt=g?.primaryOrigin||'https://chatgpt.com',sourceGpt=vault.source?.origin||'https://chatgpt.com',targetWrapper=originOf(t.url),sourceWrapper=vault.source?.wrapperOrigin||'',srcGpt=vault.frames?.find(f=>isGptOrigin(f.origin))||{},srcWrap=vault.frames?.find(f=>isFastpassOrigin(f.origin))||{},calc=f=>({local:Object.keys(f.local||{}).length,session:Object.keys(f.session||{}).length,idb:(f.idb||[]).reduce((n,d)=>n+(d.stores?.length||0),0),cache:(f.cache||[]).length}),a=calc(srcGpt),b=calc(srcWrap),targetProxy=isFastpassOrigin(targetWrapper),bridgeN=bridge?bridgeAuthCookies(vault).length:0,compatible=bridge?bridgeN:(ok?(vault.cookies||[]).filter(c=>{const k=c.sitevaultBucket||cookieBucket(c);return targetProxy?(k==='FASTPASS_FIRST_PARTY'||k==='GPT_EMBEDDED_PARTITION'):k==='GPT_UNPARTITIONED'}).length:0);
    const [recipeLabel,recipeNote]=restoreRecipeInfo();ui.previewBody.innerHTML=`<div class="preview-block"><b>Restore recipe</b><span>${esc(recipeLabel)} · ${esc(recipeNote)}</span></div><div class="preview-block"><b>Browser context</b><span>${esc(contextLabel())} · ${willJump?'will navigate this same tab to chatgpt.com':'already on ChatGPT'} · opposite context untouched</span></div><div class="preview-block"><b>Session route</b><span>${esc(sourceSessionClass(vault))} -> ${esc(targetSessionClass(t,gptTarget))} · ${bridge?'BRIDGE':ok?'EXACT':'BLOCKED'}</span></div><div class="preview-block"><b>Route</b><span>GPT: ${esc(sourceGpt)} -> ${esc(targetGpt)}<br>FastPass: ${esc(sourceWrapper||'none')} -> ${esc(targetProxy?targetWrapper:'direct ChatGPT')}</span></div><div class="preview-block"><b>Cookies</b><div class="diff-row"><i>${vault.cookies?.length||0} in snapshot</i><em class="${ok?'plus':'minus'}">${compatible} ${bridge?'auth chunks bridgeable':'restorable'}</em></div></div><div class="preview-block"><b>GPT storage</b><span>${a.local} local · ${a.session} session · ${a.idb} IDB stores · ${a.cache} caches</span></div><div class="preview-block"><b>FastPass storage</b><span>${srcWrap.origin?`${b.local} local · ${b.session} session · ${b.idb} IDB stores · ${b.cache} caches`:'not present in snapshot'}</span></div><div class="preview-block"><b>Rule</b><span>${bridge?'Only FastPass __Secure-next-auth.session-token chunks are re-issued onto .chatgpt.com. fp_chatgpt_session, separated*, CSRF/callback and FastPass storage stay isolated. ChatGPT /api/auth/session must accept the mapped token or the old GPT auth is rolled back.':'Exact mode keeps origin/bucket boundaries unchanged.'}</span></div>`;ui.preview.showModal();hideStatus();
  }catch(e){status('Preview failed',0,e.message||String(e))}
}

function legacyOpenDb(){return new Promise((res,rej)=>{const r=indexedDB.open('sitevault-vault',1);r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains('backups'))db.createObjectStore('backups',{keyPath:'id'})};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
async function legacyDbGetAll(){const db=await legacyOpenDb();try{return await new Promise((res,rej)=>{const r=db.transaction('backups','readonly').objectStore('backups').getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})}finally{db.close()}}
async function migrateLegacyVaultOnce(){const key=`sitevaultVaultV2Migrated.${PRIVATE?'incognito':'normal'}`,x=await chrome.storage.local.get(key);if(x[key])return;let old=[];try{old=await legacyDbGetAll()}catch{}let moved=0;for(const r of old)try{if(r?.id&&r?.bytes&&!(await KyronVaultStore.has(r.id))){await KyronVaultStore.put(r);moved++}}catch(e){console.warn('[Kyron] legacy vault migration skipped',r?.id,e)}await chrome.storage.local.set({[key]:{schema:2,done:true,moved,at:Date.now()}});KyronVaultStore.cleanup().catch(()=>{})}

async function reconcileProfileRecords(){
  const index=await buildDuplicateIndex(),groups=[];
  for(const r of index){const email=KyronAccountStack.emailOf(r),keys=new Set([email&&`e:${email}`,r.principalFingerprint&&`p:${r.principalFingerprint}`,r.sessionFingerprint&&`s:${r.sessionFingerprint}`,r.contentHash&&`c:${r.contentHash}`].filter(Boolean));if(!keys.size)continue;const hits=groups.filter(g=>[...keys].some(k=>g.keys.has(k)));if(!hits.length)groups.push({keys,records:[r]});else{const first=hits[0];first.records.push(r);for(const k of keys)first.keys.add(k);for(const extra of hits.slice(1)){for(const k of extra.keys)first.keys.add(k);first.records.push(...extra.records);groups.splice(groups.indexOf(extra),1)}}}
  let removed=0;
  for(const {records:group} of groups){
    if(group.length<2)continue;
    const byOldest=[...group].sort((a,b)=>new Date(a.createdAt||0)-new Date(b.createdAt||0)),named=byOldest.find(r=>!KyronAccountStack.isAutoLabel(r.name)),canonical=group.find(r=>r.labelLocked||r.labelSource==='user')||named||group.find(r=>r.id===selectedBackupId)||byOldest[0],source=[...group].sort((a,b)=>new Date(b.updatedAt||b.snapshotAt||b.createdAt||0)-new Date(a.updatedAt||a.snapshotAt||a.createdAt||0))[0];
    try{
      if(source.id!==canonical.id){const full=await KyronVaultStore.get(source.id);await KyronVaultStore.put(KyronAccountStack.mergeMeta(canonical,{...source,bytes:full.bytes,canonicalizedAt:new Date().toISOString()}))}
      for(const r of group)if(r.id!==canonical.id){await KyronVaultStore.remove(r.id);removed++}
      if(group.some(r=>r.id===selectedBackupId))selectedBackupId=canonical.id;
    }catch(e){console.warn('[Kyron] profile reconciliation skipped',group.map(r=>r.id),e)}
  }
  return removed
}
async function loadRecords(){await migrateLegacyVaultOnce();records=await KyronVaultStore.list();if(!profilesReconciled){profilesReconciled=true;if(await reconcileProfileRecords())records=await KyronVaultStore.list()}ui.vaultCount.textContent=records.length;if(selectedBackupId&&!records.some(x=>x.id===selectedBackupId))selectedBackupId=records[0]?.id||null;if(!selectedBackupId&&records.length)selectedBackupId=records[0].id;renderVault()}
function recordHost(r){return r.sourceHost||hostOf(r.sourceUrl)||'unknown'}
function renderVault(){
  ui.backupList.innerHTML=KyronVaultUi.renderList({records,selectedId:selectedBackupId,query:ui.vaultSearch.value,filter:vaultFilter,sort:vaultSort,pinnedIds:[...vaultPinnedIds],esc,hostOfRecord:recordHost,ago,humanBytes,initials:accountInitials});
  const accounts=records.filter(r=>r.capsule||r.accountEmail).length,locked=records.filter(r=>r.encrypted).length,risky=records.filter(r=>+(r?.continuity?.volatileKeys||0)>0).length;ui.vaultOverview.textContent=`${records.length} saved · ${accounts} accounts · ${vaultPinnedIds.size} pinned${locked?` · ${locked} locked`:''}${risky?` · ${risky} volatile`:''}`;
  const r=records.find(x=>x.id===selectedBackupId);ui.restorePanel.hidden=!r;if(!r){if(ui.profileTags)ui.profileTags.value='';if(ui.profileNotes)ui.profileNotes.value='';return}ui.selectedName.textContent=accountLabel(r);const health=r.sessionHealth?.status?` · session ${r.sessionHealth.status}`:'',risk=+(r?.continuity?.volatileKeys||0)?` · volatile ${r.continuity.volatileKeys}`:'',env=r?.continuity?.environmentMarker==='present'?' · env marker present':'';ui.selectedMeta.textContent=`${r.accountEmail?`${r.accountEmail} · `:''}${recordHost(r)} · ${new Date(r.createdAt).toLocaleString()} · ${humanBytes(r.size||0)}${health}${risk}${env}`;ui.restoreSummary.innerHTML=Object.entries(r.stats||{}).filter(([k])=>KINDS.includes(k)).map(([k,v])=>`<span>${k}: ${v}</span>`).join('');if(ui.profileTags)ui.profileTags.value=(Array.isArray(r.tags)?r.tags:String(r.tags||'').split(',')).map(x=>String(x).trim()).filter(Boolean).join(', ');if(ui.profileNotes)ui.profileNotes.value=r.notes||'';updateMappingHint();
}
function normalizeTags(v){return[...new Set(String(v||'').split(',').map(x=>x.trim()).filter(Boolean))].slice(0,24)}
async function saveSelectedProfileMeta(){const r=records.find(x=>x.id===selectedBackupId);if(!r)return;const tags=normalizeTags(ui.profileTags?.value),notes=String(ui.profileNotes?.value||'').trim().slice(0,2000);await KyronVaultStore.updateMeta(r.id,{tags,notes,metaUpdatedAt:new Date().toISOString()});records=await KyronVaultStore.list();renderVault();status('Profile metadata saved',100,`${tags.length} tag${tags.length===1?'':'s'} · private local note`);setTimeout(hideStatus,900)}
function collectStorageShape(){const local=[],session=[];try{for(let i=0;i<localStorage.length;i++)local.push(localStorage.key(i)||'')}catch{}try{for(let i=0;i<sessionStorage.length;i++)session.push(sessionStorage.key(i)||'')}catch{}const idb=[],cache=[];return Promise.all([typeof indexedDB!=='undefined'&&typeof indexedDB.databases==='function'?indexedDB.databases().then(async ds=>{for(const d of ds||[])try{const db=await new Promise((res,rej)=>{const q=indexedDB.open(d.name);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});try{for(const n of db.objectStoreNames)idb.push(`${d.name}/${n}`)}finally{db.close()}}catch{}}).catch(()=>{}):Promise.resolve(),typeof caches!=='undefined'?caches.keys().then(x=>cache.push(...x)).catch(()=>{}):Promise.resolve()]).then(()=>({origin:location.origin,local:[...new Set(local)].sort(),session:[...new Set(session)].sort(),idb:[...new Set(idb)].sort(),cache:[...new Set(cache)].sort()}))}
function diffNames(snapshot=[],current=[]){const A=new Set(snapshot),B=new Set(current);return{missing:[...A].filter(x=>!B.has(x)),added:[...B].filter(x=>!A.has(x)),same:[...A].filter(x=>B.has(x)).length}}
async function compareSelectedWithCurrent(){const meta=records.find(x=>x.id===selectedBackupId);if(!meta)return;let t=tabById(ui.target.value)||tabById(ui.source.value);if(!t)throw new Error('Select a ChatGPT tab first.');assertContextTab(t);let g=t.id===gptTarget?.tabId?gptTarget:null;if(!g){const info=await inspectGptTab(t),ctx=pickGptContext(info,'');if(!ctx)throw new Error('No live ChatGPT document found in the selected tab.');g={tabId:t.id,wrapperOrigin:info.wrapperOrigin,primaryOrigin:ctx.origin,kind:ctx.kind,frameId:ctx.frameId}}
  status('Comparing metadata',24,'Cookie names + storage keys only');const[{vault},cookieScope,rr]=await Promise.all([getSelectedVault(),siteCookies(g,originOf(t.url)),chrome.scripting.executeScript({target:{tabId:t.id,frameIds:[g.frameId??0]},func:collectStorageShape})]);const live=rr?.[0]?.result||{local:[],session:[],idb:[],cache:[]},frame=(vault.frames||[]).find(f=>f.origin===g.primaryOrigin)||(vault.frames||[]).find(f=>isGptOrigin(f.origin))||{},snap={cookies:(vault.cookies||[]).map(c=>`${(c.domain||'').replace(/^\./,'')}/${c.name}`).sort(),local:Object.keys(frame.local||{}).sort(),session:Object.keys(frame.session||{}).sort(),idb:(frame.idb||[]).flatMap(d=>(d.stores||[]).map(st=>`${d.name}/${st.name}`)).sort(),cache:(frame.cache||[]).map(c=>c.name).sort()},cur={cookies:(cookieScope.cookies||[]).map(c=>`${(c.domain||'').replace(/^\./,'')}/${c.name}`).sort(),local:live.local||[],session:live.session||[],idb:live.idb||[],cache:live.cache||[]},rows=['cookies','local','session','idb','cache'].map(k=>[k,diffNames(snap[k],cur[k])]);ui.previewBody.innerHTML=rows.map(([k,d])=>`<div class="preview-block"><b>${esc(k.toUpperCase())}</b><span>${d.same} same · ${d.missing.length} missing from current · ${d.added.length} new in current</span>${d.missing.length?`<small>missing: ${esc(d.missing.slice(0,12).join(' · '))}${d.missing.length>12?' …':''}</small>`:''}${d.added.length?`<small>new: ${esc(d.added.slice(0,12).join(' · '))}${d.added.length>12?' …':''}</small>`:''}</div>`).join('')+'<div class="preview-block"><b>Privacy</b><span>No cookie/storage values were compared or displayed; this is a key/schema drift check.</span></div>';ui.preview.showModal();hideStatus()}

function updateMappingHint(){const r=records.find(x=>x.id===selectedBackupId),t=tabById(ui.target.value);if(!r||!t)return;const kind=gptTarget?.tabId===t.id?gptTarget.kind:'auto',srcKind=r.gptKind||'GPT',src=sessionClass(r.sourceWrapperOrigin||r.sourceOrigin||r.sourceUrl||''),dst=targetSessionClass(t,gptTarget),exact=src!=='OTHER'&&src===dst,bridge=cookieMode==='map'&&src==='FASTPASS'&&dst==='GPT',ok=exact||bridge;ui.mappingHint.textContent=bridge?'FASTPASS -> GPT · producer-session bridge':exact?`${srcKind} -> ${kind} · exact session`:`${src} -> ${dst} · choose Bridge FP→GPT`;ui.mappingHint.classList.toggle('mapping-warning',!ok);ui.restoreSub.textContent=bridge?'map next-auth → chatgpt.com + verify':!ok?'route blocked':kind==='proxy'?'FastPass first-party + same partition':kind==='embedded'?'same GPT partition only':kind==='direct'?'direct GPT first-party only':'isolated cookie scope';}

function safeName(s){return String(s||'snapshot').replace(/[\\/:*?"<>|]+/g,'_').replace(/\s+/g,' ').trim().slice(0,90)||'snapshot'}
function downloadBytes(bytes,name){const blob=new Blob([bytes],{type:'application/octet-stream'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`${safeName(name)}.sitevault`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}

async function renameSelected(){const r=records.find(x=>x.id===selectedBackupId);if(!r)return;const name=(await promptBox('Rename profile','Choose the permanent name for this profile.','Rename',{input:true,value:r.name,placeholder:'Profile name'})).trim();if(!name)return;await KyronVaultStore.updateMeta(r.id,{name,labelSource:'user',labelLocked:true,renamedAt:new Date().toISOString()});await loadRecords()}
async function exportSelected(){const meta=records.find(x=>x.id===selectedBackupId);if(!meta)return;const r=await KyronVaultStore.get(meta.id);downloadBytes(new Uint8Array(r.bytes),r.name)}
async function deleteSelected(){const r=records.find(x=>x.id===selectedBackupId);if(!r)return;const ok=await promptBox('Delete snapshot',`Remove “${r.name}” from the local vault? This cannot be undone.`,'Delete');if(!ok)return;await KyronVaultStore.remove(r.id);selectedBackupId=null;await loadRecords()}

globalThis.KyronVaultPopupBridge={
  selected:()=>selectedBackupId,
  reload:async id=>{if(id)selectedBackupId=String(id);await loadRecords();renderVault();await persistPrefs();return records.find(x=>x.id===selectedBackupId)||null},
  restore:async id=>{if(id)selectedBackupId=String(id);await loadRecords();renderVault();await persistPrefs();return restoreSelected()}
};

function importDisplayName(file){const raw=String(file?.name||'').trim(),stem=raw.replace(/\.(sitevault|json)$/i,'').trim();return stem||'Imported profile'}
async function buildDuplicateIndex(){
  const out=[];
  for(const meta of records){
    let sessionFingerprint=meta.sessionFingerprint||'',principalFingerprint=meta.principalFingerprint||'',contentHash=meta.contentHash||'',sessionFingerprintVersion=+meta.sessionFingerprintVersion||0,principalFingerprintVersion=+meta.principalFingerprintVersion||0,sessionIdentityKind=meta.sessionIdentityKind||'';
    try{
      if(principalFingerprintVersion!==4&&(meta.accountId||meta.userId||meta.accountEmail)){const mfp=await KyronSessionDedupe.fingerprintInfo({},meta);principalFingerprint=mfp.principalFingerprint||'';principalFingerprintVersion=4}
      const needFp=!meta.encrypted&&(sessionFingerprintVersion!==3||principalFingerprintVersion!==4),needHash=!contentHash;
      if(needFp||needHash){
        const r=await KyronVaultStore.get(meta.id),bytes=new Uint8Array(r.bytes);if(needHash)contentHash=await KyronSessionDedupe.contentHash(bytes);
        if(needFp){const vault=await decodePacked(bytes,async()=>null),fp=await KyronSessionDedupe.fingerprintInfo(vault,meta);sessionFingerprint=fp.sessionFingerprint;principalFingerprint=fp.principalFingerprint;sessionFingerprintVersion=3;principalFingerprintVersion=4;sessionIdentityKind=fp.kind}
        const patch={};if(contentHash!==meta.contentHash)patch.contentHash=contentHash;if(sessionFingerprint!==meta.sessionFingerprint)patch.sessionFingerprint=sessionFingerprint||null;if(principalFingerprint!==meta.principalFingerprint)patch.principalFingerprint=principalFingerprint||null;if(sessionFingerprintVersion!==meta.sessionFingerprintVersion)patch.sessionFingerprintVersion=sessionFingerprintVersion;if(principalFingerprintVersion!==meta.principalFingerprintVersion)patch.principalFingerprintVersion=principalFingerprintVersion;if(sessionIdentityKind!==meta.sessionIdentityKind)patch.sessionIdentityKind=sessionIdentityKind;if(Object.keys(patch).length)await KyronVaultStore.updateMeta(meta.id,patch)
      }
    }catch{}
    out.push({...meta,sessionFingerprint,principalFingerprint,sessionFingerprintVersion,principalFingerprintVersion,sessionIdentityKind,contentHash})
  }
  return out
}

async function importOneSnapshot(file,index){
  let bytes=new Uint8Array(await file.arrayBuffer()),parsed=parseContainer(bytes),meta,vault=null;const displayName=importDisplayName(file),contentHash=await KyronSessionDedupe.contentHash(bytes);
  if(parsed.container){meta=parsed.header;if(!meta.encrypted)try{vault=await decodePacked(bytes,async()=>null)}catch{}}else{const legacy=JSON.parse(dec.decode(bytes));if(legacy?.format!=='sitevault')throw new Error('Unsupported backup file.');legacy.name=displayName;legacy.source={...legacy.source,origin:legacy.source?.origin||originOf(legacy.source?.url),host:legacy.source?.host||hostOf(legacy.source?.url)};legacy.version=3;legacy.stats=legacy.stats||statsOf(legacy);vault=legacy;const packed=await encodeV3(legacy,'');bytes=packed.bytes;meta=packed.header}
  const fp=vault?await KyronSessionDedupe.fingerprintInfo(vault,meta):{sessionFingerprint:String(meta.sessionFingerprint||''),principalFingerprint:String(meta.principalFingerprint||''),version:+meta.fingerprintVersion||3,principalVersion:+meta.principalFingerprintVersion||0,kind:meta.sessionFingerprint?'header':'none'},sessionFingerprint=fp.sessionFingerprint,principalFingerprint=fp.principalFingerprint,source=meta.source||{},sameEmail=KyronSessionDedupe.emailMatch(index,source.accountEmail||vault?.accountEmail),samePrincipal=KyronSessionDedupe.principalMatch(index,principalFingerprint),dup=KyronSessionDedupe.duplicateOf(index,{sessionFingerprint,contentHash});if(!sameEmail&&!samePrincipal&&dup)return{duplicate:true,existing:dup,name:displayName,sessionFingerprint,contentHash};
  const id=uid(),incoming={id,name:displayName,labelSource:'import',importedFileName:String(file?.name||''),createdAt:meta.createdAt||new Date().toISOString(),snapshotAt:meta.createdAt||new Date().toISOString(),sourceHost:source.host||hostOf(source.url),sourceOrigin:source.origin||originOf(source.url),sourceUrl:source.url||'',size:bytes.length,encrypted:!!meta.encrypted,stats:meta.stats||{},gptKind:source.gptKind||null,version:meta.version||parsed.version,accountEmail:source.accountEmail||null,accountId:source.accountId||null,userId:source.userId||null,sessionFingerprint:sessionFingerprint||null,sessionFingerprintVersion:3,sessionIdentityKind:fp.kind,principalFingerprint:principalFingerprint||null,principalFingerprintVersion:fp.principalVersion||0,samePrincipalAs:null,contentHash,bytes:bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength)},record=(sameEmail||samePrincipal)?KyronAccountStack.mergeMeta(sameEmail||samePrincipal,incoming):incoming;await KyronVaultStore.put(record);const at=index.findIndex(x=>x.id===record.id);if(at>=0)index[at]={...record};else index.push(record);return{duplicate:false,updated:!!(sameEmail||samePrincipal),record};
}
async function importSnapshots(files){
  const list=[...(files||[])].filter(f=>f&&/\.(sitevault|json)$/i.test(f.name||''));if(!list.length){status('Nothing to import',0,'Select one or more .sitevault / .json profile files.');return}
  const ok=[],updated=[],duplicates=[],failed=[],index=await buildDuplicateIndex();try{for(let i=0;i<list.length;i++){const f=list[i];status('Importing profiles',Math.round(8+84*(i/list.length)),`${i+1}/${list.length} · ${f.name}`);try{const r=await importOneSnapshot(f,index);if(r.duplicate)duplicates.push({name:f.name,existing:r.existing});else if(r.updated)updated.push(r.record);else ok.push(r.record)}catch(e){failed.push({name:f.name,error:e?.message||String(e)})}}const changed=[...ok,...updated];if(changed.length){selectedBackupId=changed.at(-1).id;await loadRecords();switchView('vault')}else if(duplicates.length){selectedBackupId=duplicates.at(-1).existing?.id||selectedBackupId;await loadRecords();switchView('vault')}const bits=[`${ok.length} imported`];if(updated.length)bits.push(`${updated.length} existing profile${updated.length===1?'':'s'} refreshed`);if(duplicates.length)bits.push(`${duplicates.length} exact duplicate${duplicates.length===1?'':'s'} skipped`);if(failed.length)bits.push(`${failed.length} failed`);status(failed.length&&!changed.length&&!duplicates.length?'Import failed':'Import complete',failed.length&&!changed.length&&!duplicates.length?0:100,bits.join(' · '));if(duplicates.length)console.info('[Kyron] exact duplicate sessions skipped',duplicates.map(x=>({file:x.name,existing:x.existing?.name||x.existing?.id})));if(failed.length)console.warn('[Kyron] profile import failures',failed);setTimeout(hideStatus,failed.length?2200:1400)}finally{ui.importFile.value=''}
}

async function persistPrefs(){return KyronPopupPrefs.save({frames:true,encrypt:ui.encrypt.checked,restoreMode,restoreRecipe,restoreCustom,cookieMode,view:!ui.personaView.hidden?'persona':(!ui.boostView.hidden?'boost':(!ui.vaultView.hidden?'vault':'capture')),scopes:Object.fromEntries(KINDS.map(k=>[k,!!kindOn(k)])),advancedOpen:!ui.advanced.hidden,selectedBackupId:selectedBackupId||null,vaultSearch:ui.vaultSearch.value||'',captureRecipe,vaultSort,vaultFilter,vaultPinnedIds:[...vaultPinnedIds]})}
async function loadPrefs(){const p=await KyronPopupPrefs.load();ui.frames.checked=true;ui.frames.disabled=true;ui.encrypt.checked=!!p.encrypt;restoreMode=p.restoreMode;restoreRecipe=p.restoreRecipe||'full';restoreCustom=normalizeRestoreCustom(p.restoreCustom);if(ui.restoreRecipe)ui.restoreRecipe.value=restoreRecipe;paintRestoreCustom();const ri=restoreRecipeInfo();if(ui.restoreRecipeHint)ui.restoreRecipeHint.textContent=`${ri[0]} · ${ri[1]}`;cookieMode=p.cookieMode;captureRecipe=p.captureRecipe;vaultSort=p.vaultSort;vaultFilter=p.vaultFilter;vaultPinnedIds=new Set(p.vaultPinnedIds||[]);setCaptureRecipe(captureRecipe);ui.vaultSort.value=vaultSort;ui.vaultFilter.value=vaultFilter;if(p.scopes&&typeof p.scopes==='object')for(const k of KINDS){const el=$(`[data-kind="${k}"]`);if(el)el.checked=p.scopes[k]!==false}ui.advanced.hidden=!p.advancedOpen;ui.advancedBtn.setAttribute('aria-expanded',String(!!p.advancedOpen));selectedBackupId=p.selectedBackupId;ui.vaultSearch.value=p.vaultSearch;$$('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===restoreMode));$$('[data-cookie-mode]').forEach(b=>b.classList.toggle('active',b.dataset.cookieMode===cookieMode));ui.passRow.hidden=!ui.encrypt.checked;if(p.view==='vault')switchView('vault');else if(p.view==='boost')switchView('boost');else if(p.view==='persona')switchView('persona')}

$$('[data-view]').forEach(b=>b.addEventListener('click',()=>{switchView(b.dataset.view);persistPrefs()}));
$('#reloadTabsBtn').addEventListener('click',async()=>{await loadTabs();gptSource=gptTarget=null;await findGpt('source');await findGpt('target',{silent:true})});
$('#expandBtn').addEventListener('click',async()=>{const t=tabById(ui.source.value)||tabById(ui.target.value);if(t)try{await chrome.sidePanel.open({tabId:t.id});window.close()}catch(e){status('Could not open workspace',0,e.message)}});
ui.source.addEventListener('change',()=>{scan=null;gptSource=null;findGpt('source')});ui.target.addEventListener('change',()=>{gptTarget=null;findGpt('target').finally(()=>renderLiveAccountCard().catch(()=>{}))});$('#scanBtn').addEventListener('click',()=>findGpt('source'));$('#autoNameBtn').addEventListener('click',autoName);
ui.sourceGptFind.addEventListener('click',()=>findGpt('source'));ui.targetGptFind.addEventListener('click',()=>findGpt('target'));ui.sourceGptSearch.addEventListener('keydown',e=>{if(e.key==='Enter')findGpt('source')});ui.targetGptSearch.addEventListener('keydown',e=>{if(e.key==='Enter')findGpt('target')});
$$('[data-capture-recipe]').forEach(b=>b.addEventListener('click',()=>applyCaptureRecipe(b.dataset.captureRecipe)));$('#surfaceProbeBtn')?.addEventListener('click',()=>refreshSurfaceIntel());
$$('[data-kind]').forEach(x=>x.addEventListener('change',()=>{markCaptureCustom();updateScopeUI();persistPrefs()}));ui.scopeAll.addEventListener('click',()=>{markCaptureCustom();const all=KINDS.every(kindOn);$$('[data-kind]').forEach(x=>x.checked=!all);updateScopeUI();persistPrefs()});$$('[data-inspect]').forEach(b=>b.addEventListener('click',()=>openPicker(b.dataset.inspect)));
ui.advancedBtn.addEventListener('click',()=>{const open=ui.advanced.hidden;ui.advanced.hidden=!open;ui.advancedBtn.setAttribute('aria-expanded',String(open));persistPrefs()});ui.frames.addEventListener('change',()=>{ui.frames.checked=true;updateScopeUI();persistPrefs()});ui.encrypt.addEventListener('change',()=>{ui.passRow.hidden=!ui.encrypt.checked;updateScopeUI();persistPrefs();if(ui.encrypt.checked)setTimeout(()=>ui.pass.focus(),20)});ui.showPass.addEventListener('click',()=>{const show=ui.pass.type==='password';ui.pass.type=show?'text':'password';ui.showPass.textContent=show?'Hide':'Show'});ui.capture.addEventListener('click',captureSnapshot);

ui.pickerSearch.addEventListener('input',renderPicker);ui.pickerList.addEventListener('change',e=>{const x=e.target.closest('[data-pick-id]');if(!x)return;markCaptureCustom();x.checked?selected[currentPicker].add(x.dataset.pickId):selected[currentPicker].delete(x.dataset.pickId);updatePickerCount()});ui.pickerAll.addEventListener('click',()=>{markCaptureCustom();for(const x of itemsFor(currentPicker))selected[currentPicker].add(x.id);renderPicker()});ui.pickerNone.addEventListener('click',()=>{markCaptureCustom();selected[currentPicker].clear();renderPicker()});ui.picker.addEventListener('close',updateScopeUI);

ui.restoreRecipe?.addEventListener('change',()=>{restoreRecipe=ui.restoreRecipe.value;paintRestoreCustom();const [a,b]=restoreRecipeInfo();ui.restoreRecipeHint.textContent=`${a} · ${b}`;updateMappingHint();persistPrefs()});for(const el of $$('[data-restore-kind],[data-restore-class],[data-restore-cookie-class],[data-restore-policy]'))el.addEventListener('change',()=>{restoreCustom=readRestoreCustom();updateMappingHint();persistPrefs()});
let vaultPrefsTimer=null;ui.vaultSearch.addEventListener('input',()=>{renderVault();clearTimeout(vaultPrefsTimer);vaultPrefsTimer=setTimeout(()=>persistPrefs(),250)});ui.vaultSort.addEventListener('change',()=>{vaultSort=ui.vaultSort.value;renderVault();persistPrefs()});ui.vaultFilter.addEventListener('change',()=>{vaultFilter=ui.vaultFilter.value;renderVault();persistPrefs()});ui.backupList.addEventListener('click',e=>{const pin=e.target.closest('[data-pin-id]');if(pin){e.preventDefault();e.stopPropagation();const id=pin.dataset.pinId;vaultPinnedIds.has(id)?vaultPinnedIds.delete(id):vaultPinnedIds.add(id);renderVault();persistPrefs();return}const a=e.target.closest('[data-backup-id]');if(!a)return;selectedBackupId=a.dataset.backupId;renderVault();persistPrefs()});const importDrop=$('#importDrop');$('#importBtn').addEventListener('click',()=>ui.importFile.click());importDrop?.addEventListener('click',()=>ui.importFile.click());ui.importFile.addEventListener('change',()=>ui.importFile.files?.length&&importSnapshots(ui.importFile.files));for(const ev of ['dragenter','dragover'])importDrop?.addEventListener(ev,e=>{e.preventDefault();e.stopPropagation();importDrop.classList.add('dragging')});for(const ev of ['dragleave','drop'])importDrop?.addEventListener(ev,e=>{e.preventDefault();e.stopPropagation();importDrop.classList.remove('dragging')});importDrop?.addEventListener('drop',e=>e.dataTransfer?.files?.length&&importSnapshots(e.dataTransfer.files));$('#renameBtn').addEventListener('click',renameSelected);$('#exportBtn').addEventListener('click',exportSelected);$('#deleteBtn').addEventListener('click',deleteSelected);$('#previewBtn').addEventListener('click',previewSelected);$('#restoreBtn').addEventListener('click',restoreSelected);ui.saveProfileMeta?.addEventListener('click',()=>saveSelectedProfileMeta().catch(e=>status('Metadata save failed',0,e.message||String(e))));ui.compareProfileBtn?.addEventListener('click',()=>compareSelectedWithCurrent().catch(e=>status('Compare failed',0,e.message||String(e))));
$$('[data-mode]').forEach(b=>b.addEventListener('click',()=>{restoreMode=b.dataset.mode;$$('[data-mode]').forEach(x=>x.classList.toggle('active',x===b));persistPrefs()}));$$('[data-cookie-mode]').forEach(b=>b.addEventListener('click',()=>{cookieMode=b.dataset.cookieMode;$$('[data-cookie-mode]').forEach(x=>x.classList.toggle('active',x===b));updateMappingHint();persistPrefs()}));

(async()=>{try{await loadPrefs();ui.frames.checked=true;await loadTabs();await loadRecords();updateScopeUI();await findGpt('target',{silent:true});await renderLiveAccountCard();if(!ui.vaultView.hidden&&records.length)renderVault();else await findGpt('source',{silent:true})}catch(e){status('SiteVault could not start',0,e.message||String(e))}})();

try{ui.frames.checked=true;ui.frames.disabled=true}catch{}
