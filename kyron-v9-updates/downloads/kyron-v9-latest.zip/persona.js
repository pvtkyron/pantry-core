(()=>{
  const C=globalThis.KyronPersonaCore;
  if(!C)return;
  const $=s=>document.querySelector(s),KEY='kyronPersonality',UIKEY='kyronPersonaUi',LASTKEY='kyronPersonaLast';
  const E={
    enabled:$('#personaEnabled'),reasoningLock:$('#personaReasoningLock'),reasoningLevel:$('#personaReasoningLevel'),answerLength:$('#personaAnswerLength'),hardTaskProtocol:$('#personaHardTaskProtocol'),protocolScope:$('#personaProtocolScope'),diligenceEnabled:$('#personaDiligenceEnabled'),diligenceLevel:$('#personaDiligenceLevel'),diligenceMinutes:$('#personaDiligenceMinutes'),diligenceVerify:$('#personaDiligenceVerify'),diligenceEdgeCases:$('#personaDiligenceEdgeCases'),diligenceAlternatives:$('#personaDiligenceAlternatives'),diligenceSources:$('#personaDiligenceSources'),diligenceComplete:$('#personaDiligenceComplete'),diligenceUseTools:$('#personaDiligenceUseTools'),playbookCode:$('#personaPlaybookCode'),playbookResearch:$('#personaPlaybookResearch'),playbookFormal:$('#personaPlaybookFormal'),playbookCasual:$('#personaPlaybookCasual'),playbookRoleplay:$('#personaPlaybookRoleplay'),exactAmbiguity:$('#personaExactAmbiguity'),regressionPass:$('#personaRegressionPass'),loadJessica:$('#personaLoadJessica'),text:$('#personaText'),userContext:$('#personaUserContext'),userContextChars:$('#personaUserContextChars'),preset:$('#personaPreset'),presetNote:$('#personaPresetNote'),strategy:$('#personaStrategy'),strategyHint:$('#personaStrategyHint'),strategyBadge:$('#personaStrategyBadge'),frequency:$('#personaFrequency'),policyDensity:$('#personaPolicyDensity'),hide:$('#personaHideHistory'),historyResponseSanitize:$('#personaHistoryResponseSanitize'),task:$('#personaTaskAdaptive'),taskStrength:$('#personaTaskAdaptiveStrength'),taskStrengthOut:$('#personaTaskAdaptiveStrengthOut'),suppliedProfile:$('#personaSuppliedProfile'),intent:$('#personaIntentGuard'),intentText:$('#personaIntentText'),examplesEnabled:$('#personaExamplesEnabled'),examples:$('#personaExamples'),exampleChars:$('#personaExampleChars'),saved:$('#personaSaved'),chars:$('#personaChars'),sample:$('#personaSample'),preview:$('#personaPreview'),warmth:$('#personaWarmth'),energy:$('#personaEnergy'),brevity:$('#personaBrevity'),playfulness:$('#personaPlayfulness'),directness:$('#personaDirectness'),creativity:$('#personaCreativity'),technicalPrecision:$('#personaTechnicalPrecision'),formality:$('#personaFormality'),emojiLevel:$('#personaEmojiLevel'),structure:$('#personaStructure'),affection:$('#personaAffection'),teasing:$('#personaTeasing'),naturalness:$('#personaNaturalness'),technicalCompactness:$('#personaTechnicalCompactness'),contextReuse:$('#personaContextReuse'),corporateAvoidance:$('#personaCorporateAvoidance'),persianCasual:$('#personaPersianCasual'),roleplayIntensity:$('#personaRoleplayIntensity'),answerFirst:$('#personaAnswerFirst'),explanationDepth:$('#personaExplanationDepth'),initiative:$('#personaInitiative'),verificationDepth:$('#personaVerificationDepth'),codeCompleteness:$('#personaCodeCompleteness'),emotionalMirroring:$('#personaEmotionalMirroring'),failureModeDepth:$('#personaFailureModeDepth'),sourceDiscipline:$('#personaSourceDiscipline'),constraintTracking:$('#personaConstraintTracking'),artifactCompleteness:$('#personaArtifactCompleteness'),smartAnchorEvery:$('#personaSmartAnchorEvery'),maxSteeringChars:$('#personaMaxSteeringChars'),maxSteeringOut:$('#personaMaxSteeringOut'),wireDot:$('#personaWireDot'),wireState:$('#personaWireState'),wireDetail:$('#personaWireDetail'),fullBytes:$('#personaFullBytes'),compactBytes:$('#personaCompactBytes'),compression:$('#personaCompression'),intelBadge:$('#personaIntelBadge'),intelModel:$('#personaIntelModel'),intelEffort:$('#personaIntelEffort'),intelSurface:$('#personaIntelSurface'),intelNative:$('#personaIntelNative'),intelTask:$('#personaIntelTask'),intelLearning:$('#personaIntelLearning'),intelReport:$('#personaIntelReport'),modelAware:$('#personaModelAware'),modelPolicy:$('#personaModelPolicy'),nativeCoexist:$('#personaNativeCoexist'),adaptiveBudget:$('#personaAdaptiveBudget'),correctionLearning:$('#personaCorrectionLearning'),intelRefresh:$('#personaIntelRefresh'),traceExport:$('#personaTraceExport'),learningReset:$('#personaLearningReset'),sentinel:$('#personaSentinel')
  };
  let cfg=C.normalize(C.DEF),timer=null,sampleTimer=null;
  const traitKeys=['warmth','energy','brevity','playfulness','directness','creativity','technicalPrecision','formality','emojiLevel','structure','affection','teasing','naturalness','technicalCompactness','contextReuse','corporateAvoidance','persianCasual','roleplayIntensity','answerFirst','explanationDepth','initiative','verificationDepth','codeCompleteness','emotionalMirroring','failureModeDepth','sourceDiscipline','constraintTracking','artifactCompleteness'];
  function read(){
    return C.normalize({...cfg,enabled:E.enabled.checked,reasoningLock:E.reasoningLock.checked,reasoningLevel:E.reasoningLevel.value,hardTaskProtocol:E.hardTaskProtocol.checked,protocolScope:E.protocolScope.value,diligenceEnabled:E.diligenceEnabled.checked,diligenceLevel:E.diligenceLevel.value,diligenceMinutes:+E.diligenceMinutes.value,diligenceVerify:E.diligenceVerify.checked,diligenceEdgeCases:E.diligenceEdgeCases.checked,diligenceAlternatives:E.diligenceAlternatives.checked,diligenceSources:E.diligenceSources.checked,diligenceComplete:E.diligenceComplete.checked,diligenceUseTools:E.diligenceUseTools.checked,playbookCode:E.playbookCode.checked,playbookResearch:E.playbookResearch.checked,playbookFormal:E.playbookFormal.checked,playbookCasual:E.playbookCasual.checked,playbookRoleplay:E.playbookRoleplay.checked,exactAmbiguity:E.exactAmbiguity.checked,regressionPass:E.regressionPass.checked,text:E.text.value,userContext:E.userContext.value,preset:E.preset.value,strategy:E.strategy.value,frequency:E.frequency.value,policyDensity:E.policyDensity?.value||cfg.policyDensity,hideHistory:E.hide.checked,historyResponseSanitize:E.historyResponseSanitize?.checked===true,taskAdaptive:E.task.checked,taskAdaptiveStrength:+E.taskStrength.value,suppliedProfile:E.suppliedProfile?.checked===true,intentGuard:E.intent.checked,intentText:E.intentText.value,examplesEnabled:E.examplesEnabled.checked,examples:E.examples.value,warmth:+E.warmth.value,energy:+E.energy.value,brevity:+E.brevity.value,playfulness:+E.playfulness.value,directness:+E.directness.value,creativity:+E.creativity.value,technicalPrecision:+E.technicalPrecision.value,formality:+E.formality.value,emojiLevel:+E.emojiLevel.value,structure:+E.structure.value,affection:+E.affection.value,teasing:+E.teasing.value,naturalness:+E.naturalness.value,technicalCompactness:+E.technicalCompactness.value,contextReuse:+E.contextReuse.value,corporateAvoidance:+E.corporateAvoidance.value,persianCasual:+E.persianCasual.value,roleplayIntensity:+E.roleplayIntensity.value,answerFirst:+E.answerFirst.value,explanationDepth:+E.explanationDepth.value,initiative:+E.initiative.value,verificationDepth:+E.verificationDepth.value,codeCompleteness:+E.codeCompleteness.value,emotionalMirroring:+E.emotionalMirroring.value,failureModeDepth:+E.failureModeDepth.value,sourceDiscipline:+E.sourceDiscipline.value,constraintTracking:+E.constraintTracking.value,artifactCompleteness:+E.artifactCompleteness.value,smartAnchorEvery:+E.smartAnchorEvery.value,maxSteeringChars:+E.maxSteeringChars.value,modelAware:E.modelAware?.checked!==false,modelPolicy:E.modelPolicy?.value||'adaptive',nativeCoexist:E.nativeCoexist?.checked!==false,adaptiveSteeringBudget:E.adaptiveBudget?.checked!==false,correctionLearning:E.correctionLearning?.checked!==false});
  }
  function strategyInfo(){
    const m={
      adaptive:['Adaptive','Short: structured prefix · medium: structured tail · long: dual anchor.'],
      'structured-prefix':['Structured Prefix','Full compact steering before the current task.'],
      'structured-tail':['Structured Tail','Current task first; full compact steering closest to generation.'],
      'dual-anchor':['Dual Anchor','Tiny style anchor first + full compact steering at the tail.'],
      'sandwich-lite':['Sandwich Lite','Full compact steering first + tiny reminder after the task.'],
      'raw-prefix':['Raw Prefix','Minimal framing before the task.'],
      'raw-tail':['Raw Tail','Minimal framing after the task.']
    };
    return m[cfg.strategy]||m.adaptive;
  }
  function presetNote(){
    if(cfg.preset==='4o-conversational')return'Conversational response lens. It does not switch or unlock the underlying ChatGPT model.';
    if(cfg.preset==='custom')return'Your advanced sliders + custom personality/context control the compiled behavior.';
    return`${C.PRESETS[cfg.preset]?.label||'Natural'} response lens. Advanced sliders can branch it into Custom.`;
  }
  function updateTraitOut(){
    const ids={warmth:'Warmth',energy:'Energy',brevity:'Brevity',playfulness:'Playfulness',directness:'Directness',creativity:'Creativity',technicalPrecision:'TechnicalPrecision',formality:'Formality',emojiLevel:'EmojiLevel',structure:'Structure',affection:'Affection',teasing:'Teasing',naturalness:'Naturalness',technicalCompactness:'TechnicalCompactness',contextReuse:'ContextReuse',corporateAvoidance:'CorporateAvoidance',persianCasual:'PersianCasual',roleplayIntensity:'RoleplayIntensity',answerFirst:'AnswerFirst',explanationDepth:'ExplanationDepth',initiative:'Initiative',verificationDepth:'VerificationDepth',codeCompleteness:'CodeCompleteness',emotionalMirroring:'EmotionalMirroring',failureModeDepth:'FailureModeDepth',sourceDiscipline:'SourceDiscipline',constraintTracking:'ConstraintTracking',artifactCompleteness:'ArtifactCompleteness'};
    for(const k of traitKeys){
      const out=$(`#persona${ids[k]}Out`);
      if(out)out.textContent=E[k].value;
    }
  }
  function paintPreview(){
    if(!cfg.enabled){
      E.preview.textContent='Persona Engine is off.';
      E.fullBytes.textContent='—';E.compactBytes.textContent='—';E.compression.textContent='—';
      return;
    }
    const sample=E.sample.value||'Your prompt here…',compiled=C.compose(cfg,sample,{kind:'full'}),m=C.metrics(cfg,sample);
    E.preview.textContent=compiled.output;
    E.fullBytes.textContent=`${m.fullBytes} B`;
    E.compactBytes.textContent=`${m.compactBytes} B`;
    E.compression.textContent=`${Math.round(m.ratio*100)}%`;
  }
  function paintWire(last){
    E.wireDot?.classList.remove('live','warn');
    if(!cfg.enabled){
      E.wireState.textContent='REASONING LOCK · OFF';
      E.wireDetail.textContent='Enable the engine, then send a ChatGPT or Work message.';
      return;
    }
    if(!last){
      E.wireState.textContent=cfg.diligenceEnabled?`PRO DILIGENCE · ${cfg.diligenceLevel.toUpperCase()} ARMED`:`REASONING · ${cfg.reasoningLevel.toUpperCase()} ARMED`;
      E.wireDetail.textContent=cfg.diligenceEnabled?`Every supported send gets the ${cfg.diligenceMinutes}-minute quality target tail + enabled QA gates.`:'Waiting to verify thinking_effort / backend_thinking_effort on the next send.';
      return;
    }
    const kind=String(last.kind||'').toLowerCase(),ok=['locked','verified','injected','anchored','sanitized'].includes(kind),warn=['bypassed','error'].includes(kind);
    E.wireDot?.classList.toggle('live',ok);
    E.wireDot?.classList.toggle('warn',warn);
    E.wireState.textContent=['locked','verified'].includes(kind)?`REASONING · ${(last.reasoningTarget||cfg.reasoningLevel).toUpperCase()} ${kind.toUpperCase()}`:`PERSONA · ${kind?kind.toUpperCase():'ARMED'}`;
    const when=last.at?new Date(last.at).toLocaleTimeString():'',bits=[last.endpoint||'conversation'];
    if(kind==='locked'||kind==='verified'){
      if(last.model)bits.push(last.model);
      if(last.effortAfter)bits.push(last.effortAfter);
      if(last.protocol)bits.push('hard-task protocol');if(last.diligence)bits.push(`${last.diligenceLevel||cfg.diligenceLevel}/${last.diligenceMinutes||cfg.diligenceMinutes}m diligence`);
      if(last.reason)bits.push(last.reason);
    }else if(kind==='injected'||kind==='anchored'){
      bits.push(`${last.strategy||cfg.strategy} · ${last.frequency||cfg.frequency}`);
      if(Number.isFinite(+last.originalChars))bits.push(`user ${last.originalChars}c`);
      if(Number.isFinite(+last.steeringChars))bits.push(`steering ${last.steeringChars}c`);
      if(last.reason)bits.push(last.reason);
    }else if(kind==='sanitized')bits.push(`${last.sanitizedParts||0} private part(s) cleaned`);
    else if(last.reason)bits.push(last.reason);
    if(when)bits.push(when);
    E.wireDetail.textContent=bits.join(' · ');
  }
  function paint(){
    E.enabled.checked=cfg.enabled;
    E.reasoningLock.checked=cfg.reasoningLock;
    E.reasoningLevel.value=cfg.reasoningLevel;
    E.answerLength.value=String(cfg.brevity>=3?3:cfg.brevity<=1?1:2);
    E.reasoningLevel.disabled=!cfg.reasoningLock;
    E.hardTaskProtocol.checked=cfg.hardTaskProtocol;
    E.protocolScope.value=cfg.protocolScope;
    E.diligenceEnabled.checked=cfg.diligenceEnabled;E.diligenceLevel.value=cfg.diligenceLevel;E.diligenceMinutes.value=String(cfg.diligenceMinutes);E.diligenceVerify.checked=cfg.diligenceVerify;E.diligenceEdgeCases.checked=cfg.diligenceEdgeCases;E.diligenceAlternatives.checked=cfg.diligenceAlternatives;E.diligenceSources.checked=cfg.diligenceSources;E.diligenceComplete.checked=cfg.diligenceComplete;E.diligenceUseTools.checked=cfg.diligenceUseTools;
    E.playbookCode.checked=cfg.playbookCode;E.playbookResearch.checked=cfg.playbookResearch;E.playbookFormal.checked=cfg.playbookFormal;E.playbookCasual.checked=cfg.playbookCasual;E.playbookRoleplay.checked=cfg.playbookRoleplay;E.exactAmbiguity.checked=cfg.exactAmbiguity;E.regressionPass.checked=cfg.regressionPass;
    E.protocolScope.disabled=!cfg.reasoningLock||!cfg.hardTaskProtocol;
    for(const el of [E.diligenceLevel,E.diligenceMinutes,E.diligenceVerify,E.diligenceEdgeCases,E.diligenceAlternatives,E.diligenceSources,E.diligenceComplete,E.diligenceUseTools])el.disabled=!cfg.diligenceEnabled;
    E.text.value=cfg.text;
    E.userContext.value=cfg.userContext;
    E.preset.value=cfg.preset;
    E.strategy.value=cfg.strategy;
    E.frequency.value=cfg.frequency;if(E.policyDensity)E.policyDensity.value=cfg.policyDensity;
    E.smartAnchorEvery.value=String(cfg.smartAnchorEvery);E.maxSteeringChars.value=String(cfg.maxSteeringChars);E.maxSteeringOut.textContent=`${cfg.maxSteeringChars} chars`;
    E.hide.checked=cfg.hideHistory;if(E.historyResponseSanitize)E.historyResponseSanitize.checked=cfg.historyResponseSanitize===true;
    E.task.checked=cfg.taskAdaptive;
    E.taskStrength.value=String(cfg.taskAdaptiveStrength);E.taskStrength.disabled=!cfg.taskAdaptive;E.taskStrengthOut.textContent=`${cfg.taskAdaptiveStrength} / 4`;
    if(E.suppliedProfile)E.suppliedProfile.checked=cfg.suppliedProfile;if(E.modelAware)E.modelAware.checked=cfg.modelAware!==false;if(E.modelPolicy)E.modelPolicy.value=cfg.modelPolicy||'adaptive';if(E.nativeCoexist)E.nativeCoexist.checked=cfg.nativeCoexist!==false;if(E.adaptiveBudget)E.adaptiveBudget.checked=cfg.adaptiveSteeringBudget!==false;if(E.correctionLearning)E.correctionLearning.checked=cfg.correctionLearning!==false;if(E.intelLearning){const scoped=Object.values(cfg.learnedByTask||{}).reduce((a,x)=>a+(x?.samples||0),0);E.intelLearning.textContent=`${cfg.learned?.samples||0} global · ${scoped} scoped`;}
    E.intent.checked=cfg.intentGuard;
    E.intentText.value=cfg.intentText;
    E.intentText.disabled=!cfg.intentGuard;
    E.examplesEnabled.checked=cfg.examplesEnabled;
    E.examples.value=cfg.examples;
    E.examples.disabled=!cfg.examplesEnabled;
    for(const k of traitKeys)E[k].value=String(cfg[k]);
    updateTraitOut();
    E.chars.textContent=`${cfg.text.length} / 24000`;
    E.userContextChars.textContent=`${cfg.userContext.length} / 8000`;
    E.exampleChars.textContent=`${cfg.examples.length} / 16000`;
    const [badge,hint]=strategyInfo();
    E.strategyBadge.textContent=badge;
    E.strategyHint.textContent=hint;
    E.presetNote.textContent=presetNote();
    E.sentinel.textContent=cfg.debugSentinelOnce?'Sentinel armed · send one message':'Arm one-shot sentinel';
    paintPreview();
  }
  async function probePersonaIntel(){
    try{const[tb]=await chrome.tabs.query({active:true,currentWindow:true});if(!tb?.id)throw new Error('No active tab');const r=await chrome.scripting.executeScript({target:{tabId:tb.id,frameIds:[0]},world:'MAIN',func:()=>{const p=window.__KYRON_PERSONA_ENGINE_V6__,i=window.__KYRON_PERSONA_INTEL__;try{i?.probeUi?.()}catch{}return p?.getRuntimeIntel?.()||i?.snapshot?.()||null}}),x=r?.[0]?.result;if(!x){E.intelBadge.textContent='No hook';E.intelReport.textContent='Open ChatGPT and reload the Kyron extension once.';return null}E.intelBadge.textContent=x.model?'Live':'Observed';E.intelModel.textContent=x.model||x.uiModel||'Unknown';E.intelEffort.textContent=x.effort||x.uiReasoning||'Unknown';E.intelSurface.textContent=x.surface||'chat';E.intelNative.textContent=x.nativePersonality!=='unknown'?x.nativePersonality:(x.nativeFeature==='available'?'Available · selection unknown':'Unknown');E.intelTask.textContent=x.taskClass||'general';E.intelReport.textContent=[x.modelClass?`family ${x.modelClass}`:'',x.routeNamespace?`route ${x.routeNamespace}`:'',x.reasoningCapable?'reasoning-capable':'',x.correctionSignals?.length?`corrections: ${x.correctionSignals.join(', ')}`:'',x.lastSettingsPath?`observed ${x.lastSettingsPath}`:''].filter(Boolean).join(' · ')||'Live hook ready; send a message to capture the actual request model/effort.';return x}catch(e){E.intelBadge.textContent='Unavailable';E.intelReport.textContent=e?.message||String(e);return null}
  }
  async function exportPersonaTrace(){const intel=await probePersonaIntel(),x=await chrome.storage.local.get([KEY,LASTKEY,'kyronPersonaIntelLast']),c=C.normalize(x[KEY]||cfg),safe={...c,text:`<redacted:${c.text.length}>`,userContext:`<redacted:${c.userContext.length}>`,intentText:`<redacted:${c.intentText.length}>`,examples:`<redacted:${c.examples.length}>`},out={format:'kyron-persona-trace',version:1,createdAt:new Date().toISOString(),runtime:intel||x.kyronPersonaIntelLast||null,config:safe,lastPersonaEvent:x[LASTKEY]||null,notes:['No cookies, auth tokens, resume tokens or raw conversation text are exported.','Explicit-correction learning stores only bounded signal categories and aggregate weights.']},blob=new Blob([JSON.stringify(out,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`Kyron-Persona-Trace-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500)}
  async function resetLearning(){cfg=C.normalize({...read(),learned:C.DEF.learned,learnedByTask:{},learnedByModelClass:{}});await chrome.storage.local.set({[KEY]:cfg});paint();await probePersonaIntel();E.saved.textContent='Learned behavior weights reset · persistent'}
  async function save(msg='Saved locally'){
    cfg=read();
    await chrome.storage.local.set({[KEY]:cfg});
    await chrome.storage.local.remove(LASTKEY);
    E.saved.textContent=`${msg} · persistent`;
    paint();
    paintWire(null);
  }
  function queue(){
    clearTimeout(timer);
    timer=setTimeout(()=>save().catch(()=>{}),350);
  }
  async function load(){
    const x=await chrome.storage.local.get([KEY,UIKEY,LASTKEY]);
    cfg=C.normalize(x[KEY]||C.DEF);
    if(JSON.stringify(cfg)!==JSON.stringify(x[KEY]||{}))await chrome.storage.local.set({[KEY]:cfg});
    E.sample.value=String(x[UIKEY]?.sample||'');
    paint();
    paintWire(x[LASTKEY]);
    E.saved.textContent=(cfg.text||cfg.userContext||cfg.preset!=='custom')?'Loaded from local storage':'Local-only · empty';
  }

  E.preset.addEventListener('change',()=>{
    const p=C.PRESETS[E.preset.value]||C.PRESETS.custom;
    cfg=C.normalize({...read(),preset:E.preset.value,...Object.fromEntries(traitKeys.map(k=>[k,p[k]]))});
    paint();
    save('Preset applied').catch(()=>{});
  });
  E.answerLength.addEventListener('change',()=>{E.brevity.value=E.answerLength.value;cfg=read();paint();save('Answer length applied').catch(()=>{})});
  for(const el of [E.enabled,E.reasoningLock,E.reasoningLevel,E.hardTaskProtocol,E.protocolScope,E.diligenceEnabled,E.diligenceLevel,E.diligenceMinutes,E.diligenceVerify,E.diligenceEdgeCases,E.diligenceAlternatives,E.diligenceSources,E.diligenceComplete,E.diligenceUseTools,E.playbookCode,E.playbookResearch,E.playbookFormal,E.playbookCasual,E.playbookRoleplay,E.exactAmbiguity,E.regressionPass,E.strategy,E.frequency,E.policyDensity,E.smartAnchorEvery,E.maxSteeringChars,E.hide,E.historyResponseSanitize,E.task,E.suppliedProfile,E.intent,E.examplesEnabled,E.modelAware,E.modelPolicy,E.nativeCoexist,E.adaptiveBudget,E.correctionLearning].filter(Boolean))el.addEventListener('change',()=>save().catch(()=>{}));
  E.taskStrength.addEventListener('input',()=>{E.taskStrengthOut.textContent=`${E.taskStrength.value} / 4`;cfg=read();paintPreview();queue()});
  for(const k of traitKeys)E[k].addEventListener('input',()=>{
    cfg=read();cfg.preset='custom';E.preset.value='custom';paint();queue();
  });
  E.maxSteeringChars.addEventListener('input',()=>{E.maxSteeringOut.textContent=`${E.maxSteeringChars.value} chars`;cfg=read();paintPreview();queue()});
  for(const el of [E.text,E.userContext,E.intentText,E.examples])el.addEventListener('input',()=>{cfg=read();paint();queue()});
  E.sample.addEventListener('input',()=>{
    cfg=read();paintPreview();clearTimeout(sampleTimer);sampleTimer=setTimeout(()=>chrome.storage.local.set({[UIKEY]:{schema:2,sample:E.sample.value}}).catch(()=>{}),250);
  });
  E.loadJessica?.addEventListener('click',()=>{const p=C.PRESETS['jessica-local'],traits=Object.fromEntries(traitKeys.map(k=>[k,p[k]]));cfg=C.normalize({...read(),...traits,preset:'jessica-local',suppliedProfile:true});paint();save('Jessica local-dev profile applied').catch(()=>{})});
  $('#personaSave').addEventListener('click',()=>save('Saved').catch(()=>{}));
  $('#personaReset').addEventListener('click',async()=>{
    if(!confirm('Reset Persona Engine settings?'))return;
    cfg=C.normalize(C.DEF);
    await chrome.storage.local.set({[KEY]:cfg});
    await chrome.storage.local.remove(LASTKEY);
    paint();paintWire(null);E.saved.textContent='Reset · persistent';
  });
  E.sentinel.addEventListener('click',async()=>{
    cfg=C.normalize({...read(),enabled:true,debugSentinelOnce:true});
    await chrome.storage.local.set({[KEY]:cfg});
    await chrome.storage.local.remove(LASTKEY);
    paint();paintWire(null);E.saved.textContent='Sentinel armed · next supported user send only';
  });
  E.intelRefresh?.addEventListener('click',()=>probePersonaIntel());
  E.traceExport?.addEventListener('click',()=>exportPersonaTrace().catch(e=>{E.intelReport.textContent=e?.message||String(e)}));
  E.learningReset?.addEventListener('click',()=>resetLearning().catch(()=>{}));
  setTimeout(()=>probePersonaIntel(),900);
  chrome.storage.onChanged.addListener((c,a)=>{
    if(a!=='local')return;
    if(c[KEY]){cfg=C.normalize(c[KEY].newValue||C.DEF);paint()}
    if(c[LASTKEY])paintWire(c[LASTKEY].newValue||null);
  });
  load().catch(()=>{});
})();
