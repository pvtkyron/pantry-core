(()=>{
  'use strict';
  const KEY='kyronRestoreJournal.v1';
  const summary=(id,meta,startedAt,state,journal)=>({id,meta,startedAt,state,journal:{schema:journal?.schema||0,tabId:journal?.tabId??null,incognito:!!journal?.incognito,frameCount:journal?.frames?.length||0,cookieCount:journal?.cookies?.length||0,capturedAt:journal?.capturedAt||0}});
  async function run({meta={},capture,apply,validate,rollback,onStage=()=>{}}){
    const id=`rt-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`,startedAt=Date.now();let journal=null,applied=null;
    try{
      onStage('capture');journal=await capture();await chrome.storage.session.set({[KEY]:summary(id,meta,startedAt,'captured',journal)});onStage('captured');
      onStage('apply');applied=await apply(journal);await chrome.storage.session.set({[KEY]:summary(id,meta,startedAt,'applied',journal)});onStage('applied');
      onStage('validate');const verdict=await validate(applied,journal);if(verdict===false||verdict?.ok===false)throw new Error(verdict?.error||'Restore validation failed.');
      await chrome.storage.session.remove(KEY);onStage('commit');return{ok:true,id,result:applied,verdict};
    }catch(error){
      let rollbackError=null;try{if(journal){onStage('rollback');await rollback(journal,error);onStage('rolled-back')}}catch(e){rollbackError=e}
      await chrome.storage.session.remove(KEY).catch(()=>{});const e=new Error(error?.message||String(error));e.rollbackError=rollbackError?.message||'';if(rollbackError)e.message+=` Rollback warning: ${e.rollbackError}`;throw e;
    }
  }
  async function pending(){return(await chrome.storage.session.get(KEY))[KEY]||null}
  async function clear(){await chrome.storage.session.remove(KEY)}
  globalThis.KyronRestoreTransaction={run,pending,clear,_test:{KEY,summary}};
})();
