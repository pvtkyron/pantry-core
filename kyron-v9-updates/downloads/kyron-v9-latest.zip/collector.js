const $=s=>document.querySelector(s),enc=new TextEncoder(),dec=new TextDecoder();
const ui={title:$('#targetTitle'),url:$('#targetUrl'),phase:$('#phase'),pct:$('#pct'),bar:$('#bar'),detail:$('#detail'),files:$('#fileCount'),size:$('#sizeCount'),mutators:$('#mutatorCount'),skipped:$('#skipCount'),log:$('#log'),download:$('#download'),retry:$('#retry'),copy:$('#copyLog')};
const params=new URLSearchParams(location.search),tabId=Number(params.get('tabId'));
const ROOT={tabId},MAX_FILE=40*1024*1024,MAX_TOTAL=350*1024*1024,QUIET_MS=6500,MIN_AFTER_LOAD=10000,MAX_WAIT=55000;
const CUSTOM=new Set(['/session-guard.js','/deep-research-proxy.js','/includes','/hider','/sayhi','/sidebar-hider','/project-route-guard','/project-locker']);
const DENY=['/backend-api/','/session-manager/','/ces/','/logout','/auth/','/public-api/','/api/'];
const STATIC_EXT=/\.(?:js|mjs|cjs|css|wasm|map|json|svg|png|jpe?g|webp|gif|ico|woff2?|ttf|otf|eot)(?:$|\?)/i;
const TEXT_EXT=/\.(?:js|mjs|cjs|css|map|json|svg|txt)(?:$|\?)/i;
let attached=false,finished=false,rootLoadedAt=0,lastAssetAt=Date.now(),startedAt=0,totalBytes=0,skipped=0,mutatorHits=0,blobUrl='';
const requests=new Map(),files=new Map(),observed=new Map(),sessions=new Set(['root']),errors=[];
const sid=s=>s?.sessionId||'root',reqKey=(s,id)=>`${sid(s)}:${id}`;
const human=n=>n<1024?`${n} B`:n<1048576?`${(n/1024).toFixed(1)} KB`:`${(n/1048576).toFixed(1)} MB`;
const log=(m,kind='')=>{const t=new Date().toLocaleTimeString();ui.log.textContent+=`[${t}] ${kind?kind+' ':''}${m}\n`;ui.log.scrollTop=ui.log.scrollHeight};
const progress=(phase,pct,detail='')=>{ui.phase.textContent=phase;ui.pct.textContent=`${pct}%`;ui.bar.style.width=`${pct}%`;if(detail)ui.detail.textContent=detail};
const refresh=()=>{ui.files.textContent=String(files.size);ui.size.textContent=human(totalBytes);ui.mutators.textContent=String(mutatorHits);ui.skipped.textContent=String(skipped)};
const send=(session,method,p={})=>chrome.debugger.sendCommand(session,method,p);
const safeUrl=u=>{try{const x=new URL(u);return `${x.origin}${x.pathname}`;}catch{return String(u||'').split('?')[0]}};
function classify(u,type='',mime=''){
  let x;try{x=new URL(u)}catch{return null}
  const host=x.hostname.toLowerCase(),path=x.pathname;
  if(host!=='chats.fastpass-panel.ir')return null;
  if(DENY.some(p=>path.startsWith(p))){skipped++;return null}
  if(path.startsWith('/cdn/assets/'))return 'cdn';
  if(CUSTOM.has(path))return 'custom';
  if(STATIC_EXT.test(path)&&['Script','Stylesheet','Font','Image','Media','Other'].includes(type))return 'static';
  if(/javascript|css|wasm|font|image\/|svg/i.test(mime||'')&&STATIC_EXT.test(path))return 'static';
  return null;
}
function noteObserved(url,type,mime,status,source){const k=safeUrl(url);if(!observed.has(k))observed.set(k,{url:k,type:type||'',mime:mime||'',status:status??null,source})}
async function setupSession(session){
  sessions.add(sid(session));
  for(const [m,p] of [['Network.enable',{}],['Page.enable',{}],['Network.setCacheDisabled',{cacheDisabled:true}],['Network.setBypassServiceWorker',{bypass:true}]])try{await send(session,m,p)}catch(e){if(m==='Network.enable')throw e}
  try{await send(session,'Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:false,flatten:true})}catch{}
}
async function bodyBytes(session,requestId){const r=await send(session,'Network.getResponseBody',{requestId});if(r.base64Encoded){const bin=atob(r.body),a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);return a}return enc.encode(r.body||'')}
async function sha256(bytes){const h=new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));return[...h].map(x=>x.toString(16).padStart(2,'0')).join('')}
async function fileNameFor(url){const x=new URL(url),raw=x.pathname.replace(/^\/+/,''),parts=raw.split('/').filter(Boolean).map(p=>p.replace(/[<>:"\\|?*\x00-\x1F]/g,'_'));let name=parts.join('/')||'asset';if(x.search){const h=await sha256(enc.encode(x.search));const i=name.lastIndexOf('.');name=i>name.lastIndexOf('/')?`${name.slice(0,i)}__q_${h.slice(0,8)}${name.slice(i)}`:`${name}__q_${h.slice(0,8)}`}return name}
const rules=[
  ['DOM_REMOVE',/\.(?:remove|removeChild|replaceChildren)\s*\(/g],
  ['DOM_REWRITE',/(?:innerHTML|outerHTML)\s*=|document\.write\s*\(/g],
  ['MUTATION_OBSERVER',/new\s+MutationObserver\s*\(/g],
  ['STORAGE_DELETE',/(?:localStorage|sessionStorage)\.(?:removeItem|clear)\s*\(/g],
  ['COOKIE_WRITE',/document\.cookie\s*=/g],
  ['COOKIE_EXPIRE',/(?:Expires\s*=\s*Thu,?\s*01\s*Jan\s*1970|Max-Age\s*=\s*0)/gi],
  ['FETCH_HOOK',/(?:window\.)?fetch\s*=|originalFetch|credentials\s*:\s*['\"](?:omit|include)['\"]/g],
  ['XHR_HOOK',/XMLHttpRequest\.prototype\.(?:open|send|setRequestHeader)|withCredentials/g],
  ['AUTH_PATH',/Authorization|Bearer\s+|credentials|setRequestHeader/g],
  ['ROUTE_GUARD',/history\.(?:pushState|replaceState)|location\.(?:replace|assign)/g],
  ['VISIBILITY_HIDE',/(?:display\s*:\s*none|visibility\s*:\s*hidden|opacity\s*:\s*0)/gi],
  ['SERVICE_WORKER',/serviceWorker\.(?:register|unregister)|navigator\.serviceWorker/g]
];
function analyzeText(text){const out=[];for(const [category,re] of rules){re.lastIndex=0;let m;while((m=re.exec(text))&&out.length<80){const line=text.slice(0,m.index).split('\n').length,start=Math.max(0,m.index-90),end=Math.min(text.length,m.index+Math.max(120,m[0].length+90)),snippet=text.slice(start,end).replace(/\s+/g,' ').trim().slice(0,260);out.push({category,line,match:m[0].slice(0,100),snippet});if(!m[0].length)re.lastIndex++}}return out}
async function storeAsset(meta,bytes,source){
  if(bytes.length>MAX_FILE){skipped++;log(`${safeUrl(meta.url)} (${human(bytes.length)})`,'SKIP LARGE');refresh();return}
  const clean=safeUrl(meta.url),key=meta.url;
  if(files.has(key))return;
  if(totalBytes+bytes.length>MAX_TOTAL){skipped++;log('Total capture cap reached','STOP');return}
  const filename=await fileNameFor(meta.url),hash=await sha256(bytes),isText=/javascript|css|json|svg|text\//i.test(meta.mime||'')||TEXT_EXT.test(meta.url),analysis=isText?analyzeText(dec.decode(bytes)):[];
  mutatorHits+=analysis.length;files.set(key,{filename,bytes,url:meta.url,urlSafe:clean,type:meta.type||'',mime:meta.mime||'',status:meta.status??null,source,sha256:hash,analysis});totalBytes+=bytes.length;lastAssetAt=Date.now();refresh();log(`${filename} · ${human(bytes.length)}${analysis.length?` · ${analysis.length} flags`:''}`,'SAVE')
}
async function onFinished(source,requestId){const k=reqKey(source,requestId),r=requests.get(k);if(!r||r.done)return;r.done=true;try{const bytes=await bodyBytes(source,requestId);await storeAsset(r,bytes,'network')}catch(e){errors.push({stage:'getResponseBody',url:safeUrl(r.url),error:e.message||String(e)});log(`${safeUrl(r.url)} -> ${e.message||e}`,'BODY FAIL')}}
chrome.debugger.onEvent.addListener((source,method,p)=>{
  if(Number(source.tabId)!==tabId||finished)return;
  if(method==='Target.attachedToTarget'){
    const child={tabId,sessionId:p.sessionId};setupSession(child).then(()=>log(`${p.targetInfo?.type||'target'} ${safeUrl(p.targetInfo?.url||'')}`,'ATTACH')).catch(e=>log(e.message||e,'CHILD FAIL'));return
  }
  if(method==='Network.responseReceived'){
    const r=p.response||{},bucket=classify(r.url,p.type,r.mimeType);noteObserved(r.url,p.type,r.mimeType,r.status,'network');if(!bucket)return;
    requests.set(reqKey(source,p.requestId),{url:r.url,type:p.type,mime:r.mimeType,status:r.status,bucket,protocol:r.protocol||'',fromDiskCache:!!r.fromDiskCache,fromServiceWorker:!!r.fromServiceWorker,done:false});lastAssetAt=Date.now();log(`${bucket} ${safeUrl(r.url)}`,'SEEN');return
  }
  if(method==='Network.loadingFinished'){void onFinished(source,p.requestId);return}
  if(method==='Network.loadingFailed'){const r=requests.get(reqKey(source,p.requestId));if(r)log(`${safeUrl(r.url)} -> ${p.errorText||'failed'}`,'FAIL');return}
  if(method==='Page.loadEventFired'&&!source.sessionId){rootLoadedAt=Date.now();lastAssetAt=Date.now();progress('Hydrating FastPass…',58,'Page loaded. Waiting for lazy chunks and custom guard scripts.');log('Top-level load event','LOAD')}
});
chrome.debugger.onDetach.addListener((source,reason)=>{if(Number(source.tabId)===tabId&&!finished){attached=false;log(`Debugger detached: ${reason}`,'DETACH')}});
function flattenResourceTree(node,out=[]){if(!node)return out;for(const r of node.resources||[])out.push({frameId:node.frame?.id,url:r.url,type:r.type,mime:r.mimeType||''});for(const c of node.childFrames||[])flattenResourceTree(c,out);return out}
async function resourceTreeFallback(){
  progress('Resource-tree fallback…',82,'Recovering static resources Chrome still retains after page load.');
  try{const tree=(await send(ROOT,'Page.getResourceTree')).frameTree,rows=flattenResourceTree(tree);for(const r of rows){const bucket=classify(r.url,r.type,r.mime);noteObserved(r.url,r.type,r.mime,null,'resourceTree');if(!bucket||[...files.values()].some(x=>x.url===r.url))continue;try{const b=await send(ROOT,'Page.getResourceContent',{frameId:r.frameId,url:r.url}),bytes=b.base64Encoded?Uint8Array.from(atob(b.content),c=>c.charCodeAt(0)):enc.encode(b.content||'');await storeAsset({...r,status:null,bucket},bytes,'resourceTree')}catch(e){errors.push({stage:'Page.getResourceContent',url:safeUrl(r.url),error:e.message||String(e)})}}}catch(e){errors.push({stage:'Page.getResourceTree',error:e.message||String(e)});log(e.message||e,'RESOURCE TREE FAIL')}
}
async function pageInventory(){
  try{const r=await send(ROOT,'Runtime.evaluate',{expression:`(()=>({scripts:[...document.scripts].map(s=>({src:s.src||'',inlineBytes:s.src?0:new TextEncoder().encode(s.textContent||'').length})),links:[...document.querySelectorAll('link[href]')].map(x=>x.href),perf:performance.getEntriesByType('resource').map(x=>x.name)}))()`,returnByValue:true,awaitPromise:true});const v=r.result?.value||{};return{scripts:(v.scripts||[]).map(x=>({src:x.src?safeUrl(x.src):'',inlineBytes:x.inlineBytes||0})),links:(v.links||[]).map(safeUrl),performance:(v.perf||[]).map(safeUrl)}}catch(e){errors.push({stage:'pageInventory',error:e.message||String(e)});return{scripts:[],links:[],performance:[]}}
}
function dosTimeDate(d=new Date()){let y=Math.max(1980,d.getFullYear());return{time:(d.getHours()<<11)|(d.getMinutes()<<5)|(d.getSeconds()>>1),date:((y-1980)<<9)|((d.getMonth()+1)<<5)|d.getDate()}}
const crcTable=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
function crc32(a){let c=0xffffffff;for(const b of a)c=crcTable[(c^b)&255]^(c>>>8);return(c^0xffffffff)>>>0}
function u16(n){const a=new Uint8Array(2),v=new DataView(a.buffer);v.setUint16(0,n,true);return a}function u32(n){const a=new Uint8Array(4),v=new DataView(a.buffer);v.setUint32(0,n>>>0,true);return a}
function zipBlob(entries){const local=[],central=[];let off=0;const {time,date}=dosTimeDate();for(const e of entries){const name=enc.encode(e.name),data=e.bytes instanceof Uint8Array?e.bytes:enc.encode(String(e.bytes)),crc=crc32(data),flags=0x0800;const lh=[u32(0x04034b50),u16(20),u16(flags),u16(0),u16(time),u16(date),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),name,data];local.push(...lh);const ch=[u32(0x02014b50),u16(20),u16(20),u16(flags),u16(0),u16(time),u16(date),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(off),name];central.push(...ch);off+=lh.reduce((n,x)=>n+x.length,0)}const csize=central.reduce((n,x)=>n+x.length,0),eocd=[u32(0x06054b50),u16(0),u16(0),u16(entries.length),u16(entries.length),u32(csize),u32(off),u16(0)];return new Blob([...local,...central,...eocd],{type:'application/zip'})}
async function buildArchive(inventory){
  progress('Building ZIP…',92,'Writing raw responses + provenance + mutator report.');
  const assets=[...files.values()].sort((a,b)=>a.filename.localeCompare(b.filename)),mutators=assets.filter(x=>x.analysis.length).map(x=>({file:x.filename,url:x.urlSafe,flags:x.analysis}));
  const manifest={format:'sitevault-fastpass-frontend',version:1,createdAt:new Date().toISOString(),target:{url:safeUrl((await chrome.tabs.get(tabId)).url||''),tabId},capture:{cacheDisabled:true,serviceWorkerBypassed:true,headersExported:false,cookiesExported:false,apiBodiesExported:false,maxFileBytes:MAX_FILE,maxTotalBytes:MAX_TOTAL},summary:{files:assets.length,bytes:totalBytes,mutatorFlags:mutatorHits,skipped,errors:errors.length},files:assets.map(x=>({path:x.filename,url:x.urlSafe,type:x.type,mime:x.mime,status:x.status,source:x.source,bytes:x.bytes.length,sha256:x.sha256,mutatorFlags:x.analysis.length})),errors};
  const observedSafe=[...observed.values()].sort((a,b)=>a.url.localeCompare(b.url));
  const readme=`SiteVault FastPass Frontend Capture v5.6\n\nThis archive contains static frontend responses only.\nIncluded: /cdn/assets/* and FastPass custom static scripts.\nExcluded: /backend-api/*, /session-manager/*, auth/API response bodies, cookies, Authorization headers, Set-Cookie headers and request headers.\n\nThe mutator report is a static keyword/API scan. A flag means code deserves inspection; it is not by itself proof of harmful behavior.\n`;
  const entries=assets.map(x=>({name:x.filename,bytes:x.bytes}));entries.push({name:'_sitevault/manifest.json',bytes:enc.encode(JSON.stringify(manifest,null,2))},{name:'_sitevault/mutator-report.json',bytes:enc.encode(JSON.stringify({createdAt:manifest.createdAt,files:mutators},null,2))},{name:'_sitevault/observed-static.json',bytes:enc.encode(JSON.stringify(observedSafe,null,2))},{name:'_sitevault/page-inventory.json',bytes:enc.encode(JSON.stringify(inventory,null,2))},{name:'_sitevault/README.txt',bytes:enc.encode(readme)});
  const blob=zipBlob(entries);if(blobUrl)URL.revokeObjectURL(blobUrl);blobUrl=URL.createObjectURL(blob);ui.download.disabled=false;ui.download.onclick=()=>{const a=document.createElement('a'),stamp=new Date().toISOString().replace(/[:.]/g,'-');a.href=blobUrl;a.download=`SiteVault-FastPass-Frontend-v5.6-${stamp}.zip`;a.click()};progress('READY',100,`${assets.length} files · ${human(totalBytes)} · ${mutatorHits} mutator flags · ZIP ready.`);log(`${assets.length} files / ${human(totalBytes)} / ${mutatorHits} flags`,'READY')
}
async function stopDebugger(){if(attached)try{await chrome.debugger.detach(ROOT)}catch{}attached=false}
async function run(){
  if(!Number.isInteger(tabId)){progress('Invalid target',0,'Open this collector from SiteVault on a FastPass source tab.');return}
  ui.download.disabled=true;ui.retry.hidden=true;finished=false;files.clear();requests.clear();observed.clear();errors.length=0;totalBytes=skipped=mutatorHits=0;rootLoadedAt=0;startedAt=lastAssetAt=Date.now();refresh();ui.log.textContent='';
  let tab;try{tab=await chrome.tabs.get(tabId)}catch{progress('Target tab missing',0,'The selected source tab no longer exists.');return}
  let host='';try{host=new URL(tab.url).hostname}catch{}if(host!=='chats.fastpass-panel.ir'){progress('Wrong source tab',0,'Select the chats.fastpass-panel.ir tab in SiteVault, then run the collector again.');return}
  ui.title.textContent=tab.title||'FastPass';ui.url.textContent=tab.url;ui.url.title=tab.url;
  try{
    progress('Attaching debugger…',8,'No request headers or cookie values are exported.');await chrome.debugger.attach(ROOT,'1.3');attached=true;log('Debugger attached','OK');await setupSession(ROOT);progress('Reloading without cache/SW…',20,'This forces fresh static responses so page scripts cannot hide their original network bodies from the archive.');await send(ROOT,'Page.reload',{ignoreCache:true});
    while(true){await new Promise(r=>setTimeout(r,500));const now=Date.now(),elapsed=now-startedAt,afterLoad=rootLoadedAt?now-rootLoadedAt:0,quiet=now-lastAssetAt;if(rootLoadedAt&&afterLoad>=MIN_AFTER_LOAD&&quiet>=QUIET_MS)break;if(elapsed>=MAX_WAIT){log('Maximum capture window reached','TIME');break}const pct=Math.min(78,24+Math.round((elapsed/MAX_WAIT)*52));progress(rootLoadedAt?'Capturing lazy chunks…':'Waiting for page load…',pct,`${files.size} files · ${human(totalBytes)} · quiet ${Math.round(quiet/1000)}s`)}
    await resourceTreeFallback();const inventory=await pageInventory();finished=true;await stopDebugger();await buildArchive(inventory);ui.retry.hidden=false
  }catch(e){errors.push({stage:'run',error:e.message||String(e)});log(e.message||e,'FATAL');finished=true;await stopDebugger();progress('Capture failed',0,e.message||String(e));ui.retry.hidden=false}
}
ui.retry.addEventListener('click',run);ui.copy.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(ui.log.textContent);ui.copy.textContent='Copied';setTimeout(()=>ui.copy.textContent='Copy',900)}catch{}});window.addEventListener('beforeunload',()=>{if(blobUrl)URL.revokeObjectURL(blobUrl);void stopDebugger()});run();
