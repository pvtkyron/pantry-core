(()=>{
  const btn=document.getElementById('diagExportBtn');if(!btn)return;
  const safeName=s=>String(s||'Kyron-diagnostics').replace(/[^a-z0-9._-]+/gi,'-').replace(/^-+|-+$/g,'')||'Kyron-diagnostics';
  btn.addEventListener('click',async()=>{
    const old=btn.textContent;btn.disabled=true;btn.textContent='Collecting…';
    try{
      const r=await chrome.runtime.sendMessage({type:'kyron:diagnostics'});if(!r?.ok)throw new Error(r?.error||'Diagnostics unavailable');
      const text=JSON.stringify(r.data,null,2),blob=new Blob([text],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`${safeName('Kyron-v9.20.0-diagnostics')}-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);btn.textContent='Exported';
    }catch(e){btn.textContent='Export failed';console.warn('[Kyron] diagnostics export failed',e)}finally{setTimeout(()=>{btn.disabled=false;btn.textContent=old},1200)}
  });
})();
