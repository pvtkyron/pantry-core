(()=>{
  'use strict';
  const norm=v=>String(v||'').trim().toLowerCase(),emailOf=v=>{const x=norm(v?.accountEmail||v?.email);return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x)?x:''};
  const same=(a,b)=>{if(!a||!b)return false;const ae=emailOf(a),be=emailOf(b);if(ae&&be)return ae===be;const pairs=[[a.accountId,b.accountId],[a.userId,b.userId]];return pairs.some(([x,y])=>x&&y&&norm(x)===norm(y))};
  const initials=(name,email)=>{const x=String(name||'').trim();if(x){const p=x.split(/\s+/).filter(Boolean);return((p[0]?.[0]||'')+(p.length>1?(p.at(-1)?.[0]||''):'')).toUpperCase().slice(0,2)||'AI'}const m=String(email||'').trim();return(m[0]||'A').toUpperCase()};
  const title=identity=>String(identity?.name||identity?.email?.split('@')[0]||'ChatGPT account').trim()||'ChatGPT account';
  const label=record=>String(record?.name||record?.accountName||record?.accountEmail?.split('@')[0]||'Saved account').trim()||'Saved account';
  const isAutoLabel=value=>{const s=String(value||'').trim();return !s||/^(?:GPT(?:\s*[·-]\s*.+)?|ChatGPT account|Saved account|Imported profile)$/i.test(s)};
  const preserveLabel=(existing,identity)=>existing?label(existing):title(identity);
  const mergeMeta=(existing,incoming={})=>{if(!existing)return{...incoming,name:label(incoming)};const labelSource=existing.labelSource||(existing.labelLocked?'user':incoming.labelSource||'existing'),out={...existing,...incoming,id:existing.id,name:label(existing),createdAt:existing.createdAt||incoming.createdAt,labelSource,labelLocked:existing.labelLocked===true||labelSource==='user',updatedAt:incoming.updatedAt||new Date().toISOString(),samePrincipalAs:null};for(const k of['accountName','accountEmail','accountId','userId','avatarUrl','principalFingerprint'])if(incoming[k]==null&&existing[k]!=null)out[k]=existing[k];return out};
  globalThis.KyronAccountStack={norm,emailOf,same,initials,title,label,isAutoLabel,preserveLabel,mergeMeta};
})();
