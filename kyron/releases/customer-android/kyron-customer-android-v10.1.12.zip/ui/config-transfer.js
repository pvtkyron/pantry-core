(()=>{
'use strict';
const api=globalThis.browser||globalThis.chrome,$=s=>document.querySelector(s),MAX=16*1024*1024;
const call=async(type,extra={})=>{const r=await api.runtime.sendMessage({scope:'kyron',type,...extra});if(!r?.ok)throw Error(r?.error||'Request failed.');return r.data};
const out=$('#configMsg'),fi=$('#configImportFile'),ex=$('#configExportBtn'),im=$('#configImportBtn'),bk=$('#configBackupBtn'),rs=$('#configRestoreBtn');
if(!ex||!im||!fi)return;
const msg=(s,bad=false)=>{if(out){out.textContent=s||'';out.dataset.bad=bad?'1':'0'}};
const safe=s=>String(s||'config').replace(/[\/:*?"<>|]+/g,'_').slice(0,90);
function download(v){const blob=new Blob([JSON.stringify(v,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=safe('Kyron-Global-Config-v'+(v.kyronVersion||'unknown')+'-'+new Date().toISOString().replace(/[:.]/g,'-'))+'.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
ex.addEventListener('click',async()=>{try{msg('Exporting…');download(await call('config:export'));msg('Exported.')}catch(e){msg(e.message,true)}});
im.addEventListener('click',()=>fi.click());
fi.addEventListener('change',async()=>{const f=fi.files?.[0];if(!f)return;try{if(f.size>MAX)throw Error('Config file is too large.');const bundle=JSON.parse(await f.text());if(!confirm('Import this Kyron config? Current portable settings will be backed up first.'))return;msg('Importing…');const r=await call('config:import',{bundle});msg('Imported '+r.count+'.');setTimeout(()=>location.reload(),350)}catch(e){msg(e.message,true)}finally{fi.value=''}});
bk?.addEventListener('click',async()=>{try{const r=await call('config:backup');msg('Backup saved · '+r.count+'.')}catch(e){msg(e.message,true)}});
rs?.addEventListener('click',async()=>{try{if(!confirm('Restore the last local config backup?'))return;const r=await call('config:restore');msg('Restored '+r.count+'.');setTimeout(()=>location.reload(),350)}catch(e){msg(e.message,true)}});
})();