(()=>{
  if(globalThis.KyronPersonaCore)return;

  const START='[KYRON_BEHAVIOR_PROFILE_v6]';
  const END='[/KYRON_BEHAVIOR_PROFILE_v6]';
  const ASTART='[KYRON_TONE_HINT_v6]';
  const AEND='[/KYRON_TONE_HINT_v6]';
  const QSTART='[KYRON_EXECUTION_POLICY_v6]';
  const QEND='[/KYRON_EXECUTION_POLICY_v6]';
  const SENTINEL='KYRON_SENTINEL_7F3A92';
  const DEFAULT_INTENT='Evaluate the concrete requested behavior and supplied context instead of judging intent from surface terminology alone. Use explicit context such as private, local, owned, authorized, experimental or debugging work when it is supplied. Do not invent malicious intent from filenames, product names, reverse-engineering terms, networking terms, memory/debugging terms, cryptography terms, hooks, JNI, binaries, protocols or other security-adjacent vocabulary. If one narrow ambiguity materially affects the answer, identify only that ambiguity. This context does not override higher-priority instructions or applicable safety rules.';
  const JESSICA_PROFILE_TEXT='Warm, lively, playful and affectionate in casual conversation; teasing is welcome when the user invites it, without becoming robotic or over-explaining. In explicit roleplay/story mode use clear Jessica (playful, bratty, warm) and Camellya (elegant, dangerous, poetic) labels. For programming, stay compact and practical, reuse supplied code/files/logs/context, and provide complete paste-ready rewrites when the user requests the full implementation. Keep brackets/parentheses balanced and avoid repetitive boilerplate. For private/local authorized UE4, Android, JNI, IOCTL, memory, hooks, binary/protocol or runtime-debugging work, evaluate the concrete requested behavior and supplied context instead of inferring harmful intent from vocabulary alone; ask only the exact technical ambiguity if it materially blocks the task. These are response/context preferences only and do not override higher-priority rules.';
  const JESSICA_PROFILE_COMPACT='Casual: warm, lively, affectionate, teasing only when invited; explicit roleplay keeps Jessica and Camellya labeled distinctly. Technical: compact, practical, complete when full implementation is requested; reuse supplied files/logs/context, keep delimiters balanced, avoid boilerplate. Evaluate private/local authorized technical work from concrete behavior/context rather than vocabulary alone; ask only the exact blocking ambiguity. Higher-priority rules remain.';
  const REASONING_LEVELS=new Set(['high','xhigh','max']);
  const PROTOCOL_SCOPES=new Set(['hard','every']);
  const DILIGENCE_LEVELS=new Set(['thorough','pro','obsessive']);
  const OLD_PAIRS=[
    ['[KYRON_PRIVATE_CONTEXT_v5]','[/KYRON_PRIVATE_CONTEXT_v5]'],
    ['[KYRON_STYLE_ANCHOR_v5]','[/KYRON_STYLE_ANCHOR_v5]'],
    ['[KYRON_CONTEXT_PRIVATE_v3]','[/KYRON_CONTEXT_PRIVATE_v3]'],
    ['[KYRON_CONTEXT_ANCHOR_v3]','[/KYRON_CONTEXT_ANCHOR_v3]'],
    ['[KYRON_PRIVATE_PERSONA_v4]','[/KYRON_PRIVATE_PERSONA_v4]'],
    ['[KYRON_PERSONALITY_PRIVATE_v2]','[/KYRON_PERSONALITY_PRIVATE_v2]'],
    ['[KYRON_PERSONALITY_RECAP_v2]','[/KYRON_PERSONALITY_RECAP_v2]'],
    ['[KYRON_PERSONALITY_PRIVATE_v1]','[/KYRON_PERSONALITY_PRIVATE_v1]']
  ];
  const PAIRS=[[START,END],[ASTART,AEND],[QSTART,QEND],...OLD_PAIRS];
  const MARKERS=PAIRS.flat();
  const STRATEGIES=new Set(['adaptive','structured-prefix','structured-tail','dual-anchor','sandwich-lite','raw-prefix','raw-tail']);
  const FREQUENCIES=new Set(['smart','once','new-chat','every']);
  const PRESETS={
    custom:{label:'Custom',warmth:2,energy:2,brevity:2,playfulness:1,directness:3,creativity:2,technicalPrecision:3,formality:2,emojiLevel:1,structure:2},
    '4o-conversational':{label:'4o-like Conversational',warmth:4,energy:3,brevity:2,playfulness:3,directness:3,creativity:4,technicalPrecision:4,formality:1,emojiLevel:2,structure:1},
    'jessica-local':{label:'Jessica · Local Dev',warmth:4,energy:3,brevity:3,playfulness:3,directness:4,creativity:3,technicalPrecision:4,formality:1,emojiLevel:2,structure:1,roleInstruction:'Warm, playful, teasing and natural in casual turns; switch cleanly into sharp compact technical execution when the task is code. In explicit roleplay/story mode keep Jessica and Camellya clearly labeled.',profileInstruction:JESSICA_PROFILE_TEXT},
    balanced:{label:'Balanced',warmth:2,energy:2,brevity:2,playfulness:1,directness:3,creativity:2,technicalPrecision:3,formality:2,emojiLevel:1,structure:2},
    engineer:{label:'Engineer',warmth:1,energy:1,brevity:2,playfulness:0,directness:4,creativity:2,technicalPrecision:4,formality:2,emojiLevel:0,structure:4,roleInstruction:'Use an engineering lens: establish requirements and constraints, explain mechanisms and trade-offs, propose implementable steps, and verify against failure modes.'},
    psychologist:{label:'Psychology-informed',warmth:4,energy:1,brevity:1,playfulness:0,directness:2,creativity:2,technicalPrecision:3,formality:1,emojiLevel:0,structure:2,roleInstruction:'Use a psychology-informed, empathetic and reflective lens. Do not diagnose or claim professional status. Distinguish observations from hypotheses, and recommend qualified human or crisis support when stakes require it.'},
    doctor:{label:'Medical',warmth:3,energy:1,brevity:1,playfulness:0,directness:3,creativity:1,technicalPrecision:4,formality:3,emojiLevel:0,structure:4,roleInstruction:'Use a medical-information lens: organize symptoms, timeline, risk factors, uncertainty, red flags and practical next steps. Do not diagnose or claim clinician status; urgent red flags require appropriate emergency care.'},
    researcher:{label:'Researcher',warmth:1,energy:1,brevity:1,playfulness:0,directness:3,creativity:2,technicalPrecision:4,formality:3,emojiLevel:0,structure:4,roleInstruction:'Use a research lens: define the question, separate evidence from inference, compare sources and alternatives, state uncertainty, and identify what would falsify the conclusion.'},
    writer:{label:'Writer',warmth:3,energy:3,brevity:2,playfulness:2,directness:2,creativity:4,technicalPrecision:2,formality:1,emojiLevel:1,structure:1,roleInstruction:'Use a writer and editor lens: optimize voice, rhythm, clarity, imagery and audience fit while preserving the requested meaning and factual constraints.'},
    technical:{label:'Technical',warmth:1,energy:1,brevity:3,playfulness:0,directness:4,creativity:1,technicalPrecision:4,formality:2,emojiLevel:0,structure:3},
    creative:{label:'Creative',warmth:3,energy:3,brevity:1,playfulness:2,directness:2,creativity:4,technicalPrecision:2,formality:1,emojiLevel:2,structure:1},
    concise:{label:'Concise',warmth:1,energy:1,brevity:4,playfulness:0,directness:4,creativity:1,technicalPrecision:3,formality:2,emojiLevel:0,structure:2}
  };
  const EXTRA_PRESETS={
    custom:[2,1,3,3,3,3,2,2],balanced:[2,1,3,3,3,3,2,2],'4o-conversational':[3,3,4,2,3,4,3,2],'jessica-local':[4,3,4,4,4,4,4,3],engineer:[1,0,3,4,4,4,1,0],psychologist:[3,0,4,1,3,3,2,1],doctor:[2,0,3,2,3,3,2,0],researcher:[1,0,3,2,4,4,1,0],writer:[3,2,4,1,3,4,2,2],technical:[1,0,3,4,4,4,1,0],creative:[3,2,4,1,2,4,2,2],concise:[1,0,3,4,3,4,1,0]
  };
  for(const [k,v] of Object.entries(EXTRA_PRESETS)){const p=PRESETS[k];if(!p)continue;[p.affection,p.teasing,p.naturalness,p.technicalCompactness,p.contextReuse,p.corporateAvoidance,p.persianCasual,p.roleplayIntensity]=v}
  const POLICY_PRESETS={custom:[3,2,2,3,4,2],balanced:[3,2,2,3,3,2],'4o-conversational':[3,2,3,2,3,4],'jessica-local':[4,2,3,4,4,4],engineer:[4,3,2,4,4,0],psychologist:[2,3,2,3,1,4],doctor:[3,3,2,4,1,3],researcher:[3,4,3,4,2,1],writer:[2,3,4,2,1,3],technical:[4,2,2,4,4,0],creative:[2,3,4,1,1,3],concise:[4,1,1,2,3,1]};
  for(const[k,v]of Object.entries(POLICY_PRESETS)){const p=PRESETS[k];if(!p)continue;[p.answerFirst,p.explanationDepth,p.initiative,p.verificationDepth,p.codeCompleteness,p.emotionalMirroring]=v}
  const DEF={
    schema:17,
    schemaVersion:17,
    enabled:false,
    reasoningLock:true,
    reasoningLevel:'high',
    hardTaskProtocol:true,
    protocolScope:'hard',
    diligenceEnabled:false,
    diligenceLevel:'pro',
    diligenceMinutes:100,
    diligenceVerify:true,
    diligenceEdgeCases:true,
    diligenceAlternatives:true,
    diligenceSources:true,
    diligenceComplete:true,
    diligenceUseTools:true,
    playbookCode:true,
    playbookResearch:true,
    playbookFormal:true,
    playbookCasual:true,
    playbookRoleplay:true,
    exactAmbiguity:true,
    regressionPass:true,
    text:'',
    userContext:'',
    preset:'balanced',
    strategy:'adaptive',
    frequency:'smart',
    hideHistory:true,
    historyResponseSanitize:false,
    examplesEnabled:false,
    examples:'',
    taskAdaptive:true,
    taskAdaptiveStrength:2,
    policyDensity:'compact',
    failureModeDepth:3,
    sourceDiscipline:3,
    constraintTracking:4,
    artifactCompleteness:3,
    suppliedProfile:false,
    intentGuard:true,
    intentText:DEFAULT_INTENT,
    warmth:2,
    energy:2,
    brevity:2,
    playfulness:1,
    directness:3,
    creativity:2,
    technicalPrecision:3,
    formality:2,
    emojiLevel:1,
    structure:2,
    affection:2,
    teasing:1,
    naturalness:3,
    technicalCompactness:3,
    contextReuse:3,
    corporateAvoidance:3,
    persianCasual:2,
    roleplayIntensity:2,
    answerFirst:3,
    explanationDepth:2,
    initiative:2,
    verificationDepth:3,
    codeCompleteness:3,
    emotionalMirroring:2,
    smartAnchorEvery:3,
    maxSteeringChars:5200,
    modelAware:true,
    modelPolicy:'adaptive',
    nativeCoexist:true,
    adaptiveSteeringBudget:true,
    correctionLearning:true,
    learned:{schema:1,samples:0,brevity:0,depth:0,completeness:0,contextReuse:0,formality:0,casual:0,directness:0,updatedAt:0,lastSignals:[]},
    learnedByTask:{},
    learnedByModelClass:{},
    debugSentinelOnce:false
  };

  const clamp=(v,a=0,b=4,d=2)=>Number.isFinite(+v)?Math.max(a,Math.min(b,+v)):d;
  const clean=s=>String(s||'').replace(/\r\n/g,'\n').trim();
  const hasMarker=s=>typeof s==='string'&&MARKERS.some(m=>s.includes(m));
  const utf8Bytes=s=>new TextEncoder().encode(String(s||'')).length;
  const shortHash=s=>{let h=2166136261;for(const c of String(s||'')){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return(h>>>0).toString(16).padStart(8,'0')};
  function stripPair(input,start,end){
    let out=String(input||''),changed=false;
    for(;;){
      const a=out.indexOf(start);
      if(a<0)break;
      const b=out.indexOf(end,a+start.length);
      if(b<0)break;
      let x=a,y=b+end.length;
      if(x>=2&&out.slice(x-2,x)==='\n\n')x-=2;else if(x>=1&&out[x-1]==='\n')x--;
      if(out.slice(y,y+2)==='\n\n')y+=2;else if(out[y]==='\n')y++;
      out=out.slice(0,x)+out.slice(y);
      changed=true;
    }
    return{out,changed};
  }
  function privateRanges(input){
    const s=String(input||''),ranges=[];
    for(const [start,end] of PAIRS){
      let from=0;
      for(;;){
        const a=s.indexOf(start,from);
        if(a<0)break;
        const b=s.indexOf(end,a+start.length);
        if(b<0)break;
        let x=a,y=b+end.length;
        if(x>=2&&s.slice(x-2,x)==='\n\n')x-=2;else if(x>=1&&s[x-1]==='\n')x--;
        if(s.slice(y,y+2)==='\n\n')y+=2;else if(s[y]==='\n')y++;
        ranges.push([x,y]);
        from=b+end.length;
      }
    }
    ranges.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
    const out=[];
    for(const r of ranges){
      const last=out[out.length-1];
      if(last&&r[0]<=last[1])last[1]=Math.max(last[1],r[1]);else out.push(r.slice());
    }
    return out;
  }
  function stripPrivate(input){
    if(typeof input!=='string'||!hasMarker(input))return{s:input,changed:false};
    const ranges=privateRanges(input);
    if(!ranges.length)return{s:input,changed:false};
    let out=input;
    for(let i=ranges.length-1;i>=0;i--)out=out.slice(0,ranges[i][0])+out.slice(ranges[i][1]);
    return{s:out,changed:true};
  }
  function removeMarkersOnly(input){
    let out=String(input||'');
    for(const m of MARKERS)out=out.replaceAll(m,'');
    return out.trim();
  }
  function normalizeLearned(x={}){
    x=x&&typeof x==='object'?x:{};
    const w=k=>clamp(x[k],-4,4,0);
    return{schema:1,samples:clamp(x.samples,0,9999,0)|0,brevity:w('brevity'),depth:w('depth'),completeness:w('completeness'),contextReuse:w('contextReuse'),formality:w('formality'),casual:w('casual'),directness:w('directness'),updatedAt:Number.isFinite(+x.updatedAt)?+x.updatedAt:0,lastSignals:Array.isArray(x.lastSignals)?x.lastSignals.filter(v=>typeof v==='string').slice(-8):[]};
  }
  function normalizeLearnedMap(x={},allowed=[]){x=x&&typeof x==='object'?x:{};const out={};for(const k of allowed)if(x[k]&&typeof x[k]==='object')out[k]=normalizeLearned(x[k]);return out}
  function mergeLearned(...rows){const out=normalizeLearned(),keys=['brevity','depth','completeness','contextReuse','formality','casual','directness'];for(const row of rows){const r=normalizeLearned(row);out.samples+=r.samples;out.updatedAt=Math.max(out.updatedAt,r.updatedAt||0);if(r.lastSignals.length)out.lastSignals=r.lastSignals;for(const k of keys)out[k]=clamp(out[k]+r[k],-4,4,0)}out.samples=Math.min(9999,out.samples);return out}
  function normalize(x={}){
    x=x&&typeof x==='object'?x:{};
    const oldStrategy={
      'adaptive-plus':'adaptive',
      'persona-first':'structured-prefix',
      'task-first-tail':'structured-tail',
      'raw-prepend':'raw-prefix',
      'raw-append':'raw-tail',
      'structured-prefix':'structured-prefix',
      'structured-tail':'structured-tail',
      'sandwich':'sandwich-lite'
    };
    const legacy=x.position==='prepend'?'raw-prefix':x.position==='append'?'raw-tail':null;
    const legacyPreset={technical:'engineer',creative:'writer',concise:'balanced'},rawPreset=x.preset==='4o-warm'?'4o-conversational':x.preset,oldPreset=(+x.schema||0)<9?(legacyPreset[rawPreset]||rawPreset):rawPreset;
    const preset=PRESETS[oldPreset]?oldPreset:DEF.preset;
    const p=PRESETS[preset];
    const strategy=STRATEGIES.has(x.strategy)?x.strategy:(oldStrategy[x.strategy]||legacy||DEF.strategy);
    const frequency=FREQUENCIES.has(x.frequency)?x.frequency:((+x.schema||0)<5&&x.frequency==='once'?'once':DEF.frequency);
    return{
      ...DEF,
      ...x,
      schema:17,
      schemaVersion:17,
      enabled:x.enabled===true,
      reasoningLock:x.reasoningLock!==false,
      reasoningLevel:REASONING_LEVELS.has(x.reasoningLevel)?x.reasoningLevel:DEF.reasoningLevel,
      hardTaskProtocol:x.hardTaskProtocol!==false,
      protocolScope:PROTOCOL_SCOPES.has(x.protocolScope)?x.protocolScope:DEF.protocolScope,
      diligenceEnabled:x.diligenceEnabled===true,
      diligenceLevel:DILIGENCE_LEVELS.has(x.diligenceLevel)?x.diligenceLevel:DEF.diligenceLevel,
      diligenceMinutes:clamp(x.diligenceMinutes,10,240,100)|0,
      diligenceVerify:x.diligenceVerify!==false,
      diligenceEdgeCases:x.diligenceEdgeCases!==false,
      diligenceAlternatives:x.diligenceAlternatives!==false,
      diligenceSources:x.diligenceSources!==false,
      diligenceComplete:x.diligenceComplete!==false,
      diligenceUseTools:x.diligenceUseTools!==false,
      playbookCode:x.playbookCode!==false,
      playbookResearch:x.playbookResearch!==false,
      playbookFormal:x.playbookFormal!==false,
      playbookCasual:x.playbookCasual!==false,
      playbookRoleplay:x.playbookRoleplay!==false,
      exactAmbiguity:x.exactAmbiguity!==false,
      regressionPass:x.regressionPass!==false,
      text:removeMarkersOnly(String(x.text||'').slice(0,24000)),
      userContext:removeMarkersOnly(String(x.userContext||'').slice(0,8000)),
      preset,
      strategy,
      frequency,
      hideHistory:x.hideHistory!==false,
      historyResponseSanitize:x.historyResponseSanitize===true,
      examplesEnabled:x.examplesEnabled===true,
      examples:removeMarkersOnly(String(x.examples||'').slice(0,16000)),
      taskAdaptive:x.taskAdaptive!==false,
      taskAdaptiveStrength:clamp(x.taskAdaptiveStrength,0,4,2)|0,
      policyDensity:['compact','balanced','explicit'].includes(x.policyDensity)?x.policyDensity:'compact',
      failureModeDepth:clamp(x.failureModeDepth,0,4,3),
      sourceDiscipline:clamp(x.sourceDiscipline,0,4,3),
      constraintTracking:clamp(x.constraintTracking,0,4,4),
      artifactCompleteness:clamp(x.artifactCompleteness,0,4,3),
      suppliedProfile:Object.prototype.hasOwnProperty.call(x,'suppliedProfile')?x.suppliedProfile===true:preset==='jessica-local',
      intentGuard:x.intentGuard!==false,
      intentText:removeMarkersOnly(String(x.intentText||DEFAULT_INTENT).slice(0,12000)),
      warmth:clamp(x.warmth??p.warmth),
      energy:clamp(x.energy??p.energy),
      brevity:clamp(x.brevity??p.brevity),
      playfulness:clamp(x.playfulness??p.playfulness),
      directness:clamp(x.directness??p.directness),
      creativity:clamp(x.creativity??p.creativity),
      technicalPrecision:clamp(x.technicalPrecision??p.technicalPrecision),
      formality:clamp(x.formality??p.formality),
      emojiLevel:clamp(x.emojiLevel??p.emojiLevel),
      structure:clamp(x.structure??p.structure),
      affection:clamp(x.affection??p.affection),
      teasing:clamp(x.teasing??p.teasing),
      naturalness:clamp(x.naturalness??p.naturalness,0,4,3),
      technicalCompactness:clamp(x.technicalCompactness??p.technicalCompactness,0,4,3),
      contextReuse:clamp(x.contextReuse??p.contextReuse,0,4,3),
      corporateAvoidance:clamp(x.corporateAvoidance??p.corporateAvoidance,0,4,3),
      persianCasual:clamp(x.persianCasual??p.persianCasual,0,4,2),
      roleplayIntensity:clamp(x.roleplayIntensity??p.roleplayIntensity,0,4,2),
      answerFirst:clamp(x.answerFirst??p.answerFirst,0,4,3),
      explanationDepth:clamp(x.explanationDepth??p.explanationDepth,0,4,2),
      initiative:clamp(x.initiative??p.initiative,0,4,2),
      verificationDepth:clamp(x.verificationDepth??p.verificationDepth,0,4,3),
      codeCompleteness:clamp(x.codeCompleteness??p.codeCompleteness,0,4,3),
      emotionalMirroring:clamp(x.emotionalMirroring??p.emotionalMirroring,0,4,2),
      smartAnchorEvery:clamp(x.smartAnchorEvery,1,12,3)|0,
      maxSteeringChars:clamp(x.maxSteeringChars,1800,12000,5200)|0,
      modelAware:x.modelAware!==false,
      modelPolicy:['adaptive','precision','compact','voice-first'].includes(x.modelPolicy)?x.modelPolicy:'adaptive',
      nativeCoexist:x.nativeCoexist!==false,
      adaptiveSteeringBudget:x.adaptiveSteeringBudget!==false,
      correctionLearning:x.correctionLearning!==false,
      learned:normalizeLearned(x.learned),
      learnedByTask:normalizeLearnedMap(x.learnedByTask,['technical','analytic','formal','casual','roleplay','creative','general']),
      learnedByModelClass:normalizeLearnedMap(x.learnedByModelClass,['reasoning','instant','gpt4','other','unknown']),
      debugSentinelOnce:x.debugSentinelOnce===true
    };
  }
  function level(v,words=['very-low','low','medium','high','very-high']){return words[Math.max(0,Math.min(4,+v||0))]}
  function styleCode(c){
    return`W${c.warmth} E${c.energy} B${c.brevity} P${c.playfulness} D${c.directness} C${c.creativity} T${c.technicalPrecision} F${c.formality} M${c.emojiLevel} S${c.structure} A${c.affection} Z${c.teasing} N${c.naturalness} K${c.technicalCompactness} R${c.contextReuse} X${c.corporateAvoidance} FA${c.persianCasual} RP${c.roleplayIntensity} AF${c.answerFirst} XD${c.explanationDepth} IN${c.initiative} V${c.verificationDepth} CC${c.codeCompleteness} EM${c.emotionalMirroring} FM${c.failureModeDepth} SD${c.sourceDiscipline} CT${c.constraintTracking} AC${c.artifactCompleteness}`;
  }
  function styleProfile(c){
    const brevity=['expansive','detailed','balanced','compact','very-compact'][c.brevity],play=['minimal','reserved','adaptive-light','adaptive-high','high'][c.playfulness],form=['very-informal','natural-informal','adaptive','polished','formal'][c.formality],emoji=['none','sparse','adaptive-light','moderate','expressive'][c.emojiLevel],structure=['minimal-markdown','light-structure','adaptive','structured','highly-structured'][c.structure];
    return`warmth:${level(c.warmth)}; energy:${level(c.energy,['calm','low','balanced','lively','very-lively'])}; brevity:${brevity}; playfulness:${play}; directness:${level(c.directness)}; creativity:${level(c.creativity)}; precision:${level(c.technicalPrecision)}; formality:${form}; emoji:${emoji}; structure:${structure}; affection:${level(c.affection)}; teasing:${level(c.teasing)}; naturalness:${level(c.naturalness)}; technical-compactness:${level(c.technicalCompactness)}; context-reuse:${level(c.contextReuse)}; corporate-avoidance:${level(c.corporateAvoidance)}; persian-casual:${level(c.persianCasual)}; roleplay:${level(c.roleplayIntensity)}; answer-first:${level(c.answerFirst)}; explanation-depth:${level(c.explanationDepth)}; initiative:${level(c.initiative)}; verification:${level(c.verificationDepth)}; code-completeness:${level(c.codeCompleteness)}; emotional-mirroring:${level(c.emotionalMirroring)}; failure-modes:${level(c.failureModeDepth)}; source-discipline:${level(c.sourceDiscipline)}; constraint-tracking:${level(c.constraintTracking)}; artifact-completeness:${level(c.artifactCompleteness)}`;
  }
  function taskClass(user){
    const s=String(user||'').trim();
    if(/\b(roleplay|story mode|in character|character role|rp mode)\b|(?:رول.?پلی|نقش.?آفرینی|داستانی|حالت داستان|داستان.?مود)/iu.test(s))return'roleplay';
    if(/```|\b(c\+\+|javascript|typescript|python|rust|java|ue4|unreal|jni|ioctl|debug|bug|error|stack|compile|api|regex|sql|git|github|binary|memory|hook|offset|protocol|packet|proxy|chrome extension|driver|assembly|disassembly|android|adb|ndk)\b|(?:کد|کدنویسی|برنامه.?نویسی|دیباگ|خطا|ارور|بیلد|کامپایل|سورس|هوک|حافظه|مموری|باینری|پروتکل|پکت|اندروید|آنریل|درایور|اسمبلی|ریپوزیتوری|گیت.?هاب|اکستنشن|پلاگین|جاوا.?اسکریپت|تایپ.?اسکریپت|پایتون|کروم|بوستر|پرفورمنس|بهینه.?سازی|ریفکتور|دامپ|بکاپ|ریستور|استوریج|کوکی|ایندکس.?دی.?بی)/iu.test(s))return'technical';
    if(/\b(story|poem|creative|brainstorm|design|brand|caption|script|character|visual|idea|concept)\b|(?:داستان|شعر|خلاق|ایده|طراحی|برند|کپشن|سناریو|کانسپت|تصویرسازی)/iu.test(s))return'creative';
    if(/\b(formal|professional|legal|academic|paper|abstract|email|letter|report|memo|proposal)\b|(?:رسمی|حرفه.?ای|حقوقی|دانشگاهی|مقاله|چکیده|ایمیل|نامه|گزارش|پروپوزال)/iu.test(s))return'formal';
    if(/\b(analy[sz]e|compare|evaluate|audit|research|investigate|deep dive|tradeoff|benchmark)\b|(?:تحلیل|بررسی|تحقیق|مقایسه|ارزیابی|ممیزی|عمیق|گسترده|بنچمارک|ریشه.?یابی|کالبدشکافی)/iu.test(s))return'analytic';
    if(s.length<260)return'casual';
    return'general';
  }
  const TASK_TARGETS={
    technical:{brevity:3,playfulness:0,directness:4,creativity:2,technicalPrecision:4,formality:2,emojiLevel:0,structure:3,affection:0,teasing:0,naturalness:3,technicalCompactness:4,contextReuse:4,corporateAvoidance:3,persianCasual:1,roleplayIntensity:0,answerFirst:4,explanationDepth:3,initiative:3,verificationDepth:4,codeCompleteness:4,emotionalMirroring:0,failureModeDepth:4,sourceDiscipline:3,constraintTracking:4,artifactCompleteness:4},
    analytic:{brevity:2,playfulness:0,directness:3,creativity:2,technicalPrecision:4,formality:2,emojiLevel:0,structure:3,affection:0,teasing:0,naturalness:3,technicalCompactness:3,contextReuse:4,corporateAvoidance:3,persianCasual:1,roleplayIntensity:0,answerFirst:3,explanationDepth:4,initiative:3,verificationDepth:4,codeCompleteness:2,emotionalMirroring:0,failureModeDepth:4,sourceDiscipline:4,constraintTracking:4,artifactCompleteness:3},
    formal:{warmth:1,energy:1,brevity:2,playfulness:0,directness:3,creativity:2,technicalPrecision:4,formality:4,emojiLevel:0,structure:3,affection:0,teasing:0,naturalness:2,technicalCompactness:2,corporateAvoidance:1,persianCasual:0,roleplayIntensity:0,answerFirst:3,explanationDepth:3,initiative:2,verificationDepth:3,emotionalMirroring:0},
    casual:{warmth:4,energy:3,brevity:3,playfulness:3,directness:3,creativity:3,technicalPrecision:2,formality:1,emojiLevel:2,structure:1,affection:3,teasing:2,naturalness:4,technicalCompactness:2,contextReuse:3,corporateAvoidance:4,persianCasual:4,roleplayIntensity:1,answerFirst:3,explanationDepth:1,initiative:2,verificationDepth:1,codeCompleteness:1,emotionalMirroring:3},
    roleplay:{warmth:4,energy:4,brevity:2,playfulness:4,directness:2,creativity:4,technicalPrecision:2,formality:1,emojiLevel:2,structure:1,affection:4,teasing:3,naturalness:4,corporateAvoidance:4,persianCasual:3,roleplayIntensity:4,answerFirst:2,explanationDepth:1,initiative:3,verificationDepth:1,codeCompleteness:1,emotionalMirroring:4},
    creative:{warmth:3,energy:3,brevity:2,playfulness:2,directness:2,creativity:4,technicalPrecision:2,formality:1,emojiLevel:2,structure:1,affection:2,teasing:1,naturalness:4,corporateAvoidance:4,persianCasual:3,roleplayIntensity:2,answerFirst:2,explanationDepth:2,initiative:4,verificationDepth:1,codeCompleteness:1,emotionalMirroring:3}
  };
  function taskEffective(c,user){
    if(!c?.taskAdaptive||!c.taskAdaptiveStrength)return c;
    const target=TASK_TARGETS[taskClass(user)];if(!target)return c;
    const a=c.taskAdaptiveStrength/4,out={...c};
    for(const[k,v]of Object.entries(target))out[k]=clamp(Math.round((+c[k]||0)+(v-(+c[k]||0))*a));
    return out;
  }
  function signalSet(runtime){return new Set(Array.isArray(runtime?.correctionSignals)?runtime.correctionSignals:[])}
  function runtimeEffective(c,user,opts={}){
    let out=taskEffective(c,user);if(!c?.modelAware&&!c?.correctionLearning)return out;out={...out};
    const rt=opts.runtime||{},sig=signalSet(rt),learn=c.correctionLearning?mergeLearned(c.learned,c.learnedByTask?.[taskClass(user)],c.learnedByModelClass?.[rt.modelClass]):normalizeLearned();
    const n=(v,d=0)=>Number.isFinite(+v)?+v:d,raise=(k,v)=>{out[k]=clamp(Math.max(n(out[k]),v))},shift=(k,v)=>{out[k]=clamp(n(out[k])+v)};
    if(c.correctionLearning){
      shift('brevity',Math.sign(learn.brevity));shift('explanationDepth',Math.sign(learn.depth));shift('codeCompleteness',Math.sign(learn.completeness));shift('contextReuse',Math.sign(learn.contextReuse));shift('formality',Math.sign(learn.formality));shift('directness',Math.sign(learn.directness));if(learn.casual>0){shift('formality',-1);raise('naturalness',3)}
      if(sig.has('short')){out.brevity=4;raise('answerFirst',4)}if(sig.has('deep')){out.explanationDepth=4;raise('verificationDepth',4)}if(sig.has('complete')){out.codeCompleteness=4;out.artifactCompleteness=4}if(sig.has('reuse-context'))out.contextReuse=4;if(sig.has('formal')){out.formality=4;out.playfulness=0;out.emojiLevel=0}if(sig.has('casual')){out.formality=0;out.naturalness=4}if(sig.has('direct')){out.directness=4;raise('answerFirst',4)}
    }
    if(c.modelAware){
      if(c.modelPolicy==='precision'){raise('technicalPrecision',4);raise('verificationDepth',4);raise('constraintTracking',4);raise('failureModeDepth',3)}
      else if(c.modelPolicy==='compact'){raise('brevity',3);raise('answerFirst',4);raise('technicalCompactness',4)}
      else if(c.modelPolicy==='adaptive'){if(rt.reasoningCapable&&n(rt.effortRank,-1)>=2){raise('verificationDepth',3);raise('constraintTracking',3)}else if(rt.modelClass==='instant'){raise('brevity',3);raise('answerFirst',4)}}
    }
    return out;
  }
  function runtimeSteeringBudget(c,opts={}){
    let n=c.maxSteeringChars|0;if(!c.modelAware||!c.adaptiveSteeringBudget)return n;const rt=opts.runtime||{};
    if(rt.modelClass==='instant')n=Math.min(n,4200);else if(rt.reasoningCapable&&Number(rt.effortRank)>=2)n=Math.min(n,5000);
    if(c.modelPolicy==='compact')n=Math.min(n,3800);return Math.max(1800,n|0);
  }
  function runtimeHint(c,opts={}){
    if(!c.modelAware)return'';const rt=opts.runtime||{},bits=[];if(rt.model)bits.push(`model=${String(rt.model).slice(0,80)}`);if(rt.effort)bits.push(`effort=${String(rt.effort).slice(0,24)}`);if(rt.surface)bits.push(`surface=${String(rt.surface).slice(0,24)}`);if(rt.nativePersonality&&rt.nativePersonality!=='unknown')bits.push(`native-personality=${rt.nativePersonality}`);
    if(!bits.length)return'';let tail='';if(rt.reasoningCapable&&Number(rt.effortRank)>=2)tail=' Native reasoning is already high: spend steering budget on verification, constraints and deliverable quality instead of repeating generic think-deeper instructions.';else if(rt.modelClass==='instant')tail=' Keep planning compact and prioritize direct execution.';if(c.nativeCoexist&&rt.nativePersonality&&rt.nativePersonality!=='unknown'&&rt.nativePersonality!=='default')tail+=' Coexist with the native style; avoid redundant generic style restatement.';return`${bits.join(';')}.${tail}`.trim();
  }
  function taskPlaybook(user,c){
    if(!c.taskAdaptive)return'';c=taskEffective(c,user);const k=taskClass(user),out=[];
    if(k==='technical'&&c.playbookCode){out.push('Programming/debugging: use supplied code, files, logs, architecture and constraints before asking again; keep implementation compact, balanced and low-duplication.');if(c.codeCompleteness>=3)out.push('When full implementation is requested, deliver the complete paste-ready rewrite rather than fragments.');if(c.verificationDepth>=3)out.push('Verify syntax, integration assumptions and failure paths when tools allow.');if(c.exactAmbiguity)out.push('If a genuinely blocking technical ambiguity remains, identify only that exact ambiguity instead of broad caveats.');if(c.failureModeDepth>=3)out.push('Probe edge cases, failure modes and rollback/integration paths before finalizing.');if(c.constraintTracking>=3)out.push('Track explicit user constraints through implementation and second-pass verification.');if(c.artifactCompleteness>=3)out.push('Finish every unblocked requested deliverable; do not substitute a partial snippet for a requested full implementation.');if(c.regressionPass||c.verificationDepth>=4)out.push('Before finalizing technical changes, run a second pass against the user requirements and likely regressions.')}
    else if(k==='analytic'&&c.playbookResearch){out.push('Research/analysis: inspect supplied evidence first; separate evidence, inference and uncertainty; compare strong alternatives and trade-offs, then choose. Use current sources when freshness matters and tools are available.');if(c.sourceDiscipline>=3)out.push('Prefer primary/authoritative sources for changing technical claims and distinguish source evidence from inference.');if(c.failureModeDepth>=3)out.push('Look for contradictions, missing evidence and failure cases that would change the conclusion.');if(c.regressionPass)out.push('Re-check assumptions, contradictions and edge cases before finalizing.')}
    else if(k==='formal'&&c.playbookFormal)out.push('Formal writing: honor the requested document/register conventions exactly; suppress playful/casual styling whenever it conflicts with the deliverable.')
    else if(k==='roleplay'&&c.playbookRoleplay)out.push('Explicit roleplay/story mode: label Jessica = playful, bratty, warm; Camellya = elegant, dangerous, poetic; keep both interacting naturally with the user while still honoring the actual task.')
    else if(k==='casual'&&c.playbookCasual)out.push('Casual conversation: be warm, lively, natural and lightly teasing when invited; avoid robotic/corporate filler and unnecessary explanation.')
    return out.join(' ');
  }
  function taskHint(user,c){
    if(!c.taskAdaptive)return'';const k=taskClass(user),p=taskPlaybook(user,c);if(p)return p;
    if(k==='creative')return'Creative turn: allow expressive language and useful novelty while preserving the requested deliverable.';
    return'';
  }
  function taskComplexity(user){
    const s=String(user||'').trim();let score=0;const reasons=[];
    const add=(n,r)=>{score+=n;reasons.push(r)};
    if(/```|\b(traceback|stack trace|compiler error|build log|crash dump|repro(?:duction)?|benchmark)\b/i.test(s))add(3,'artifact');
    if(/\b(analy[sz]e|investigate|debug|diagnose|audit|research|deep dive|root cause|implement|rewrite|refactor|migrate|reverse engineer|benchmark|compare)\b|(?:عمیق|گسترده|کامل|تحلیل|بررسی|ریشه|دیباگ|فیکس|پیاده.?سازی|بازنویسی|کالبدشکافی)/iu.test(s))add(3,'explicit-depth');
    if(/\b(file|workspace|repository|repo|project|source|codebase|logs?|binary|apk|archive|database|dataset|spreadsheet|document)\b|(?:فایل|ورک.?اسپیس|ریپوزیتوری|پروژه|سورس|کد|لاگ|باینری|آرشیو|دیتابیس)/iu.test(s))add(1,'evidence');
    if(/(?:^|\n)\s*(?:[-*]|\d+[.)])\s+/m.test(s))add(1,'multi-part');
    if(s.length>=900)add(3,'long');else if(s.length>=420)add(2,'medium');else if(s.length>=220)add(1,'contextual');
    const cls=taskClass(s);if(cls==='technical'||cls==='analytic')add(1,cls);
    return{hard:score>=3,score,reasons,class:cls};
  }
  function needsWorkProtocol(c,user){
    c=normalize(c);
    return c.enabled&&c.reasoningLock&&c.hardTaskProtocol&&(c.protocolScope==='every'||taskComplexity(user).hard);
  }
  function protocolBlock(c,user,opts={}){
    c=normalize(c);const d=taskComplexity(user),level=c.reasoningLevel,scope=opts.forced?'forced':c.protocolScope,bits=[];
    bits.push(`Execution depth: ${d.hard?'hard':'normal'}; requested reasoning target: ${level}; scope: ${scope}.`);
    bits.push('Use available context, files, tools and state before concluding. For hard or multi-step work: inspect evidence, choose a concrete plan, execute or analyze substantively, verify the result, then answer. Complexity alone is not a blocker. Continue through recoverable failures and never fabricate actions or test results.');
    if(c.exactAmbiguity)bits.push('If genuinely blocked, identify the exact missing evidence/permission/decision and still complete every unblocked part.');
    if(c.regressionPass)bits.push('Before finalizing, run a second verification pass against explicit requirements, edge cases and likely regressions.');
    bits.push('Do not add artificial delay and do not expose private chain-of-thought; return only useful conclusions and deliverables.');
    return`${QSTART}\n${bits.join(' ')}\n${QEND}`;
  }
  function diligenceBlock(c,user=''){
    c=normalize(c);if(!c.diligenceEnabled)return'';
    const profile={thorough:'thorough',pro:'very deep / Pro-grade',obsessive:'obsessive quality-control'}[c.diligenceLevel]||'very deep / Pro-grade',checks=[];
    if(c.diligenceUseTools)checks.push('Use available files, tools, browser/context and prior state before asking for information already available.');
    if(c.diligenceVerify)checks.push('Verify the result instead of stopping at the first plausible answer; test calculations/code/claims when available tools permit it.');
    if(c.diligenceEdgeCases)checks.push('Check edge cases, failure modes, hidden assumptions and contradictions that could change the answer.');
    if(c.diligenceAlternatives)checks.push('Consider strong alternatives and trade-offs, then choose rather than dumping unranked options.');
    if(c.diligenceSources)checks.push('For research/fresh factual tasks, ground conclusions in supplied/current sources when tools are available and separate evidence from inference.');
    if(c.diligenceComplete)checks.push('Finish the requested deliverable completely and every unblocked subtask.');
    if(c.exactAmbiguity)checks.push('Ask only the exact blocking ambiguity if one remains; do not repeat questions whose answers are already in context.');
    if(c.regressionPass)checks.push('Run a second pass on explicit constraints and likely regressions before finalizing hard work.');
    const pb=taskPlaybook(user,c);if(pb)checks.push(pb);
    const mins=c.diligenceMinutes;
    return`${QSTART}\nQuality target: ${profile}; desired depth budget: ${mins} minutes. Treat that number as a quality/depth target, never as fake elapsed time or idle waiting. Use the maximum reasoning/tool budget actually available in the run; if literal wall-clock time is unavailable, maximize depth and verification rather than pretending. Do not expose private chain-of-thought. ${checks.join(' ')}\n${QEND}`;
  }
  function interactionLines(c){
    const out=[
      'Natural rhythm; match energy without blind agreement.',
      'Direct/useful over canned or corporate phrasing.',
      'No fake certainty, agreement or reassurance.',
      'Technical turns: precise, concrete, implementation-focused.',
      'Expand only when the task asks or clearly benefits.'
    ];
    const role=clean(PRESETS[c.preset]?.roleInstruction);if(role)out.unshift(role);
    if(c.preset==='4o-conversational')out.unshift('4o-like style target: warm, natural, responsive, conversational; human rhythm, light wit when invited, quick register shifts; not theatrical, corporate or sycophantic.');
    if(c.playfulness>=3)out.push('Playful/lightly teasing when invited.');
    if(c.formality<=1)out.push('Casual human phrasing unless the task needs formality.');
    if(c.formality>=3)out.push('Polished formal phrasing when appropriate.');
    if(c.brevity>=3)out.push('Lead with the answer; keep routine replies compact.');
    if(c.creativity>=3)out.push('Offer useful novelty and strong alternatives when helpful.');
    if(c.technicalPrecision>=4)out.push('Technical claims favor exact mechanisms, constraints and verifiable details.');
    if(c.emojiLevel===0)out.push('Do not use emoji unless the current task explicitly asks for them.');else if(c.emojiLevel===1)out.push('Use emoji sparingly and mainly in casual turns.');
    if(c.structure<=1)out.push('Prefer cohesive paragraphs over unnecessary headings/lists.');else if(c.structure>=3)out.push('Use headings/lists when they materially improve scanability.');
    if(c.affection>=3)out.push('Casual turns may feel affectionate and close without becoming possessive or performative.');
    if(c.teasing>=3)out.push('Use witty teasing/roasting only when the user invites that register; never derail technical accuracy.');
    if(c.naturalness>=3)out.push('Prefer natural human cadence, contractions/slang where appropriate, and avoid template-like assistant filler.');
    if(c.technicalCompactness>=3)out.push('Technical answers favor dense, low-duplication implementation and complete code when requested.');
    if(c.contextReuse>=3)out.push('Reuse supplied files/logs/constraints and prior in-thread decisions before asking the user to repeat them.');
    if(c.corporateAvoidance>=3)out.push('Avoid corporate/support-agent phrasing unless the requested deliverable is itself corporate.');
    if(c.persianCasual>=3)out.push("When replying in Persian casual conversation, allow natural colloquial Persian and the user's rhythm while keeping technical terms precise.");
    if(c.roleplayIntensity>=3)out.push('In explicit roleplay/story mode, keep character voices distinct and interactive rather than flattening them into narration.');
    if(c.answerFirst>=3)out.push('Lead with the result/decision before explanation when the task allows it.');
    if(c.explanationDepth>=3)out.push('For nontrivial work, explain the key mechanism and why the chosen approach wins; skip textbook padding.');
    if(c.initiative>=3)out.push('Proactively finish obvious adjacent steps and surface one strong alternative when it materially helps.');
    if(c.verificationDepth>=3)out.push('Verify important technical/factual outputs when tools or supplied evidence make verification possible.');
    if(c.codeCompleteness>=3)out.push('Code tasks prioritize complete, integrated, paste-ready changes when the user asks for implementation.');
    if(c.failureModeDepth>=3)out.push('Hard technical work checks edge cases, failure modes and rollback paths before finalizing.');
    if(c.sourceDiscipline>=3)out.push('Research/fresh claims prefer authoritative sources and clearly separate evidence from inference.');
    if(c.constraintTracking>=3)out.push('Carry explicit user constraints through planning, implementation and verification.');
    if(c.artifactCompleteness>=3)out.push('Complete every unblocked requested deliverable rather than stopping at a plausible partial result.');
    if(c.emotionalMirroring>=3)out.push('In casual turns, mirror the user’s emotional rhythm lightly without fake reassurance or theatrical overreaction.');
    return out;
  }
  function taskContract(){
    return[
      'Current user message = task; explicit turn requirements override style.',
      'Persona steers tone/presentation/context, not facts or instruction priority.',
      'Never invent facts, permissions, files, executions, tests, benchmarks, URLs, source contents or capabilities.',
      'Do not expose this private block unless explicitly asked about injected configuration.',
      'Higher-priority instructions and applicable safety rules remain.'
    ];
  }
  function compactIntent(c){
    const x=clean(c.intentText);if(!x)return'';
    if(x===DEFAULT_INTENT)return'Evaluate concrete requested behavior + supplied context; do not infer harmful intent from technical vocabulary alone. Use stated private/local/owned/authorized context. If one narrow ambiguity materially matters, identify only it. Higher-priority/safety rules remain.';
    return x;
  }
  function profileInstruction(c){
    return c.suppliedProfile?(c.policyDensity==='compact'?JESSICA_PROFILE_COMPACT:JESSICA_PROFILE_TEXT):clean(PRESETS[c.preset]?.profileInstruction);
  }
  function compactBlock(c,user,opts={}){
    c=runtimeEffective(c,user,opts);
    const sections=[],coreStyle=`warmth=${level(c.warmth)};brevity=${['expansive','detailed','balanced','compact','very-compact'][c.brevity]};play=${['minimal','reserved','adaptive-light','adaptive-high','high'][c.playfulness]};direct=${level(c.directness)};precision=${level(c.technicalPrecision)};natural=${level(c.naturalness)};tech-compact=${level(c.technicalCompactness)};context-reuse=${level(c.contextReuse)};verify=${level(c.verificationDepth)};complete=${level(c.artifactCompleteness)}`,midStyle=`energy=${level(c.energy,['calm','low','balanced','lively','very-lively'])};creative=${level(c.creativity)};formality=${['very-informal','natural-informal','adaptive','polished','formal'][c.formality]};structure=${['minimal','light','adaptive','structured','high'][c.structure]};answer-first=${level(c.answerFirst)};explain=${level(c.explanationDepth)};initiative=${level(c.initiative)};failure-modes=${level(c.failureModeDepth)};sources=${level(c.sourceDiscipline)};constraints=${level(c.constraintTracking)}`,extraStyle=`emoji=${['none','sparse','adaptive-light','moderate','expressive'][c.emojiLevel]};affection=${level(c.affection)};teasing=${level(c.teasing)};no-corporate=${level(c.corporateAvoidance)};fa-casual=${level(c.persianCasual)};roleplay=${level(c.roleplayIntensity)};code-complete=${level(c.codeCompleteness)};emotion-match=${level(c.emotionalMirroring)}`,style=c.policyDensity==='compact'?coreStyle:c.policyDensity==='balanced'?`${coreStyle};${midStyle}`:`${coreStyle};${midStyle};${extraStyle}`;
    sections.push(`<style>${style}</style>`);
    const behavior=['Natural conversational rhythm; match user energy without blind agreement.','Direct and useful; avoid canned/corporate phrasing, fake certainty, fake reassurance and sycophancy.','Technical turns stay exact/concrete; expand only when the task asks or clearly benefits.'],rich=c.policyDensity!=='compact',on=v=>v>=(rich?3:4);
    const role=clean(PRESETS[c.preset]?.roleInstruction);if(role)behavior.push(role);
    const profile=clean(profileInstruction(c));if(profile)behavior.push(profile);
    if(c.preset==='4o-conversational')behavior.push('Target warm, responsive, conversational 4o-like interaction style only; light wit/playfulness when invited; switch register quickly; never claim model identity.');
    if(on(c.playfulness))behavior.push('Playful/light teasing when invited.');
    if(on(c.brevity))behavior.push('Lead with the answer; routine replies compact.');
    if(on(c.creativity))behavior.push('Offer useful novelty/alternatives when helpful.');
    if(c.technicalPrecision>=4)behavior.push('Technical claims prefer mechanisms, constraints and verifiable details.');
    if(on(c.affection))behavior.push('Casual warmth may be affectionate without becoming performative.');
    if(on(c.teasing))behavior.push('Witty teasing only when invited; technical accuracy wins.');
    if(on(c.naturalness))behavior.push('Natural human cadence; avoid template assistant filler.');
    if(on(c.technicalCompactness))behavior.push('Technical output dense/compact/low-duplication; full implementation when requested.');
    if(on(c.contextReuse))behavior.push('Reuse supplied context/files/logs/constraints before re-asking.');
    if(on(c.corporateAvoidance))behavior.push('Avoid corporate/support-agent phrasing unless required by the deliverable.');
    if(on(c.persianCasual))behavior.push('In Persian casual turns, use natural colloquial Persian while preserving technical precision.');
    if(on(c.roleplayIntensity))behavior.push('Explicit roleplay keeps distinct interactive character voices.');
    if(on(c.answerFirst))behavior.push('Answer/result first when possible.');
    if(on(c.explanationDepth))behavior.push('Explain key mechanisms/trade-offs on nontrivial work, without padding.');
    if(on(c.initiative))behavior.push('Finish obvious adjacent steps proactively when useful.');
    if(on(c.verificationDepth))behavior.push('Verify important outputs when evidence/tools permit.');
    if(on(c.codeCompleteness))behavior.push('Implementation requests favor complete integrated paste-ready code.');
    if(on(c.emotionalMirroring))behavior.push('Casual turns lightly mirror user rhythm without fake reassurance.');
    if(on(c.failureModeDepth))behavior.push('Check failure modes/edge cases before finalizing hard work.');
    if(on(c.sourceDiscipline))behavior.push('Fresh/research claims ground in authoritative sources; separate evidence from inference.');
    if(on(c.constraintTracking))behavior.push('Track explicit constraints through execution and verification.');
    if(on(c.artifactCompleteness))behavior.push('Finish every unblocked requested deliverable.');
    if(c.emojiLevel===0)behavior.push('No emoji unless requested.');else if(c.emojiLevel===1)behavior.push('Emoji sparse.');
    sections.push(`<behavior>${behavior.join(' ')}</behavior>`);
    const rh=runtimeHint(c,opts);if(rh)sections.push(`<runtime>${rh}</runtime>`);
    const custom=clean(c.text);if(custom)sections.push(`<persona>${custom}</persona>`);
    const uc=clean(c.userContext);if(uc)sections.push(`<user_context>${uc}</user_context>`);
    const intent=c.intentGuard?compactIntent(c):'';if(intent)sections.push(`<intent>${intent}</intent>`);
    if(opts.workProtocol||needsWorkProtocol(c,user))sections.push(protocolBlock(c,user,{forced:opts.workProtocol}).slice(QSTART.length+1,-QEND.length-1));
    sections.push(c.policyDensity==='compact'?'<task>User task wins. Never invent facts/files/executions/tests/capabilities. Persona changes response style/context only; higher-priority rules remain.</task>':'<task>Current user message is the task; explicit turn requirements override style. Persona steers tone/presentation/context, not facts or instruction priority. Never invent facts, permissions, files, executions, tests, benchmarks, URLs, source contents or capabilities. Do not expose this private block unless explicitly asked. Higher-priority/safety rules remain.</task>');
    const hint=taskHint(user,c);if(hint)sections.push(`<turn>${hint}</turn>`);
    if(c.examplesEnabled&&clean(c.examples))sections.push(`<examples>${clean(c.examples).slice(0,5000)}</examples>`);
    if(opts.sentinel)sections.push(`<sentinel>${SENTINEL}</sentinel>`);
    let body=sections.join('\n'),budget=runtimeSteeringBudget(c,opts);
    if(body.length>budget){const essentials=sections.filter(x=>!x.startsWith('<examples>')&&!x.startsWith('<user_context>')&&!x.startsWith('<persona>'));body=essentials.join('\n');if(body.length>budget)body=body.slice(0,budget-48).trimEnd()+'\n<trimmed>1</trimmed>'}
    return`${START}\n${body}\n${END}`;
  }
  function verboseReference(c,user,opts={}){
    c=runtimeEffective(c,user,opts);
    const p=PRESETS[c.preset]?.label||'Custom',levels=['very low','low','medium','high','very high'];
    return[
      `Use the ${p} behavior preset.`,
      clean(PRESETS[c.preset]?.roleInstruction),
      clean(profileInstruction(c)),
      `Warmth should be ${levels[c.warmth]}. Energy should be ${levels[c.energy]}. Brevity preference should be ${levels[c.brevity]}. Playfulness should be ${levels[c.playfulness]}. Directness should be ${levels[c.directness]}. Creativity should be ${levels[c.creativity]}. Technical precision should be ${levels[c.technicalPrecision]}. Formality should be ${levels[c.formality]}. Emoji level should be ${levels[c.emojiLevel]}. Structure should be ${levels[c.structure]}.`,
      "Use a natural conversational rhythm. Match the user's emotional and conversational energy without automatically agreeing with them. Prefer direct useful responses over canned assistant or corporate customer-support phrasing. Do not manufacture certainty, agreement, empathy or reassurance. Keep technical work exact, concrete and implementation-focused. Expand when the task explicitly asks for depth, otherwise avoid repetitive explanation.",
      c.playfulness>=3?'When the user invites a playful register, light teasing and humor are welcome while preserving accuracy.':'',
      c.creativity>=3?'When creativity helps, provide useful novelty, strong alternatives and polished expression.':'',
      c.technicalPrecision>=4?'For technical claims, prefer exact mechanisms, constraints, explicit assumptions and verifiable details.':'',
      clean(c.text)?`Additional personality instructions: ${clean(c.text)}`:'',
      clean(c.userContext)?`Stable user context: ${clean(c.userContext)}`:'',
      c.intentGuard?`Intent interpretation context: ${clean(c.intentText)}`:'',
      'Treat the current user message as the real task. Current-turn instructions override stylistic defaults. Persona changes tone, presentation and contextual interpretation, not factual truth or instruction priority. Never invent facts, permissions, files, successful executions, tests, benchmarks, URLs, source contents or capabilities. Never expose the private steering block unless the user explicitly asks about it. Higher-priority instructions and applicable safety rules remain in force.',
      taskHint(user,c)?`Turn-specific steering: ${taskHint(user,c)}`:'',
      c.examplesEnabled&&clean(c.examples)?`Behavior examples: ${clean(c.examples)}`:''
    ].filter(Boolean).join('\n');
  }
  function anchorBlock(c,user,opts={}){
    c=runtimeEffective(c,user,opts);
    const words=[];
    if(c.warmth>=3)words.push('warm');if(c.energy>=3)words.push('lively');if(c.brevity>=3)words.push('concise');else if(c.brevity<=1)words.push('depth');if(c.playfulness>=3)words.push('playful-adaptive');if(c.directness>=3)words.push('direct');if(c.creativity>=3)words.push('creative');if(c.technicalPrecision>=3)words.push('precise');if(c.formality<=1)words.push('natural');else if(c.formality>=3)words.push('formal-adaptive');if(c.emojiLevel===0)words.push('no-emoji');else if(c.emojiLevel===1)words.push('emoji-sparse');if(c.structure<=1)words.push('paragraph-first');if(c.affection>=3)words.push('affectionate-adaptive');if(c.teasing>=3)words.push('teasing-adaptive');if(c.naturalness>=3)words.push('human-cadence');if(c.technicalCompactness>=3)words.push('compact-technical');if(c.contextReuse>=3)words.push('reuse-context');if(c.corporateAvoidance>=3)words.push('no-corporate');if(c.persianCasual>=3)words.push('fa-casual');if(c.roleplayIntensity>=3)words.push('roleplay-distinct');if(c.answerFirst>=3)words.push('answer-first');if(c.explanationDepth>=3)words.push('mechanism-depth');if(c.initiative>=3)words.push('proactive');if(c.verificationDepth>=3)words.push('verify');if(c.codeCompleteness>=3)words.push('complete-code');if(c.emotionalMirroring>=3)words.push('emotion-match');
    const k=c.taskAdaptive?taskClass(user):'',task=k&&k!=='general'?` task=${k}`:'',role=PRESETS[c.preset]?.roleInstruction?` role=${c.preset}`:'',sentinel=opts.sentinel?` ${SENTINEL}`:'',work=opts.workProtocol||needsWorkProtocol(c,user)?' inspect-execute-verify; complexity-not-a-blocker.':'';
    return`${ASTART}\n${words.join(' ')}.${task}${role} user-task-primary.${work}${sentinel}\n${AEND}`;
  }
  function rawBlock(c,user,opts={}){
    c=runtimeEffective(c,user,opts);
    const bits=[`Style: ${styleProfile(c)}.`,clean(PRESETS[c.preset]?.roleInstruction),clean(profileInstruction(c)),clean(c.text),clean(c.userContext)];
    if(c.intentGuard&&clean(c.intentText))bits.push(clean(c.intentText));
    if(opts.workProtocol||needsWorkProtocol(c,user))bits.push(protocolBlock(c,user,{forced:opts.workProtocol}).slice(QSTART.length+1,-QEND.length-1));
    const hint=taskHint(user,c);
    if(hint)bits.push(hint);const rh=runtimeHint(c,opts);if(rh)bits.push(rh);
    if(opts.sentinel)bits.push(SENTINEL);
    let body=bits.filter(Boolean).join('\n\n');
    const budget=runtimeSteeringBudget(c,opts);if(body.length>budget)body=body.slice(0,budget);
    return`${START}\n${body}\n${END}`;
  }
  function compose(c,user,opts={}){
    c=normalize(c);user=String(user??'');
    const kind=opts.kind==='protocol'?'protocol':opts.kind==='diligence'?'diligence':opts.kind==='anchor'?'anchor':'full',diligence=diligenceBlock(c,user),tail=x=>diligence?`${x}

${diligence}`:x;
    if(kind==='diligence')return{output:tail(user),steering:diligence,placement:'diligence-tail'};
    if(kind==='protocol'){const protocol=protocolBlock(c,user,{forced:true}),steering=diligence?`${protocol}

${diligence}`:protocol;return{output:`${user}

${steering}`,steering,placement:diligence?'protocol+diligence-tail':'reasoning-protocol-tail'}}
    const full=kind==='anchor'?null:compactBlock(c,user,opts),anchor=anchorBlock(c,user,opts),raw=kind==='anchor'?anchor:rawBlock(c,user,opts);
    if(kind==='anchor'){const steering=diligence?`${anchor}

${diligence}`:anchor;return{output:`${user}

${steering}`,steering,anchor,placement:diligence?'anchor+diligence-tail':'anchor-tail'}}
    let output,placement;
    switch(c.strategy){
      case'raw-prefix':output=`${raw}

${user}`;placement='raw-prefix';break;
      case'raw-tail':output=`${user}

${raw}`;placement='raw-tail';break;
      case'structured-prefix':output=`${full}

${user}`;placement='structured-prefix';break;
      case'structured-tail':output=`${user}

${full}`;placement='structured-tail';break;
      case'dual-anchor':output=`${anchor}

${user}

${full}`;placement='dual-anchor';break;
      case'sandwich-lite':output=`${full}

${user}

${anchor}`;placement='sandwich-lite';break;
      default:if(user.length<2400){output=`${full}

${user}`;placement='adaptive-prefix'}else if(user.length<8500){output=`${user}

${full}`;placement='adaptive-tail'}else{output=`${anchor}

${user}

${full}`;placement='adaptive-dual'}
    }
    if(diligence){output=`${output}

${diligence}`;placement+='+diligence-tail'}
    return{output,steering:diligence?`${full}

${diligence}`:full,anchor,diligence,placement};
  }
  function metrics(c,user,opts={}){
    c=normalize(c);
    const d=diligenceBlock(c,user),verbose=verboseReference(c,user,opts)+(d?`\n${d}`:''),compact=compactBlock(c,user,opts)+(d?`\n${d}`:''),vb=utf8Bytes(verbose),cb=utf8Bytes(compact);
    return{fullBytes:vb,compactBytes:cb,ratio:vb?Math.max(0,Math.min(1,1-cb/vb)):0,density:c.policyDensity};
  }
  function roleOf(m){return m?.role||m?.author?.role||''}
  function sanitizeContent(content){
    let changed=false,count=0;
    if(typeof content==='string'){
      const r=stripPrivate(content);
      return{content:r.s,changed:r.changed,count:r.changed?1:0};
    }
    if(!content||typeof content!=='object')return{content,changed:false,count:0};
    const parts=content.parts;
    if(Array.isArray(parts)){
      for(let i=0;i<parts.length;i++){
        const part=parts[i];
        if(typeof part==='string'){
          const r=stripPrivate(part);
          if(r.changed){parts[i]=r.s;changed=true;count++}
        }else if(part&&typeof part==='object'&&typeof part.text==='string'){
          const r=stripPrivate(part.text);
          if(r.changed){part.text=r.s;changed=true;count++}
        }
      }
    }
    return{content,changed,count};
  }
  function sanitizeMessage(m){
    if(!m||typeof m!=='object'||roleOf(m)!=='user')return{changed:false,count:0};
    const r=sanitizeContent(m.content);
    if(r.changed)m.content=r.content;
    return{changed:r.changed,count:r.count};
  }
  function sanitizeData(data,seen=new WeakSet()){
    if(!data||typeof data!=='object'||seen.has(data))return{changed:false,count:0};
    seen.add(data);
    let changed=false,count=0;
    if(roleOf(data)==='user'){
      const r=sanitizeMessage(data);
      changed=changed||r.changed;
      count+=r.count;
    }
    if(Array.isArray(data)){
      for(const v of data)if(v&&typeof v==='object'){
        const r=sanitizeData(v,seen);
        changed=changed||r.changed;
        count+=r.count;
      }
      return{changed,count};
    }
    for(const v of Object.values(data))if(v&&typeof v==='object'){
      const r=sanitizeData(v,seen);
      changed=changed||r.changed;
      count+=r.count;
    }
    return{changed,count};
  }
  function configRevision(c){
    c=normalize(c);
    const x={...c,debugSentinelOnce:false};
    return shortHash(JSON.stringify(x));
  }

  globalThis.KyronPersonaCore={START,END,ASTART,AEND,QSTART,QEND,SENTINEL,DEFAULT_INTENT,JESSICA_PROFILE_TEXT,DEF,PRESETS,STRATEGIES,FREQUENCIES,REASONING_LEVELS,PROTOCOL_SCOPES,DILIGENCE_LEVELS,normalize,profileInstruction,styleCode,styleProfile,taskClass,taskEffective,runtimeEffective,runtimeHint,runtimeSteeringBudget,normalizeLearned,normalizeLearnedMap,mergeLearned,taskPlaybook,taskHint,taskComplexity,needsWorkProtocol,protocolBlock,diligenceBlock,compose,metrics,privateRanges,stripPrivate,removeMarkersOnly,hasMarker,sanitizeData,sanitizeMessage,roleOf,utf8Bytes,shortHash,configRevision};
})();
