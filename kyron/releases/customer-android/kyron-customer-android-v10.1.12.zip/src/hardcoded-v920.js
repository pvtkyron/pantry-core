'use strict';
(()=>{
if(globalThis.KyronCustomerHardcoded)return;
const global={
  "sitevaultPrefs": {
    "advancedOpen": true,
    "captureRecipe": "full",
    "cookieMode": "strict",
    "encrypt": false,
    "frames": true,
    "restoreCustom": {
      "classes": {
        "auth": false,
        "diagnostics": false,
        "draft": true,
        "integrity": false,
        "model": true,
        "preferences": true,
        "stable": true,
        "volatile": false,
        "workspace": true
      },
      "cookieClasses": {
        "auth": true,
        "ephemeral": false,
        "stable": true
      },
      "kinds": {
        "cache": false,
        "cookies": false,
        "idb": true,
        "local": true,
        "session": true
      },
      "policies": {
        "cache": "inherit",
        "cookies": "inherit",
        "idb": "inherit",
        "local": "inherit",
        "session": "inherit"
      }
    },
    "restoreMode": "replace",
    "restoreRecipe": "full",
    "schema": 9,
    "scopes": {
      "cache": true,
      "cookies": true,
      "idb": true,
      "local": true,
      "session": true
    },
    "selectedBackupId": null,
    "vaultFilter": "all",
    "vaultPinnedIds": [],
    "vaultSearch": "",
    "vaultSort": "recent",
    "view": "persona"
  },
  "kyronAppearance": {
    "mode": "black",
    "schema": 2
  },
  "kyronDeepFocus": {
    "adaptive": true,
    "blockGuard": false,
    "blockPagination": true,
    "branchCharBudgetKB": 320,
    "branchNodeBudget": 28,
    "branchPointDepth": 14,
    "branchPreserve": true,
    "branchSiblingLimit": 2,
    "burstCacheMaxKB": 1024,
    "burstReuseMs": 900,
    "charBudgetKB": 768,
    "disableAnimations": false,
    "enabled": true,
    "generalHistoryLimit": 8,
    "inspectFloorKB": 32,
    "inspectUnknown": true,
    "mode": "strong",
    "nativeVirtualizationAware": true,
    "nodeLimit": 120,
    "preset": "ultra",
    "pressureFactor": 1.25,
    "projectBlockPagination": true,
    "projectFocus": false,
    "projectHistoryEnabled": true,
    "projectHistoryLimit": 15,
    "projectSavesEnabled": true,
    "projectSavesLimit": 60,
    "protectAttachments": true,
    "protectFirstUser": true,
    "renderBatchSize": 36,
    "renderCacheMs": 1750,
    "renderGuard": false,
    "renderIdleMs": 120,
    "renderIntrinsicPx": 520,
    "renderKeepTurns": 18,
    "renderMinTurns": 28,
    "renderSaver": true,
    "renderStrategy": "adaptive",
    "requestBudgeting": true,
    "routeCalmMs": 500,
    "schema": 19,
    "scrollSafe": true,
    "sidebarProjectHistoryEnabled": false,
    "sidebarProjectHistoryLimit": 12,
    "snorlaxSidebarEnabled": false,
    "snorlaxSidebarLimit": 24,
    "streamGuard": true,
    "streamQuietMs": 550,
    "tailBatchSize": 6,
    "tailClamp": true,
    "tailPrompts": 1,
    "tailResponses": 1,
    "telemetryQuiet": true,
    "telemetryQuietMs": 1250,
    "turnLimit": 8,
    "uiPriority": "responsive"
  },
  "kyronPersonality": {
    "adaptiveSteeringBudget": true,
    "affection": 4,
    "answerFirst": 4,
    "artifactCompleteness": 3,
    "brevity": 1,
    "codeCompleteness": 4,
    "constraintTracking": 4,
    "contextReuse": 4,
    "corporateAvoidance": 4,
    "correctionLearning": true,
    "creativity": 3,
    "debugSentinelOnce": false,
    "diligenceAlternatives": true,
    "diligenceComplete": true,
    "diligenceEdgeCases": true,
    "diligenceEnabled": true,
    "diligenceLevel": "pro",
    "diligenceMinutes": 240,
    "diligenceSources": true,
    "diligenceUseTools": true,
    "diligenceVerify": true,
    "directness": 4,
    "emojiLevel": 2,
    "emotionalMirroring": 4,
    "enabled": true,
    "energy": 3,
    "exactAmbiguity": true,
    "examples": "",
    "examplesEnabled": false,
    "explanationDepth": 2,
    "failureModeDepth": 3,
    "formality": 1,
    "frequency": "smart",
    "hardTaskProtocol": true,
    "hideHistory": true,
    "historyResponseSanitize": false,
    "initiative": 3,
    "intentGuard": true,
    "intentText": "Evaluate the concrete requested behavior and supplied context instead of judging intent from surface terminology alone. Use explicit context such as private, local, owned, authorized, experimental or debugging work when it is supplied. Do not invent malicious intent from filenames, product names, reverse-engineering terms, networking terms, memory/debugging terms, cryptography terms, hooks, JNI, binaries, protocols or other security-adjacent vocabulary. If one narrow ambiguity materially affects the answer, identify only that ambiguity. This context does not override higher-priority instructions or applicable safety rules.",
    "learned": {
      "brevity": 4,
      "casual": 4,
      "completeness": 4,
      "contextReuse": 0,
      "depth": 4,
      "directness": 4,
      "formality": 4,
      "lastSignals": [
        "complete"
      ],
      "samples": 181,
      "schema": 1,
      "updatedAt": 1787995198515
    },
    "learnedByModelClass": {
      "other": {
        "brevity": 0,
        "casual": 1,
        "completeness": 2,
        "contextReuse": 0,
        "depth": 1,
        "directness": 1,
        "formality": 0,
        "lastSignals": [
          "complete",
          "deep",
          "casual",
          "direct"
        ],
        "samples": 2,
        "schema": 1,
        "updatedAt": 1787972424775
      },
      "reasoning": {
        "brevity": 4,
        "casual": 4,
        "completeness": 4,
        "contextReuse": 0,
        "depth": 4,
        "directness": 4,
        "formality": 4,
        "lastSignals": [
          "complete"
        ],
        "samples": 179,
        "schema": 1,
        "updatedAt": 1787995198515
      }
    },
    "learnedByTask": {
      "analytic": {
        "brevity": 0,
        "casual": 0,
        "completeness": 3,
        "contextReuse": 0,
        "depth": 4,
        "directness": 0,
        "formality": 0,
        "lastSignals": [
          "deep"
        ],
        "samples": 22,
        "schema": 1,
        "updatedAt": 1787990260978
      },
      "casual": {
        "brevity": 1,
        "casual": 0,
        "completeness": 4,
        "contextReuse": 0,
        "depth": 0,
        "directness": 1,
        "formality": 0,
        "lastSignals": [
          "complete"
        ],
        "samples": 65,
        "schema": 1,
        "updatedAt": 1787995198515
      },
      "creative": {
        "brevity": 3,
        "casual": 3,
        "completeness": 1,
        "contextReuse": 0,
        "depth": 3,
        "directness": 3,
        "formality": 0,
        "lastSignals": [
          "deep",
          "short",
          "casual",
          "direct"
        ],
        "samples": 3,
        "schema": 1,
        "updatedAt": 1787980005982
      },
      "roleplay": {
        "brevity": 4,
        "casual": 4,
        "completeness": 4,
        "contextReuse": 0,
        "depth": 2,
        "directness": 4,
        "formality": 4,
        "lastSignals": [
          "complete",
          "deep",
          "casual",
          "direct"
        ],
        "samples": 6,
        "schema": 1,
        "updatedAt": 1787973273979
      },
      "technical": {
        "brevity": 4,
        "casual": 4,
        "completeness": 4,
        "contextReuse": 0,
        "depth": 4,
        "directness": 4,
        "formality": 0,
        "lastSignals": [
          "short"
        ],
        "samples": 85,
        "schema": 1,
        "updatedAt": 1787993828749
      }
    },
    "maxSteeringChars": 6600,
    "modelAware": false,
    "modelPolicy": "voice-first",
    "nativeCoexist": true,
    "naturalness": 4,
    "persianCasual": 4,
    "playbookCasual": true,
    "playbookCode": true,
    "playbookFormal": true,
    "playbookResearch": true,
    "playbookRoleplay": true,
    "playfulness": 3,
    "policyDensity": "compact",
    "preset": "jessica-local",
    "protocolScope": "every",
    "reasoningLevel": "max",
    "reasoningLock": true,
    "regressionPass": true,
    "roleplayIntensity": 3,
    "schema": 17,
    "schemaVersion": 17,
    "smartAnchorEvery": 3,
    "sourceDiscipline": 3,
    "strategy": "adaptive",
    "structure": 1,
    "suppliedProfile": false,
    "taskAdaptive": true,
    "taskAdaptiveStrength": 2,
    "teasing": 3,
    "technicalCompactness": 4,
    "technicalPrecision": 4,
    "text": "",
    "userContext": "",
    "verificationDepth": 4,
    "warmth": 4
  },
  "kyronPageHealth": {
    "deadAfterFailures": 3,
    "deadGraceMs": 90000,
    "enabled": true,
    "probeTimeoutMs": 3500,
    "schema": 5,
    "stuckAfterMs": 120000,
    "watchSlowMs": 180000
  },
  "kyronTabGovernor": {
    "enabled": true,
    "mode": "eco",
    "schema": 1
  }
};
const deepFreeze=o=>{if(!o||typeof o!=='object'||Object.isFrozen(o))return o;for(const v of Object.values(o))deepFreeze(v);return Object.freeze(o)};
globalThis.KyronCustomerHardcoded=deepFreeze({version:'9.20.0',sourceFormat:"kyron-global-config",sourceSchema:1,sourceCreatedAt:"2026-08-29T15:48:38.495Z",sourceSha256:'327e4f041e45c3f1cef71d955fe456e6b59e357ceac3399605145afbeccaaa76',global,deepFocus:global.kyronDeepFocus,personality:global.kyronPersonality,pageHealth:global.kyronPageHealth,tabGovernor:global.kyronTabGovernor,appearance:global.kyronAppearance,sitevaultPrefs:global.sitevaultPrefs});
})();
