(()=>{
  if(window.top!==window||window.__KYRON_PERSONA_ENGINE_V6__||window.__KYRON_PERSONA_ENGINE_V5__)return;
  const C=globalThis.KyronPersonaCore;
  if(!C)return;
  const clock=()=>globalThis.performance?.now?.()??Date.now();

  let cfg=C.normalize(C.DEF),rev=C.configRevision(cfg),pendingNew=null,lastHref=location.href,modelPolicy={schema:2,enabled:true,model:'gpt-5-6',modelLock:true,effortLock:true,effort:'high',effortMode:'exact',surface:'all',fallback:'preserve'};
  const perf={prepares:0,injections:0,anchors:0,bypasses:0,verified:0,totalCompileMs:0,maxCompileMs:0,lastCompileMs:0,lastBytes:0,lastKind:'',lastReason:'',lastTask:'general',lastModel:'',lastModelClass:'',lastEffort:'',lastSurface:'',lastNativePersonality:'unknown',lastCorrectionSignals:[],density:cfg.policyDensity};
  const seenOnce=new Set(),smartState=new Map();
  const SEND_PATH=/^\/(?:backend-api|backend-anon)\/(?:[a-z0-9_-]+\/)*conversation(?:\/(?:submit|send))?$/i,RESPONSES_PATH=/^\/(?:backend-api|backend-anon)\/(?:[a-z0-9_-]+\/)*(?:responses?|chat\/completions)$/i;
  const EFFORT_RANK={none:0,instant:0,minimal:0,min:0,low:0,standard:1,medium:1,extended:2,high:2,xhigh:3,max:4,ultra:5};
  const INTERNAL_EFFORT={high:'extended',xhigh:'xhigh',max:'max'},API_EFFORT={high:'high',xhigh:'xhigh',max:'max'},POLICY={instant:{slug:'gpt-5-6-instant',internal:'',api:''},medium:{slug:'gpt-5-6-thinking',internal:'standard',api:'medium'},high:{slug:'gpt-5-6-thinking',internal:'extended',api:'high'},xhigh:{slug:'gpt-5-6-thinking',internal:'xhigh',api:'xhigh'},max:{slug:'gpt-5-6-thinking',internal:'max',api:'max'}};

  function isPromptSend(method,u){if(method!=='POST')return false;const p=u.pathname.replace(/\/+$/,'');return SEND_PATH.test(p)||RESPONSES_PATH.test(p)}
  function quickInterest(raw,method='GET'){const s=String(raw||''),m=String(method||'GET').toUpperCase();if(m==='POST')return /\/(?:backend-api|backend-anon)\/(?:[a-z0-9_-]+\/)*(?:conversation(?:\/(?:submit|send))?|responses?|chat\/completions)(?:[?#]|$)/i.test(s);return cfg.enabled&&cfg.hideHistory!==false&&cfg.historyResponseSanitize===true&&/\/(?:backend-api|backend-anon)\/(?:[a-z0-9_-]+\/)*(?:conversation|conversations|shared_conversation)\/[^/?#]+(?:[?#]|$)/i.test(s)}
  function syncRoute(){
    if(location.href===lastHref)return;
    lastHref=location.href;
    if(!/\/c\//.test(location.pathname))pendingNew=null;
  }
  function conversationId(data){
    return String(data?.conversation_id||data?.conversationId||'').trim();
  }
  function messageArrays(data){const out=[];for(const v of[data?.messages,data?.input,data?.request?.messages,data?.request?.input,data?.payload?.messages,data?.payload?.input,data?.body?.messages,data?.body?.input])if(Array.isArray(v)&&!out.includes(v))out.push(v);return out}
  function latestUserMessage(data){for(const a of messageArrays(data))for(let i=a.length-1;i>=0;i--)if(C.roleOf(a[i])==='user')return a[i];return null}
  function latestUserText(data){const m=latestUserMessage(data),t=textTarget(m);if(t)return String(t.get()||'');for(const v of[data?.input,data?.request?.input,data?.payload?.input,data?.body?.input])if(typeof v==='string'&&v.trim())return v;return''}
  function modelOf(data){
    for(const v of[data?.backend_model,data?.model_slug,data?.model,data?.requested_default_model])if(typeof v==='string'&&v.trim())return v.trim();
    return'';
  }
  function normalizeModelPolicy(v={}){
    v=v&&typeof v==='object'?v:{};
    const model=['gpt-5-6','native'].includes(String(v.model))?String(v.model):'gpt-5-6',effort=['instant','medium','high','xhigh','max'].includes(String(v.effort))?String(v.effort):'high';
    return{schema:2,enabled:v.enabled!==false,model,modelLock:model!=='native'&&v.modelLock!==false,effortLock:v.effortLock!==false,effort,effortMode:['exact','minimum'].includes(String(v.effortMode))?String(v.effortMode):'exact',surface:['all','chat','work','project'].includes(String(v.surface))?String(v.surface):'all',fallback:'preserve'};
  }
  function policySurface(data){
    if(data?.chat_mode==='work'||/\/(?:work|workspace)(?:\/|$)/i.test(location.pathname))return'work';
    if(/\/(?:g\/g-p-|project\/)/i.test(location.pathname))return'project';
    return'chat';
  }
  function policyTarget(data){
    const p=normalizeModelPolicy(modelPolicy),surface=policySurface(data),applies=p.surface==='all'||p.surface===surface,map=POLICY[p.effort]||POLICY.high;
    return{...p,surfaceNow:surface,applies,...map};
  }
  function patchModelPolicy(data){
    const t=policyTarget(data),rows=[],seen=new Set(),current=modelOf(data);
    if(!t.enabled||!t.applies||!t.modelLock||t.model==='native'||!data||typeof data!=='object')return{supported:false,changed:false,target:current,fields:[],surface:t.surfaceNow,policy:t};
    const patch=(o,path='')=>{if(!o||typeof o!=='object'||seen.has(o))return;seen.add(o);for(const k of['backend_model','model_slug','model','requested_default_model'])if(k in o&&typeof o[k]==='string'){const before=o[k];if(before!==t.slug)o[k]=t.slug;rows.push({field:path?path+'.'+k:k,before,after:o[k],changed:before!==o[k]})}};
    patch(data);patch(data.request,'request');patch(data.payload,'payload');patch(data.body,'body');
    return{supported:rows.length>0,changed:rows.some(x=>x.changed),target:t.slug,fields:rows.map(x=>x.field),rows,surface:t.surfaceNow,policy:t};
  }
  function reasoningModel(data){
    const model=modelOf(data);
    return data?.chat_mode==='work'||'backend_thinking_effort'in(data||{})||'thinking_effort'in(data||{})||!!data?.reasoning||/(?:gpt[-_.]?5|thinking|codex|sol|terra|luna|^o[134](?:-|$))/i.test(model);
  }
  function effortRank(v){return EFFORT_RANK[String(v??'').toLowerCase()]??-1}
  function patchReasoningEffort(data){
    const model=modelOf(data),pt=policyTarget(data),controller=pt.enabled&&pt.applies&&pt.effortLock,persona=cfg.enabled&&cfg.reasoningLock,target=controller?pt.effort:cfg.reasoningLevel,mode=data?.chat_mode==='work'||'backend_model'in(data||{})?'work':'chat',rows=[],seen=new Set();
    if(!data||typeof data!=='object'||!controller&&!persona)return{supported:false,changed:false,model,mode,target,surface:pt.surfaceNow};
    const exact=controller&&pt.effortMode==='exact',set=(obj,key,want,path='')=>{if(!obj||typeof obj!=='object'||seen.has(path+':'+key))return;seen.add(path+':'+key);const had=Object.prototype.hasOwnProperty.call(obj,key),before=had?obj[key]:null,keep=!exact&&had&&effortRank(before)>=effortRank(want),after=keep?before:want;if(!had||after!==before)obj[key]=after;rows.push({field:path?path+'.'+key:key,before:had?String(before):'missing',after:String(after),changed:!had||after!==before})};
    const known=reasoningModel(data),internal=controller?pt.internal:INTERNAL_EFFORT[target],api=controller?pt.api:API_EFFORT[target];
    if(controller&&pt.effort==='instant'){
      if(exact){for(const k of['backend_thinking_effort','thinking_effort','backend_reasoning_effort','reasoning_effort','reasoningEffort'])if(Object.prototype.hasOwnProperty.call(data,k)){const before=data[k];delete data[k];rows.push({field:k,before:String(before),after:'removed',changed:true})}if(data.reasoning&&typeof data.reasoning==='object'&&Object.prototype.hasOwnProperty.call(data.reasoning,'effort')){const before=data.reasoning.effort;delete data.reasoning.effort;rows.push({field:'reasoning.effort',before:String(before),after:'removed',changed:true})}}
      return{supported:rows.length>0||known,changed:rows.some(x=>x.changed),model,mode,target,fields:rows.map(x=>x.field),before:rows.map(x=>x.field+'='+x.before).join(','),after:rows.map(x=>x.field+'='+x.after).join(','),rows,surface:pt.surfaceNow,policy:pt};
    }
    if(mode==='work'||'backend_thinking_effort'in data)set(data,'backend_thinking_effort',internal);if('thinking_effort'in data||known&&mode!=='work'&&!data.reasoning)set(data,'thinking_effort',internal);if('backend_reasoning_effort'in data)set(data,'backend_reasoning_effort',api);if('reasoning_effort'in data)set(data,'reasoning_effort',api);if('reasoningEffort'in data)set(data,'reasoningEffort',api);if(data.reasoning&&typeof data.reasoning==='object')set(data.reasoning,'effort',api,'reasoning');
    const changed=rows.some(x=>x.changed),supported=rows.length>0;return{supported,changed,model,mode,target,fields:rows.map(x=>x.field),before:rows.map(x=>x.field+'='+x.before).join(','),after:rows.map(x=>x.field+'='+x.after).join(','),rows,surface:pt.surfaceNow,policy:pt};
  }
  function plan(data,userText=latestUserText(data)){
    if(!cfg.enabled)return{inject:false,kind:'none',reason:'disabled'};
    syncRoute();
    const cid=conversationId(data),sentinel=cfg.debugSentinelOnce===true;
    if(sentinel)return{inject:true,kind:'full',reason:'sentinel',cid,sentinel:true};
    if(cfg.frequency==='every')return{inject:true,kind:'full',reason:'every-message',cid};
    if(cfg.frequency==='new-chat'){
      if(cid)return{inject:false,kind:'none',reason:'existing-conversation',cid};
      if(pendingNew?.mode==='new-chat')return{inject:false,kind:'none',reason:'new-chat-already-sent',cid};
      pendingNew={mode:'new-chat',rev};
      return{inject:true,kind:'full',reason:'new-conversation',cid};
    }
    if(cfg.frequency==='once'){
      if(cid){
        if(pendingNew?.mode==='once'){
          seenOnce.add(cid);
          pendingNew=null;
          return{inject:false,kind:'none',reason:'first-turn-already-steered',cid};
        }
        if(seenOnce.has(cid))return{inject:false,kind:'none',reason:'already-steered',cid};
        seenOnce.add(cid);
        return{inject:true,kind:'full',reason:'first-seen-conversation',cid};
      }
      if(pendingNew?.mode==='once')return{inject:false,kind:'none',reason:'pending-new-chat',cid};
      pendingNew={mode:'once',rev};
      return{inject:true,kind:'full',reason:'new-conversation',cid};
    }
    if(cid){
      const taskClass=C.taskClass(userText);
      if(pendingNew?.mode==='smart'){
        smartState.set(cid,{rev:pendingNew.rev,turns:1,taskClass});
        pendingNew=null;
        return{inject:false,kind:'none',reason:'smart-bound-after-full',cid};
      }
      const st=smartState.get(cid);
      if(!st||st.rev!==rev){
        smartState.set(cid,{rev,turns:1,taskClass});
        return{inject:true,kind:'full',reason:st?'settings-changed':'smart-first-turn',cid};
      }
      st.turns=(st.turns||1)+1;
      const classChanged=!!st.taskClass&&st.taskClass!==taskClass&&taskClass!=='general'&&st.taskClass!=='general';
      st.taskClass=taskClass;
      smartState.set(cid,st);
      if(classChanged)return{inject:true,kind:'anchor',reason:'smart-task-shift',cid};
      if(st.turns%cfg.smartAnchorEvery===0)return{inject:true,kind:'anchor',reason:`smart-anchor-${cfg.smartAnchorEvery}`,cid};
      return{inject:false,kind:'none',reason:'smart-sparse-pass',cid};
    }
    if(pendingNew?.mode==='smart'&&pendingNew.rev===rev)return{inject:false,kind:'none',reason:'smart-pending-pass',cid};
    pendingNew={mode:'smart',rev};
    return{inject:true,kind:'full',reason:'smart-new-conversation',cid};
  }
  function messageRole(m){
    return C.roleOf(m);
  }
  function textTarget(m){
    if(!m||messageRole(m)!=='user')return null;
    if(Array.isArray(m?.content?.parts)){
      for(let i=m.content.parts.length-1;i>=0;i--){
        const p=m.content.parts[i];
        if(typeof p==='string')return{get:()=>m.content.parts[i],set:v=>{m.content.parts[i]=v}};
        if(p&&typeof p==='object'&&typeof p.text==='string')return{get:()=>p.text,set:v=>{p.text=v}};
      }
    }
    if(Array.isArray(m?.content)){
      for(let i=m.content.length-1;i>=0;i--){const p=m.content[i];if(typeof p==='string')return{get:()=>m.content[i],set:v=>{m.content[i]=v}};if(p&&typeof p==='object'&&typeof p.text==='string')return{get:()=>p.text,set:v=>{p.text=v}}}
    }
    if(typeof m.content==='string')return{get:()=>m.content,set:v=>{m.content=v}};
    if(typeof m.text==='string')return{get:()=>m.text,set:v=>{m.text=v}};
    return null;
  }
  function injectCompiled(target,original,decision,meta,messageId=''){
    if(!original||C.hasMarker(original))return false;
    const runtime=meta.runtime||window.__KYRON_PERSONA_INTEL__?.snapshot?.()||{},t0=clock(),compiled=C.compose(cfg,original,{kind:decision.kind,sentinel:decision.sentinel,runtime}),ms=+(clock()-t0).toFixed(2),bytes=C.utf8Bytes(compiled.steering);
    target(compiled.output);Object.assign(meta,{original,messageId,conversationId:decision.cid||'',kind:decision.kind,reason:decision.reason,placement:compiled.placement,originalChars:original.length,steeringChars:compiled.steering.length,markerVersion:6,fullBytes:null,compactBytes:bytes,compressionRatio:null,policyDensity:cfg.policyDensity,modelClass:runtime.modelClass||'',reasoningEffort:runtime.effort||'',surface:runtime.surface||'',nativePersonality:runtime.nativePersonality||'unknown',correctionSignals:Array.isArray(runtime.correctionSignals)?runtime.correctionSignals.slice(0,8):[],steeringBudget:C.runtimeSteeringBudget(cfg,{runtime}),sentinel:decision.sentinel===true,diligence:cfg.diligenceEnabled===true,diligenceLevel:cfg.diligenceLevel,diligenceMinutes:cfg.diligenceMinutes,compileMs:ms});
    perf.injections++;if(decision.kind==='anchor')perf.anchors++;perf.totalCompileMs+=ms;perf.maxCompileMs=Math.max(perf.maxCompileMs,ms);Object.assign(perf,{lastCompileMs:ms,lastBytes:bytes,lastKind:decision.kind,lastReason:decision.reason,lastModel:runtime.model||'',lastModelClass:runtime.modelClass||'',lastEffort:runtime.effort||'',lastSurface:runtime.surface||'',lastNativePersonality:runtime.nativePersonality||'unknown',lastCorrectionSignals:Array.isArray(runtime.correctionSignals)?runtime.correctionSignals.slice(0,8):[],density:cfg.policyDensity});return true;
  }
  function injectData(data,decision,meta){
    if(!data||typeof data!=='object'||!decision.inject)return false;
    for(const list of messageArrays(data))for(let i=list.length-1;i>=0;i--){const m=list[i],target=textTarget(m);if(!target)continue;const original=target.get();return injectCompiled(v=>target.set(v),original,decision,meta,String(m?.id||m?.message_id||''))}
    for(const [obj,key]of[[data,'input'],[data?.request,'input'],[data?.payload,'input'],[data?.body,'input']])if(obj&&typeof obj[key]==='string'&&obj[key].trim())return injectCompiled(v=>{obj[key]=v},obj[key],decision,meta,'');
    return false;
  }
  async function bodyText(args){
    const [input,init]=args;
    if(typeof init?.body==='string')return init.body;
    if(input instanceof Request){
      try{return await input.clone().text()}catch{return null}
    }
    return null;
  }
  function replaceBody(args,body){
    const [input,init]=args;
    if(input instanceof Request){
      try{return[new Request(input,{...(init||{}),body})]}catch{return[input,{...(init||{}),body}]}
    }
    return[input,{...(init||{}),body}];
  }
  function endpointOf(u){
    return u.pathname.replace(/\/+$/,'');
  }
  function emit(kind,u,meta={}){
    const detail={type:'persona',kind,endpoint:endpointOf(u),strategy:cfg.strategy,frequency:cfg.frequency,preset:cfg.preset,smartAnchorEvery:cfg.smartAnchorEvery,at:Date.now(),...meta};
    if(detail.conversationId){
      detail.conversationHash=C.shortHash(detail.conversationId);
      delete detail.conversationId;
    }
    window.postMessage({__kyronDeepFocus:'stats',detail},location.origin);
  }
  function textNodes(root){
    const out=[];
    if(!root)return out;
    if(document.createTreeWalker&&globalThis.NodeFilter){
      const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
      for(let n=w.nextNode();n;n=w.nextNode())out.push(n);
      return out;
    }
    const walk=n=>{for(const c of n?.childNodes||[]){if(c?.nodeType===3)out.push(c);else walk(c)}};
    walk(root);
    return out;
  }
  function stripRowMarkers(row){
    let nodes=textNodes(row);
    if(!nodes.length&&row?.querySelectorAll){
      const boxes=[...row.querySelectorAll('.whitespace-pre-wrap,[data-testid="collapsible-user-message-content"] .whitespace-pre-wrap')];
      let changed=false;
      for(const box of boxes){
        const raw=String(box.textContent||'');
        if(!C.hasMarker(raw))continue;
        const r=C.stripPrivate(raw);
        if(!r.changed)continue;
        box.textContent=r.s;box.setAttribute?.('data-kyron-persona-hidden','1');changed=true;
      }
      return changed;
    }
    if(!nodes.length)return false;
    const raw=nodes.map(n=>String(n.data??n.nodeValue??'')).join('');
    if(!C.hasMarker(raw))return false;
    const ranges=C.privateRanges(raw);
    if(!ranges.length)return false;
    const spans=[];let off=0;
    for(const n of nodes){const text=String(n.data??n.nodeValue??''),end=off+text.length;spans.push({n,start:off,end});off=end}
    for(let i=ranges.length-1;i>=0;i--){
      const [a,b]=ranges[i];
      for(let j=spans.length-1;j>=0;j--){
        const x=spans[j];
        if(x.end<=a||x.start>=b)continue;
        const text=String(x.n.data??x.n.nodeValue??''),l=Math.max(0,a-x.start),r=Math.min(text.length,b-x.start),next=text.slice(0,l)+text.slice(r);
        if('data'in x.n)x.n.data=next;else x.n.nodeValue=next;
      }
    }
    row.setAttribute?.('data-kyron-persona-hidden','1');
    return true;
  }
  function scrubVisible(meta=null){
    if(cfg.hideHistory===false||typeof document.querySelectorAll!=='function')return false;
    let changed=false;const rows=[...document.querySelectorAll('[data-message-author-role="user"]')].slice(-18);
    for(const row of rows){if(meta?.messageId&&row.getAttribute?.('data-message-id')&&row.getAttribute('data-message-id')!==meta.messageId)continue;changed=stripRowMarkers(row)||changed}
    return changed;
  }
  function armBubbleGuard(meta){
    if(cfg.hideHistory===false||!meta?.original)return()=>{};
    let timer=null,done=false;
    const scan=()=>{if(done)return false;const hit=scrubVisible(meta);if(hit)done=true;return hit};
    scan();
    if(!done&&typeof setTimeout==='function')timer=setTimeout(()=>{timer=null;scan();done=true},750);
    return()=>{done=true;if(timer)clearTimeout(timer)};
  }
  function stateSnapshot(){
    return{pendingNew:pendingNew?{...pendingNew}:null,seenOnce:new Set(seenOnce),smartState:new Map([...smartState].map(([k,v])=>[k,{...v}]))};
  }
  function restoreSnapshot(x){
    if(!x)return;
    pendingNew=x.pendingNew?{...x.pendingNew}:null;
    seenOnce.clear();for(const v of x.seenOnce||[])seenOnce.add(v);
    smartState.clear();for(const [k,v] of x.smartState||[])smartState.set(k,{...v});
  }
  function commit(txn,u){
    if(!txn?.changed&&!txn?.observed)return;
    const meta=txn.meta||{};
    if(meta.original)armBubbleGuard(meta)
    const kind=meta.effortSupported?(meta.effortChanged?'locked':'verified'):(meta.kind==='anchor'?'anchored':meta.original?'injected':'bypassed');
    if(kind==='verified')perf.verified++;if(kind==='bypassed')perf.bypasses++;perf.lastKind=kind;perf.lastReason=meta.reason||'';
    emit(kind,u,{reason:meta.reason,placement:meta.placement,originalChars:meta.originalChars,steeringChars:meta.steeringChars,markerVersion:6,fullBytes:meta.fullBytes,compactBytes:meta.compactBytes,compressionRatio:meta.compressionRatio,conversationId:meta.conversationId,model:meta.model,chatMode:meta.chatMode,reasoningTarget:meta.reasoningTarget,effortFields:meta.effortFields,effortBefore:meta.effortBefore,effortAfter:meta.effortAfter,effortChanged:meta.effortChanged,protocol:meta.protocol,diligence:meta.diligence,diligenceLevel:meta.diligenceLevel,diligenceMinutes:meta.diligenceMinutes,promptKind:meta.kind,taskClass:meta.taskClass,policyDensity:meta.policyDensity,modelClass:meta.modelClass,reasoningEffort:meta.reasoningEffort,surface:meta.surface,nativePersonality:meta.nativePersonality,correctionSignals:meta.correctionSignals,steeringBudget:meta.steeringBudget,compileMs:meta.compileMs});
    if(meta.sentinel)window.postMessage({__kyronPersonaEngine:'sentinel-consumed'},location.origin);
  }
  function rollback(txn,u,reason='send-failed'){
    if(!txn?.snapshot)return;
    restoreSnapshot(txn.snapshot);
    emit('bypassed',u,{reason,rolledBack:true});
  }
  async function prepare(args,u,method){
    if(!isPromptSend(method,u))return{args,changed:false};
    perf.prepares++;
    const raw=await bodyText(args);
    if(!raw){perf.bypasses++;perf.lastReason='empty-body';emit('bypassed',u,{reason:'empty-body'});return{args,changed:false}}
    let data;
    try{data=JSON.parse(raw)}catch{perf.bypasses++;perf.lastReason='non-json-body';emit('bypassed',u,{reason:'non-json-body'});return{args,changed:false}}
    const snapshot=stateSnapshot(),user=latestUserText(data),taskClass=C.taskClass(user),intel=window.__KYRON_PERSONA_INTEL__,runtime=intel?.observePrompt?.(data,user,taskClass,cfg)||intel?.snapshot?.()||{},planned=plan(data,user),protocol=C.needsWorkProtocol(cfg,user),diligence=cfg.diligenceEnabled===true,decision=protocol&&!planned.inject?{inject:true,kind:'protocol',reason:'hard-task-protocol',cid:planned.cid||conversationId(data)}:diligence&&!planned.inject?{inject:true,kind:'diligence',reason:'always-diligence-tail',cid:planned.cid||conversationId(data)}:planned,modelPatch=patchModelPolicy(data),effort=patchReasoningEffort(data),meta={model:modelPatch.target||effort.model,modelChanged:modelPatch.changed,modelFields:modelPatch.fields,chatMode:effort.mode,reasoningTarget:effort.target,effortSupported:effort.supported,effortChanged:effort.changed,effortFields:effort.fields,effortBefore:effort.before,effortAfter:effort.after,protocol,diligence,diligenceLevel:cfg.diligenceLevel,diligenceMinutes:cfg.diligenceMinutes,taskClass,runtime};Object.assign(perf,{lastTask:taskClass,lastModel:runtime.model||effort.model||'',lastModelClass:runtime.modelClass||'',lastEffort:runtime.effort||'',lastSurface:runtime.surface||'',lastNativePersonality:runtime.nativePersonality||'unknown',lastCorrectionSignals:runtime.correctionSignals||[],density:cfg.policyDensity});
    let injected=false;
    if(decision.inject)injected=injectData(data,decision,meta);
    if(decision.inject&&!injected&&!effort.changed&&!modelPatch.changed){restoreSnapshot(snapshot);perf.bypasses++;perf.lastReason='no-supported-user-text';emit('bypassed',u,{reason:'no-supported-user-text',model:effort.model,reasoningTarget:effort.target});return{args,changed:false}}
    const changed=modelPatch.changed||effort.changed||injected,observed=(modelPatch.supported||effort.supported)&&!changed;
    if(!changed&&!observed)return{args,changed:false,decision};
    if(!meta.reason)meta.reason=modelPatch.changed?'model-policy-applied':effort.changed?'minimum-reasoning-raised':'minimum-reasoning-verified';
    return{args:changed?replaceBody(args,JSON.stringify(data)):args,changed,observed,meta,snapshot,decision};
  }
  function stripSerialized(raw){
    raw=String(raw||'');
    if(!raw.includes('KYRON_'))return{raw,changed:false,count:0};
    let out=raw,changed=false,count=0;
    const pairs=[[C.START,C.END],[C.ASTART,C.AEND],['[KYRON_CONTEXT_PRIVATE_v3]','[/KYRON_CONTEXT_PRIVATE_v3]'],['[KYRON_CONTEXT_ANCHOR_v3]','[/KYRON_CONTEXT_ANCHOR_v3]'],['[KYRON_PRIVATE_PERSONA_v4]','[/KYRON_PRIVATE_PERSONA_v4]'],['[KYRON_PERSONALITY_PRIVATE_v2]','[/KYRON_PERSONALITY_PRIVATE_v2]'],['[KYRON_PERSONALITY_RECAP_v2]','[/KYRON_PERSONALITY_RECAP_v2]'],['[KYRON_PERSONALITY_PRIVATE_v1]','[/KYRON_PERSONALITY_PRIVATE_v1]']];
    for(const [start,end] of pairs)for(;;){
      const a=out.indexOf(start);if(a<0)break;
      const b=out.indexOf(end,a+start.length);if(b<0)break;
      let x=a,y=b+end.length;
      if(x>=4&&out.slice(x-4,x)==='\\n\\n')x-=4;else if(x>=2&&out.slice(x-2,x)==='\\n')x-=2;else if(x>=2&&out.slice(x-2,x)==='\n\n')x-=2;else if(x>=1&&out[x-1]==='\n')x--;
      if(out.slice(y,y+4)==='\\n\\n')y+=4;else if(out.slice(y,y+2)==='\\n')y+=2;else if(out.slice(y,y+2)==='\n\n')y+=2;else if(out[y]==='\n')y++;
      out=out.slice(0,x)+out.slice(y);changed=true;count++;
    }
    return{raw:out,changed,count};
  }
  function textResponse(raw,res,contentType=null){
    const h=new Headers(res.headers);
    h.delete('content-length');
    h.delete('content-encoding');
    if(contentType)h.set('content-type',contentType);
    const out=new Response(raw,{status:res.status,statusText:res.statusText,headers:h});
    try{Object.defineProperty(out,'url',{value:res.url})}catch{}
    return out;
  }
  function responseFrom(data,res){
    const h=new Headers(res.headers);
    h.delete('content-length');
    h.delete('content-encoding');
    h.set('content-type','application/json; charset=utf-8');
    const out=new Response(JSON.stringify(data),{status:res.status,statusText:res.statusText,headers:h});
    try{Object.defineProperty(out,'url',{value:res.url})}catch{}
    return out;
  }
  async function sanitizeJsonResponse(res,u){
    try{
      const raw=await res.clone().text(),sr=stripSerialized(raw);
      if(sr.changed){JSON.parse(sr.raw);emit('sanitized',u,{sanitizedParts:sr.count,raw:true,markerVersion:6});return textResponse(sr.raw,res,'application/json; charset=utf-8')}
      const data=JSON.parse(raw),r=C.sanitizeData(data);
      if(!r.changed)return res;
      emit('sanitized',u,{sanitizedParts:r.count,markerVersion:6});
      return responseFrom(data,res);
    }catch{return res}
  }
  function sanitizeSseLine(line){
    if(!line.startsWith('data:'))return{line,changed:false,count:0};
    const lead=line.startsWith('data: ')?'data: ':'data:',raw=line.slice(lead.length);
    if(!raw||raw==='[DONE]'||!raw.includes('KYRON_'))return{line,changed:false,count:0};
    const sr=stripSerialized(raw);
    if(sr.changed){try{JSON.parse(sr.raw);return{line:lead+sr.raw,changed:true,count:sr.count}}catch{}}
    try{
      const data=JSON.parse(raw),r=C.sanitizeData(data);
      if(!r.changed)return{line,changed:false,count:0};
      return{line:lead+JSON.stringify(data),changed:true,count:r.count};
    }catch{return{line,changed:false,count:0}}
  }
  function sanitizeSseResponse(res,u){
    if(!res.body||typeof TransformStream!=='function')return res;
    const dec=new TextDecoder(),enc=new TextEncoder();
    let buf='',count=0,changed=false;
    const ts=new TransformStream({
      transform(chunk,controller){
        buf+=dec.decode(chunk,{stream:true});
        for(;;){
          const i=buf.indexOf('\n');
          if(i<0)break;
          let line=buf.slice(0,i),nl='\n';
          buf=buf.slice(i+1);
          if(line.endsWith('\r')){line=line.slice(0,-1);nl='\r\n'}
          const r=sanitizeSseLine(line);
          changed=changed||r.changed;
          count+=r.count;
          controller.enqueue(enc.encode(r.line+nl));
        }
      },
      flush(controller){
        buf+=dec.decode();
        if(buf){const r=sanitizeSseLine(buf);changed=changed||r.changed;count+=r.count;controller.enqueue(enc.encode(r.line))}
        if(changed)emit('sanitized',u,{sanitizedParts:count,stream:true,markerVersion:6});
      }
    });
    const h=new Headers(res.headers);
    h.delete('content-length');
    h.delete('content-encoding');
    const out=new Response(res.body.pipeThrough(ts),{status:res.status,statusText:res.statusText,headers:h});
    try{Object.defineProperty(out,'url',{value:res.url})}catch{}
    return out;
  }
  async function sanitizeLiveResponse(res,u){
    if(!cfg.enabled||cfg.hideHistory===false||!res?.ok)return res;
    const ct=(res.headers.get('content-type')||'').toLowerCase();
    if(ct.includes('application/json')&&cfg.historyResponseSanitize===true)return sanitizeJsonResponse(res,u);
    if(ct.includes('text/event-stream')&&cfg.liveStreamSanitize===true)return sanitizeSseResponse(res,u);
    return res;
  }
  function sanitizeConversationData(data,u=null){
    if(!cfg.enabled||cfg.hideHistory===false)return false;
    const r=C.sanitizeData(data);
    if(r.changed&&u){
      const cid=u.pathname.split('/').filter(Boolean).at(-1)||'';
      if(cid){seenOnce.add(cid);smartState.set(cid,{rev})}
      emit('sanitized',u,{sanitizedParts:r.count,markerVersion:6,conversationId:cid});
    }
    return r.changed;
  }
  function setConfig(x){
    const next=C.normalize({...cfg,...x}),nextRev=C.configRevision(next),changed=nextRev!==rev;
    cfg=next;
    if(changed){rev=nextRev;pendingNew=null}
  }
  function resetState(){
    pendingNew=null;
    seenOnce.clear();
    smartState.clear();
  }

  const scheduleScrub=(ms=0)=>setTimeout(()=>{try{scrubVisible()}catch{}},Math.max(0,ms|0));


  window.addEventListener('message',e=>{
    if(e.source!==window||e.origin!==location.origin)return;
    if(e.data?.__kyronDeepFocus==='personality-config')setConfig(e.data.cfg||{});
    if(e.data?.__kyronModelPolicy==='config'){modelPolicy=normalizeModelPolicy(e.data.cfg)}
  });

  const api={isPromptSend,quickInterest,prepare,commit,rollback,sanitizeLiveResponse,sanitizeConversationData,setConfig,resetState,getConfig:()=>cfg,getMetrics:()=>({...perf}),getRuntimeIntel:()=>window.__KYRON_PERSONA_INTEL__?.snapshot?.()||null,probeRuntimeIntel:()=>window.__KYRON_PERSONA_INTEL__?.probeUi?.()||null,plan,injectData,scrubVisible};window.__KYRON_PERSONA_ENGINE_V6__=api;window.__KYRON_PERSONA_ENGINE_V5__=api;
  if(globalThis.__KYRON_TEST_MODE__)window.__KYRON_PERSONA_ENGINE_TEST__={...api,latestUserText,latestUserMessage,messageArrays,core:C,sanitizeSseLine,stripSerialized,stripRowMarkers,armBubbleGuard,conversationId,modelOf,reasoningModel,patchReasoningEffort,patchModelPolicy,normalizeModelPolicy,policySurface,getModelPolicy:()=>({...modelPolicy})};
})();
