(()=>{
'use strict';if(globalThis.__KYRON_CONVERSATION_BIDI__)return;globalThis.__KYRON_CONVERSATION_BIDI__=true;
const STYLE='kyron-conversation-bidi-style';
const ROOTS=['[data-thread-find-target="conversation"] [data-markdown-text-style="assistant-message"]','[data-chatgpt-conversation-selection-target="true"] [data-markdown-text-style="assistant-message"]','[data-message-author-role="assistant"] .markdown'];
const BLOCK=ROOTS.flatMap(r=>[r,r+' :is(p,li,blockquote,h1,h2,h3,h4,h5,h6,td,th)']).join(',');
const CODE=ROOTS.map(r=>r+' :is(pre,code,kbd,samp)').join(',');
function css(){if(document.getElementById(STYLE))return;const s=document.createElement('style');s.id=STYLE;s.textContent=BLOCK+'{unicode-bidi:plaintext!important;text-align:start!important;}'+CODE+'{direction:ltr!important;unicode-bidi:isolate!important;text-align:left!important;}';(document.head||document.documentElement).appendChild(s)}
function apply(root=document){for(const el of root.querySelectorAll?.(BLOCK)||[]){if(!el.hasAttribute('dir'))el.setAttribute('dir','auto')}}
css();if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>apply(),{once:true});else apply();
new MutationObserver(ms=>{for(const m of ms)for(const n of m.addedNodes)if(n.nodeType===1){if(n.matches?.(BLOCK)&&!n.hasAttribute('dir'))n.setAttribute('dir','auto');apply(n)}}).observe(document.documentElement,{childList:true,subtree:true});
})();
