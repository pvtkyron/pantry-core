# Kyron v10.1.12

Focused browser runtime for ChatGPT.

- `src/` — extension runtime and the single config contract.
- `ui/` — popup controls.
- `worker/` — gateway source.
- `customer-tests/` — customer runtime smoke tests.

Config files are portable. Auth, account snapshots, cookies and device identity stay local.
